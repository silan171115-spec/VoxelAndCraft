#!/bin/sh
mkdir -p out && javac -encoding UTF-8 -d out src/voxel/*.java && echo "Build OK. Run: sh run.sh"
