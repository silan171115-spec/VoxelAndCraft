@echo off
java -cp out voxel.Game %*
