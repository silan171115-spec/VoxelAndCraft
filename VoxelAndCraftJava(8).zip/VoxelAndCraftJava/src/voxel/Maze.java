package voxel;

import java.util.*;

/** Кальцитовый лабиринт: подземная структура 51x51 внутри кальцитовых пещер. Строится детерминированно по семени мира и ячейке 96x96. */
final class Maze {
    static final int REG = 96, SQ = 3, N = 17, SIZE = N * SQ, MARGIN = 6;
    static final Maze NONE = new Maze(0, 0, 0);
    final int ox, oz, y0;
    final boolean[][] wall = new boolean[N][N];
    int westRow; // индекс клетки западного входа (нечётный)
    static final int[][] RING = {{2, 1}, {2, 2}, {1, 2}, {0, 2}, {0, 1}, {0, 0}, {1, 0}, {2, 0}};

    Maze(int ox, int oz, int y0) { this.ox = ox; this.oz = oz; this.y0 = y0; }

    /** Лабиринт, к области которого (с запасом) относится колонка, или null. */
    static Maze at(World w, int wx, int wz) {
        int rx = Math.floorDiv(wx, REG), rz = Math.floorDiv(wz, REG);
        Maze m = w.mazes.computeIfAbsent(World.key(rx, rz), k -> create(w, rx, rz));
        if (m == NONE) return null;
        if (wx < m.ox - 14 || wx >= m.ox + SIZE + MARGIN || wz < m.oz - MARGIN || wz >= m.oz + SIZE + MARGIN) return null;
        return m;
    }

    static Maze create(World w, int rx, int rz) {
        Noise.seed = w.seed;
        if (Noise.h(rx, 0, rz, 301) > .5) return NONE;
        int ox = rx * REG + 14 + (int) (Noise.h(rx, 1, rz, 302) * 24), oz = rz * REG + 14 + (int) (Noise.h(rx, 2, rz, 303) * 24);
        int y0 = 9 + (int) (Noise.h(rx, 3, rz, 304) * 12);
        int[][] pts = {{ox, oz}, {ox + SIZE, oz}, {ox, oz + SIZE}, {ox + SIZE, oz + SIZE}, {ox + SIZE / 2, oz + SIZE / 2}};
        for (int[] p : pts) if (w.height(p[0], p[1]) < Math.max(y0 + 14, World.SEA + 6)) return NONE;
        Maze m = new Maze(ox, oz, y0);
        for (boolean[] row : m.wall) Arrays.fill(row, true);
        Random r = new Random(w.seed * 31L + rx * 7919L + rz * 104729L);
        // обход в глубину по клеткам (2i+1, 2j+1)
        int M = (N - 1) / 2; boolean[][] seen = new boolean[M][M];
        Deque<int[]> st = new ArrayDeque<>(); st.push(new int[]{0, 0}); seen[0][0] = true; m.wall[1][1] = false;
        int[][] D = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        while (!st.isEmpty()) {
            int[] c = st.peek(); List<int[]> opts = new ArrayList<>();
            for (int[] d : D) { int nx = c[0] + d[0], nz = c[1] + d[1]; if (nx >= 0 && nz >= 0 && nx < M && nz < M && !seen[nx][nz]) opts.add(new int[]{nx, nz, d[0], d[1]}); }
            if (opts.isEmpty()) { st.pop(); continue; }
            int[] o = opts.get(r.nextInt(opts.size()));
            seen[o[0]][o[1]] = true; m.wall[2 * c[0] + 1 + o[2]][2 * c[1] + 1 + o[3]] = false; m.wall[2 * o[0] + 1][2 * o[1] + 1] = false;
            st.push(new int[]{o[0], o[1]});
        }
        // центральный зал 3x3 клетки и несколько лишних проходов
        for (int i = 7; i <= 9; i++) for (int j = 7; j <= 9; j++) m.wall[i][j] = false;
        for (int k = 0; k < 14; k++) { int i = 1 + r.nextInt(N - 2), j = 1 + r.nextInt(N - 2); if ((i + j) % 2 == 1) m.wall[i][j] = false; }
        // два входа по краям
        m.westRow = 2 * r.nextInt(M) + 1; m.wall[0][m.westRow] = false; m.wall[N - 1][2 * r.nextInt(M) + 1] = false; m.wall[2 * r.nextInt(M) + 1][0] = false;
        return m;
    }

    /** id блока лабиринта; -1 — вне структуры, -2 — окружающая зона (камень там станет кальцитом). */
    int block(int wx, int y, int wz) {
        int lx = wx - ox, lz = wz - oz, rowZ = westRow * SQ;
        if (lz >= rowZ && lz < rowZ + SQ) {
            int dy0 = y - y0;
            if (lx >= -11 && lx < -8) { // шахта со спиральной лестницей вверх, к поверхности
                if (dy0 < 0) return -2;
                if (dy0 == 0) return Blocks.SMOOTH_CALCITE;
                int ci = lx + 11, cj = lz - rowZ, k = dy0, ring = -1;
                for (int q = 0; q < 8; q++) if (RING[q][0] == ci && RING[q][1] == cj) ring = q;
                return (ring >= 0 && (k - 1) % 8 == ring) ? Blocks.CALCITE_BRICKS : 0;
            }
            if (lx >= -8 && lx < 0) { // тоннель от шахты к лабиринту
                if (dy0 == 0 || dy0 == 5) return Blocks.SMOOTH_CALCITE;
                if (dy0 >= 1 && dy0 <= 4) return 0;
            }
        }
        if (lx < 0 || lz < 0 || lx >= SIZE || lz >= SIZE) return y >= y0 - 3 && y <= y0 + 8 ? -2 : -1;
        int dy = y - y0;
        if (dy < -3 || dy > 8) return -1;
        if (dy < 0 || dy > 5) return -2;
        if (dy == 0) return ((lx / SQ + lz / SQ) % 2 == 0 && lx % SQ == 1 && lz % SQ == 1) ? Blocks.CALCITE_BRICKS : Blocks.SMOOTH_CALCITE;
        if (dy == 5) return Blocks.SMOOTH_CALCITE;
        int sx = lx / SQ, sz = lz / SQ;
        if (wall[sx][sz]) return Blocks.CALCITE_BRICKS;
        if (sx == 8 && sz == 8 && lx % SQ == 1 && lz % SQ == 1) return dy == 1 ? Blocks.CALCITE_BRICKS : dy == 2 ? Blocks.DIAMOND_ORE : dy == 3 ? Blocks.GOLD_ORE : 0;
        return 0;
    }
}
