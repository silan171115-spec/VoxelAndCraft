package voxel;

import java.io.*;
import java.net.Socket;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Сетевой слой (TCP). Кадр: [int длина][byte тип][данные]. Потоки чтения/записи только гоняют байты;
 * разбор и обработка сообщений всегда выполняются в игровом потоке через очередь inbox.
 */
final class Net {
    // клиент -> сервер
    static final int HELLO = 1, POS = 2, BLOCK = 3, ATTACK = 4;
    // сервер -> клиент
    static final int WELCOME = 10, CHUNKDIFF = 11, DIFFDONE = 12, BLOCKS = 13, PLAYERS = 14, MOBS = 15, TIME = 16, DAMAGE = 17, KICK = 18;
    static final int PROTOCOL = 1, DEFAULT_PORT = 25565;

    interface IOConsumer { void accept(DataOutputStream o) throws IOException; }
    interface Handler { void handle(Link l, int type, DataInputStream in) throws IOException; void closed(Link l); }

    static byte[] frame(int type, IOConsumer body) {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream(); DataOutputStream o = new DataOutputStream(bo);
            o.writeInt(0); o.writeByte(type); body.accept(o); o.flush();
            byte[] b = bo.toByteArray(); int len = b.length - 4;
            b[0] = (byte) (len >>> 24); b[1] = (byte) (len >>> 16); b[2] = (byte) (len >>> 8); b[3] = (byte) len;
            return b;
        } catch (IOException e) { throw new UncheckedIOException(e); }
    }

    static final class Link {
        final Socket sock; final LinkedBlockingQueue<byte[]> out = new LinkedBlockingQueue<>();
        volatile boolean alive = true; Object user;

        Link(Socket s, Queue<Runnable> inbox, Handler h) throws IOException {
            sock = s; s.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            OutputStream os = new BufferedOutputStream(s.getOutputStream());
            Thread rd = new Thread(() -> {
                try {
                    while (alive) {
                        int len = in.readInt(); if (len < 1 || len > 16 * 1024 * 1024) throw new IOException("bad frame");
                        byte[] b = new byte[len]; in.readFully(b);
                        inbox.add(() -> {
                            if (!alive) return;
                            try { h.handle(this, b[0] & 0xff, new DataInputStream(new ByteArrayInputStream(b, 1, b.length - 1))); }
                            catch (IOException e) { close(); }
                        });
                    }
                } catch (IOException e) { }
                finally { if (alive) { alive = false; inbox.add(() -> h.closed(this)); } closeQuiet(); }
            }, "net-read"); rd.setDaemon(true); rd.start();
            Thread wr = new Thread(() -> {
                try {
                    while (alive || !out.isEmpty()) {
                        byte[] f = out.take(); if (f.length == 0) break;
                        os.write(f); if (out.isEmpty()) os.flush();
                    }
                    os.flush();
                } catch (Exception e) { }
                finally { closeQuiet(); }
            }, "net-write"); wr.setDaemon(true); wr.start();
        }
        void send(byte[] frame) { if (alive) out.add(frame); }
        void close() { if (alive) { alive = false; out.add(new byte[0]); } closeQuiet(); }
        void closeQuiet() { try { sock.close(); } catch (IOException e) { } }
    }
}
