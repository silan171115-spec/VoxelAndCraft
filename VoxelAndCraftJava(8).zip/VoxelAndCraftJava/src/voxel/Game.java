package voxel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

/** Voxel and Craft — Java-версия. Запуск: java -cp out voxel.Game */
public final class Game extends JPanel {
    static final double DAY_LEN = 480;
    static final int MAIN = 0, PLAY = 1, PAUSE = 2, SETTINGS = 3, WORLDS = 4, CREATE = 5;
    static final int[][] Q = {{320, 180, 48}, {480, 270, 64}, {640, 360, 96}};
    static final String[] QN = {"Низкое", "Среднее", "Высокое"};
    static final double[] SENS = {.5, .75, 1, 1.5, 2};
    static final String[] SPLASH = {"Сделано на Java!", "Только JDK 21!", "Вода течёт!", "Greedy meshing!", "Ломай и строй!", "Без библиотек!", "Мир сохраняется!"};

    record Btn(Rectangle r, boolean enabled, Runnable act) { }

    World world; Player p = new Player(); Renderer r; BufferedImage img; Save save;
    final boolean[] keys = new boolean[256];
    double time = DAY_LEN * .25, mine; int mineX = -1, mineY, mineZ; boolean lmb, rmb, grabbed;
    Robot robot; long last = System.nanoTime(), lastSpace; double fps = 60; boolean showInv;
    Cursor blank;
    int state = MAIN, prevState = MAIN, quality = 1, sensIdx = 2, fovIdx = 1, viewIdx = 2;
    static final int[] FOV = {55, 70, 85, 100}, VIEW = {32, 48, 64, 96, 128};
    boolean invertY, showInfo = true, keepInv = true, showHints = true;
    double fluidAcc, saveAcc, toastT; String toast = "";
    // меню
    World mw; Renderer mr; BufferedImage mimg; double mYaw;
    List<Save> saves = new ArrayList<>(); int sel = -1, scroll;
    String cName = "", cSeed = ""; int cFocus; boolean cCreative, confirmDel;
    int mx, my; double ui = 1; String splash = SPLASH[new Random().nextInt(SPLASH.length)];
    final List<Btn> btns = new ArrayList<>();
    final List<Rectangle> rows = new ArrayList<>();
    // сеть и мобы
    static final int JOIN = 6, JOINING = 7, DEAD = 8;
    final MobManager mobs = new MobManager(); Server server; Client client; final List<Remote> remotes = new ArrayList<>();
    String nick = "Игрок" + new Random().nextInt(100), joinAddr = "127.0.0.1:25565"; volatile String joinStatus = ""; volatile boolean joinFailed;
    boolean hostMode; int joinFocus; double attackCd; Mob targetMob; List<String> localIps;
    // GUI (инвентарь, верстак, печь) и измерения
    static final int GUI_INV = 1, GUI_CRAFT = 2, GUI_FURN = 3;
    int gui, curId, curN; final int[] cgId = new int[9], cgN = new int[9]; Furnace furn;
    World overworld, sulfur; double portalT; boolean needExit; double portalMsgT;
    record Slot(int kind, int idx, Rectangle r) { }
    final List<Slot> slots = new ArrayList<>();

    Game() {
        setPreferredSize(new Dimension(960, 540)); setFocusable(true);
        try { robot = new Robot(); } catch (Exception e) { }
        try { blank = Toolkit.getDefaultToolkit().createCustomCursor(new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB), new Point(), "b"); } catch (Exception e) { blank = null; }
        loadSettings(); refreshSaves();
        addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (state != CREATE && state != JOIN) return;
                char ch = e.getKeyChar(); if (ch < 32 || ch == 127) return;
                if (state == JOIN) { if (joinFocus == 0 && nick.length() < 16) nick += ch; else if (joinFocus == 1 && joinAddr.length() < 40) joinAddr += ch; return; }
                if (cFocus == 0 && cName.length() < 24) cName += ch; else if (cFocus == 1 && cSeed.length() < 18) cSeed += ch;
            }
            public void keyPressed(KeyEvent e) {
                int c = e.getKeyCode(); if (c < 256) keys[c] = true;
                if (state == CREATE) {
                    if (c == KeyEvent.VK_ESCAPE) state = WORLDS; else if (c == KeyEvent.VK_TAB) cFocus = 1 - cFocus; else if (c == KeyEvent.VK_ENTER) createWorld();
                    else if (c == KeyEvent.VK_BACK_SPACE) { if (cFocus == 0 && !cName.isEmpty()) cName = cName.substring(0, cName.length() - 1); else if (cFocus == 1 && !cSeed.isEmpty()) cSeed = cSeed.substring(0, cSeed.length() - 1); }
                    return;
                }
                if (state == JOIN) {
                    if (c == KeyEvent.VK_ESCAPE) state = MAIN; else if (c == KeyEvent.VK_TAB) joinFocus = 1 - joinFocus; else if (c == KeyEvent.VK_ENTER) startJoin();
                    else if (c == KeyEvent.VK_BACK_SPACE) { if (joinFocus == 0 && !nick.isEmpty()) nick = nick.substring(0, nick.length() - 1); else if (joinFocus == 1 && !joinAddr.isEmpty()) joinAddr = joinAddr.substring(0, joinAddr.length() - 1); }
                    return;
                }
                if (state == JOINING) return;
                if (state == SETTINGS) { if (c == KeyEvent.VK_ESCAPE) state = prevState; return; }
                if (state == WORLDS) { if (c == KeyEvent.VK_ESCAPE) state = MAIN; return; }
                if (state == MAIN || state == DEAD) return;
                if (state == PAUSE) { if (c == KeyEvent.VK_ESCAPE) { state = PLAY; grab(true); } return; }
                if (c >= KeyEvent.VK_1 && c <= KeyEvent.VK_9) p.selected = c - KeyEvent.VK_1;
                if (c == KeyEvent.VK_ESCAPE) { if (gui != 0) closeGui(); else { state = PAUSE; grab(false); } }
                if (c == KeyEvent.VK_C) { p.creative = !p.creative; if (!p.creative) p.flying = false; }
                if (c == KeyEvent.VK_E) { if (gui != 0) closeGui(); else openGui(GUI_INV); }
                if (c == KeyEvent.VK_SPACE) { long n = System.currentTimeMillis(); if (n - lastSpace < 300 && p.creative) p.flying = !p.flying; lastSpace = n; }
                if (c == KeyEvent.VK_F2) shot();
                if (c == KeyEvent.VK_F5) { saveGame(); }
            }
            public void keyReleased(KeyEvent e) { int c = e.getKeyCode(); if (c < 256) keys[c] = false; }
        });
        addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                if (state != PLAY) { if (e.getButton() == 1) click(e.getX() / ui, e.getY() / ui); return; }
                if (gui != 0) { guiClick(e.getX() / ui, e.getY() / ui, e.getButton()); return; }
                if (!grabbed) { grab(true); return; }
                if (e.getButton() == 1) lmb = true;
                if (e.getButton() == 3) { rmb = true; if (!interact()) place(); }
            }
            public void mouseReleased(MouseEvent e) { if (e.getButton() == 1) { lmb = false; mine = 0; } if (e.getButton() == 3) rmb = false; }
        });
        MouseAdapter mm = new MouseAdapter() {
            public void mouseMoved(MouseEvent e) { mx = (int) (e.getX() / ui); my = (int) (e.getY() / ui); look(e); }
            public void mouseDragged(MouseEvent e) { mx = (int) (e.getX() / ui); my = (int) (e.getY() / ui); look(e); }
        };
        addMouseMotionListener(mm);
        addMouseWheelListener(e -> {
            if (state == PLAY) p.selected = Math.floorMod(p.selected + e.getWheelRotation(), 9);
            else if (state == WORLDS) scroll = Math.max(0, scroll + e.getWheelRotation() * 30);
        });
        new javax.swing.Timer(16, e -> { tick(); repaint(); }).start();
    }

    // ================= сохранения и переходы =================
    void refreshSaves() { saves = Save.list(); sel = saves.isEmpty() ? -1 : Math.min(Math.max(sel, 0), saves.size() - 1); scroll = 0; }
    void applyQuality() {
        int[] q = Q[quality]; r = new Renderer(q[0], q[1]); r.viewDist = VIEW[viewIdx]; r.setFov(FOV[fovIdx]); applyDim();
        img = new BufferedImage(q[0], q[1], BufferedImage.TYPE_INT_RGB);
    }
    void createWorld() {
        int seed;
        String s = cSeed.trim();
        if (s.isEmpty()) seed = (int) (System.nanoTime() & 0x7fffffff); else { try { seed = Integer.parseInt(s); } catch (NumberFormatException ex) { seed = s.hashCode(); } }
        String name = cName.trim().isEmpty() ? "Новый мир" : cName.trim();
        startGame(Save.create(name, seed, cCreative));
    }
    void startGame(Save s) {
        save = s; mw = null; mr = null; mimg = null; mobs.clear(); remotes.clear();
        world = new World(s.seed(), s); overworld = world; sulfur = null; gui = 0; curId = curN = 0; Arrays.fill(cgId, 0); Arrays.fill(cgN, 0);
        p = new Player(s.hasPlayer() || s.creative());
        loadFurnaces();
        if (s.hasPlayer() && (int) s.d("dim", 0) == 1) world = ensureWorld(1);
        applyQuality();
        if (s.hasPlayer()) { s.readPlayer(p); time = s.d("time", DAY_LEN * .25); }
        else { int[] sp = world.findSpawn(); p.x = sp[0] + .5; p.y = sp[1]; p.z = sp[2] + .5; p.creative = s.creative(); time = DAY_LEN * .25; }
        showInv = false; mine = 0; mineX = -1; lmb = rmb = false;
        state = PLAY; grab(true); saveGame();
        if (hostMode) startHost();
    }
    // ================= сеть =================
    void toast(String s) { toast = s; toastT = 3; }
    void startHost() {
        server = new Server(this, Net.DEFAULT_PORT);
        try { server.start(); toast("Сервер запущен на порту " + Net.DEFAULT_PORT); }
        catch (java.io.IOException e) { server = null; toast("Не удалось открыть порт " + Net.DEFAULT_PORT + " — игра одиночная"); }
    }
    void leaveNet() {
        if (server != null) server.stop(); if (client != null) client.disconnect();
        server = null; client = null; hostMode = false; mobs.clear(); remotes.clear();
    }
    void startJoin() {
        String a = joinAddr.trim(); String host = a; int port = Net.DEFAULT_PORT;
        int i = a.lastIndexOf(':'); if (i > 0) { host = a.substring(0, i); try { port = Integer.parseInt(a.substring(i + 1).trim()); } catch (NumberFormatException e) { joinStatus = "Неверный порт"; return; } }
        if (host.isBlank()) { joinStatus = "Введите адрес сервера"; return; }
        client = new Client(this); joinFailed = false; joinStatus = "Подключение к " + host + ":" + port + "..."; state = JOINING;
        client.connectAsync(host, port, nick.isBlank() ? "Игрок" : nick.trim());
    }
    void clientWelcome(int seed, double t, double x, double y, double z, boolean creative) {
        world = new World(seed); world.noFluid = true; world.noMech = true; overworld = world; sulfur = null; gui = 0; curId = curN = 0; save = null; p = new Player(); p.x = x; p.y = y; p.z = z; p.creative = creative;
        applyQuality(); time = t; mobs.clear(); remotes.clear(); mw = null; mr = null; mimg = null; showInv = false;
        world.blockListener = a -> { if (a[5] == 1 && client != null) client.sendBlock(a); };
        joinStatus = "Загрузка мира...";
    }
    void clientReady() { state = PLAY; grab(true); joinStatus = ""; toast("Вы подключились к серверу"); }
    void onDisconnected(String why) {
        leaveNet(); world = null; r = null; img = null; grab(false); state = JOIN; joinStatus = why; joinFailed = true;
    }
    List<MobManager.Target> targets() {
        List<MobManager.Target> t = new ArrayList<>();
        t.add(new MobManager.Target(p.x, p.y, p.z, p.creative, d -> { if (!p.creative) p.hurt(d, "Вас убил зомби"); }));
        if (server != null) for (Remote rm : remotes) t.add(new MobManager.Target(rm.x, rm.y, rm.z, false, d -> server.sendDamage(rm, d)));
        return t;
    }
    void doAttack(Mob m, double dx, double dz) {
        int held = p.inv[p.selected]; double dmg = p.creative ? 100 : Blocks.isTool(held) ? (Blocks.kind[held] == 4 ? 5 + Blocks.tier[held] : 3) : 2;
        double hl = Math.hypot(dx, dz); if (hl < 1e-6) hl = 1;
        double kx = dx / hl * 7, kz = dz / hl * 7;
        if (client != null) { client.sendAttack(m.id, dmg, kx, kz); m.hurt = .3; } else mobs.attack(m.id, dmg, kx, kz);
    }
    void saveGame() {
        if (world == null || save == null) return;
        if (overworld != null) overworld.saveModified(); if (sulfur != null) sulfur.saveModified();
        save.info.setProperty("dim", "" + world.dim);
        save.writePlayer(p, time, p.flying); saveFurnaces();
        toast = "Мир сохранён"; toastT = 2;
    }
    void heart(Graphics2D g, int x, int y, int s) {
        int h = s / 2; g.fillOval(x, y, h + 1, h + 1); g.fillOval(x + s - h - 1, y, h + 1, h + 1);
        g.fillPolygon(new int[]{x, x + s, x + s / 2}, new int[]{y + h / 2 + 1, y + h / 2 + 1, y + s}, 3);
    }
    /** Возрождение после смерти: в начальной точке мира (в обычном измерении). */
    void respawn() {
        if (world != null && world.dim != 0 && overworld != null) { world = overworld; applyDim(); }
        int[] sp = world.findSpawn();
        p.x = sp[0] + .5; p.y = sp[1]; p.z = sp[2] + .5; p.vx = p.vy = p.vz = 0; p.health = 20; p.air = 10; p.dead = false; p.cause = ""; p.fallStart = p.y; p.sinceHurt = 99;
        if (!keepInv && !p.creative) { java.util.Arrays.fill(p.inv, 0); java.util.Arrays.fill(p.cnt, 0); }
        portalT = 0; needExit = false;
        state = PLAY; grab(true); toast("Вы возродились"); 
    }
    void loadSettings() {
        try (java.io.InputStream in = new java.io.FileInputStream("settings.properties")) {
            Properties pr = new Properties(); pr.load(new java.io.InputStreamReader(in, java.nio.charset.StandardCharsets.UTF_8));
            quality = Math.max(0, Math.min(2, Integer.parseInt(pr.getProperty("quality", "1")))); sensIdx = Math.max(0, Math.min(SENS.length - 1, Integer.parseInt(pr.getProperty("sens", "2"))));
            fovIdx = Math.max(0, Math.min(FOV.length - 1, Integer.parseInt(pr.getProperty("fov", "1")))); viewIdx = Math.max(0, Math.min(VIEW.length - 1, Integer.parseInt(pr.getProperty("view", "2"))));
            invertY = Boolean.parseBoolean(pr.getProperty("invertY", "false")); showInfo = Boolean.parseBoolean(pr.getProperty("info", "true"));
            keepInv = Boolean.parseBoolean(pr.getProperty("keepInv", "true")); showHints = Boolean.parseBoolean(pr.getProperty("hints", "true"));
        } catch (Exception e) { }
    }
    void saveSettings() {
        try (java.io.OutputStream o = new java.io.FileOutputStream("settings.properties")) {
            Properties pr = new Properties(); pr.setProperty("quality", "" + quality); pr.setProperty("sens", "" + sensIdx); pr.setProperty("fov", "" + fovIdx); pr.setProperty("view", "" + viewIdx);
            pr.setProperty("invertY", "" + invertY); pr.setProperty("info", "" + showInfo); pr.setProperty("keepInv", "" + keepInv); pr.setProperty("hints", "" + showHints);
            pr.store(new java.io.OutputStreamWriter(o, java.nio.charset.StandardCharsets.UTF_8), "Voxel and Craft");
        } catch (Exception e) { }
    }
    void exitToMenu() {
        closeGui(false); saveGame(); leaveNet(); overworld = sulfur = null; world = null; save = null; r = null; img = null; state = MAIN; grab(false); refreshSaves();
    }

    void grab(boolean g) { grabbed = g; setCursor(g && blank != null ? blank : Cursor.getDefaultCursor()); }
    void look(MouseEvent e) {
        if (!grabbed || robot == null || state != PLAY) return;
        Point c = getLocationOnScreen(); int cx = c.x + getWidth() / 2, cy = c.y + getHeight() / 2;
        int dx = e.getXOnScreen() - cx, dy = e.getYOnScreen() - cy;
        if (dx == 0 && dy == 0) return;
        double k = .0025 * SENS[sensIdx];
        p.yaw -= dx * k; p.pitch = Math.max(-1.55, Math.min(1.55, p.pitch - (invertY ? -dy : dy) * k));
        robot.mouseMove(cx, cy);
    }
    void click(double x, double y) {
        for (int i = btns.size() - 1; i >= 0; i--) { Btn b = btns.get(i); if (b.enabled && b.r.contains(x, y)) { b.act.run(); return; } }
        if (state == WORLDS) for (int i = 0; i < rows.size(); i++) if (rows.get(i).contains(x, y) && y > 56 && y < lastListBottom) { sel = i; confirmDel = false; return; }
        if (state == CREATE) { if (fieldRect(0).contains(x, y)) cFocus = 0; else if (fieldRect(1).contains(x, y)) cFocus = 1; }
        if (state == JOIN) { if (fieldRect(0).contains(x, y)) joinFocus = 0; else if (fieldRect(1).contains(x, y)) joinFocus = 1; }
    }
    int lastListBottom, lw, lh;
    Rectangle fieldRect(int i) { return new Rectangle(lw / 2 - 200, 112 + i * 80, 400, 36); }

    // ================= игровая логика =================
    void place() {
        if (r.hitFace < 0) return; int id = p.inv[p.selected]; if (id == 0 || p.cnt[p.selected] <= 0 || !Blocks.isBlock(id)) return;
        int x = r.prevX, y = r.prevY, z = r.prevZ;
        int cur = world.get(x, y, z);
        if (Blocks.solid[id] && !Blocks.shaped[id] && Math.abs(x + .5 - p.x) < .8 && Math.abs(z + .5 - p.z) < .8 && y + 1 > p.y && y < p.y + 1.8) return;
        int meta = 0;
        if (Blocks.shaped[id]) {
            double cp = Math.cos(p.pitch), dx = -Math.sin(p.yaw) * cp, dy = Math.sin(p.pitch), dz = -Math.cos(p.yaw) * cp;
            double fy = p.eyeY() + dy * r.hitDist; fy -= Math.floor(fy);
            boolean upper = r.hitFace == 3 || (r.hitFace != 0 && fy > .5);
            if (id < Blocks.STAIR0) {
                int hid = world.get(r.hitX, r.hitY, r.hitZ), hm = world.getMeta(r.hitX, r.hitY, r.hitZ);
                if (hid == id && ((hm == 0 && r.hitFace == 0) || (hm == 1 && r.hitFace == 3))) { // две плиты = полный блок
                    world.set(r.hitX, r.hitY, r.hitZ, Blocks.MATS[id - Blocks.SLAB0], 0, true);
                    if (!p.creative) { if (--p.cnt[p.selected] == 0) p.inv[p.selected] = 0; }
                    return;
                }
                meta = upper ? 1 : 0;
            } else {
                meta = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? 0 : 1) : (dz > 0 ? 2 : 3);
                if (upper) meta |= 4;
            }
        }
        if (cur != 0 && cur != Blocks.WATER && cur != Blocks.LAVA) return;
        world.set(x, y, z, id, meta, true); if (!p.creative) { if (--p.cnt[p.selected] == 0) p.inv[p.selected] = 0; }
    }
    void breakBlock(int x, int y, int z) {
        int id = world.get(x, y, z);
        if (id == Blocks.FURNACE) {
            Furnace f = world.furnaces.remove(Fluid.pack(x, y, z));
            if (f != null) { if (f.inN > 0) p.add(f.inId, f.inN); if (f.fuelN > 0) p.add(f.fuelId, f.fuelN); if (f.outN > 0) p.add(f.outId, f.outN); }
        }
        world.set(x, y, z, 0);
        if (id == Blocks.COAL_BLOCK || id == Blocks.DYNAMITE) collapsePortals(x, y, z);
        int d = Blocks.drop[id]; if (d == -1) d = id;
        if (id == Blocks.SULFUR_ORE) { if (!p.creative) p.add(Blocks.SULFUR, 2 + new Random().nextInt(3)); return; }
        if (id == Blocks.SULFUR_CRYSTAL) { if (!p.creative) p.add(Blocks.SULFUR, 1 + new Random().nextInt(2)); return; }
        if (d > 0 && !p.creative) p.add(d, 1);
    }
    double breakTime(int id) {
        double h = Blocks.hard[id]; if (h >= 999) return 1e9; if (p.creative) return 0;
        int held = p.inv[p.selected], k = Blocks.isTool(held) ? Blocks.kind[held] : 0;
        double speed = (k == Blocks.tool[id] && k > 0) ? Blocks.SPEED[Blocks.tier[held]] : 1;
        return h * 1.5 / speed;
    }
    void tick() {
        long n = System.nanoTime(); double dt = Math.min(.05, (n - last) / 1e9); last = n; fps = fps * .9 + .1 / Math.max(dt, 1e-4);
        if (toastT > 0) toastT -= dt;
        if (state == JOINING) {
            if (client != null) client.tick(dt);
            if (joinFailed) { client = null; world = null; state = JOIN; }
            return;
        }
        if (world == null && (state == MAIN || state == SETTINGS)) { panorama(dt); return; }
        boolean net = server != null || client != null;
        boolean sim = state == PLAY || (net && (state == PAUSE || state == DEAD || (state == SETTINGS && prevState == PAUSE)));
        if (state == PLAY && world != null && p.dead) { closeGui(false); state = DEAD; grab(false); lmb = rmb = false; mine = 0; }
        if (!sim || world == null) return;
        time += dt;
        if (client != null) client.tick(dt);
        if (state == PLAY) {
            double fw = (keys[KeyEvent.VK_W] ? 1 : 0) - (keys[KeyEvent.VK_S] ? 1 : 0), st = (keys[KeyEvent.VK_D] ? 1 : 0) - (keys[KeyEvent.VK_A] ? 1 : 0);
            boolean busy = gui != 0;
            p.update(world, dt, busy ? 0 : fw, busy ? 0 : st, !busy && keys[KeyEvent.VK_SPACE], !busy && keys[KeyEvent.VK_SHIFT]);
        }
        if (client == null) {
            fluidAcc += dt; if (fluidAcc > .2) { fluidAcc = 0; world.fluid.tick(); }
            mobs.update(world, dt, world.dim == 1 ? 0 : day(), targets());
        } else mobs.clientUpdate(dt);
        for (Remote rm : remotes) rm.update(dt);
        Textures.animate(time);
        if (client == null) { world.mech.tick(); tickDynamite(dt); for (Furnace f : world.furnaces.values()) f.update(dt); }
        if (server != null) server.tick(dt);
        saveAcc += dt; if (saveAcc > 60) { saveAcc = 0; saveGame(); }
        if (state != PLAY) return;
        portalLogic(dt);
        List<Renderer.Renderable> ents = new ArrayList<>(mobs.mobs); ents.addAll(remotes);
        r.render(world, p, world.dim == 1 ? 1 : day(), mine, time, ents);
        attackCd -= dt;
        double cp = Math.cos(p.pitch), vdx = -Math.sin(p.yaw) * cp, vdy = Math.sin(p.pitch), vdz = -Math.cos(p.yaw) * cp;
        double[] md = {0}; Mob tm = mobs.raycast(p.x, p.eyeY(), p.z, vdx, vdy, vdz, 3.6, md);
        boolean mobFirst = tm != null && (r.hitFace < 0 || md[0] < r.hitDist); targetMob = mobFirst ? tm : null;
        if (lmb && mobFirst) { mine = 0; if (attackCd <= 0) { attackCd = .45; doAttack(tm, vdx, vdz); } }
        else if (lmb && r.hitFace >= 0) {
            if (r.hitX != mineX || r.hitY != mineY || r.hitZ != mineZ) { mineX = r.hitX; mineY = r.hitY; mineZ = r.hitZ; mine = 0; }
            mine += dt; int id = world.get(mineX, mineY, mineZ);
            if (mine >= breakTime(id)) { breakBlock(mineX, mineY, mineZ); mine = 0; }
        } else mine = 0;
        System.arraycopy(r.px, 0, ((DataBufferInt) img.getRaster().getDataBuffer()).getData(), 0, r.px.length);
    }
    double day() { double a = (time % DAY_LEN) / DAY_LEN * 2 * Math.PI; return Math.max(0, Math.min(1, .5 + .9 * Math.sin(a))); }

    /** Живой фон главного меню: медленно вращающаяся панорама генерируемого мира. */
    void panorama(double dt) {
        if (mw == null) {
            mw = new World(777); mr = new Renderer(320, 180); mr.viewDist = 64; mimg = new BufferedImage(320, 180, BufferedImage.TYPE_INT_RGB);
        }
        mYaw += dt * .12;
        Player cam = new Player(); int[] sp = mw.findSpawn(); cam.x = sp[0] + .5; cam.z = sp[2] + .5; cam.y = Math.max(sp[1] + 6, 44) - Player.EYE_H(); cam.yaw = mYaw; cam.pitch = -.12;
        mr.render(mw, cam, .95, 0, 0);
        System.arraycopy(mr.px, 0, ((DataBufferInt) mimg.getRaster().getDataBuffer()).getData(), 0, mr.px.length);
        mr.hitFace = -1;
    }

    // ================= отрисовка =================
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0; int w = getWidth(), h = getHeight();
        ui = Math.max(1, Math.min(w / 960.0, h / 540.0));
        lw = (int) (w / ui); lh = (int) (h / ui);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        btns.clear(); rows.clear();
        boolean inGame = world != null && img != null;
        if (inGame && (state == PLAY || state == PAUSE || state == DEAD || (state == SETTINGS && prevState == PAUSE))) {
            g.drawImage(img, 0, 0, w, h, null);
            AffineTransform at = g.getTransform(); g.scale(ui, ui);
            if (state == PLAY) hud(g, lw, lh);
            g.setColor(state == PLAY ? new Color(0, 0, 0, 0) : state == DEAD ? new Color(120, 0, 0, 150) : new Color(0, 0, 0, 150)); g.fillRect(0, 0, lw, lh);
            menu(g); g.setTransform(at); return;
        }
        if (mimg != null && (state == MAIN || state == SETTINGS)) {
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(mimg, 0, 0, w, h, null);
            g.setPaint(new GradientPaint(0, 0, new Color(0, 0, 0, 90), 0, h, new Color(0, 0, 0, 20))); g.fillRect(0, 0, w, h);
        } else { g.setPaint(new GradientPaint(0, 0, new Color(60, 110, 180), 0, h, new Color(20, 40, 30))); g.fillRect(0, 0, w, h); }
        g.scale(ui, ui);
        if (state == WORLDS || state == CREATE || state == JOIN || state == JOINING || (state == SETTINGS && mimg == null)) Ui.dirtBackground(g, lw, lh);
        menu(g);
    }

    Btn button(Graphics2D g, String label, int x, int y, int w, int h, boolean enabled, Runnable act) {
        Rectangle rc = new Rectangle(x, y, w, h);
        Ui.button(g, rc, label, enabled && rc.contains(mx, my), enabled);
        Btn b = new Btn(rc, enabled, act); btns.add(b); return b;
    }
    void title(Graphics2D g, String t, int y) { g.setFont(new Font("SansSerif", Font.BOLD, 24)); Ui.centerText(g, t, lw / 2, y, Color.WHITE); }

    void menu(Graphics2D g) {
        int cx = lw / 2;
        switch (state) {
            case MAIN -> {
                int lh0 = Ui.logo(g, "VOXEL AND CRAFT", cx, 48, Math.min(lw - 60, 760));
                // подпись
                AffineTransform at = g.getTransform();
                g.translate(cx + Ui.logoImg.getWidth() / 2 - 70, 48 + lh0 - 6); g.rotate(-.35);
                double pulse = 1 + .06 * Math.sin(System.currentTimeMillis() / 180.0); g.scale(pulse, pulse);
                g.setFont(new Font("SansSerif", Font.BOLD, 18)); Ui.centerText(g, splash, 0, 0, new Color(255, 255, 60));
                g.setTransform(at);
                int y = lh / 2 - 10;
                button(g, "Одиночная игра", cx - 200, y - 20, 400, 40, true, () -> { hostMode = false; refreshSaves(); state = WORLDS; confirmDel = false; });
                button(g, "Создать сервер", cx - 200, y + 30, 196, 40, true, () -> { hostMode = true; refreshSaves(); state = WORLDS; confirmDel = false; });
                button(g, "Подключиться по IP", cx + 4, y + 30, 196, 40, true, () -> { joinStatus = ""; joinFocus = 1; state = JOIN; });
                button(g, "Настройки", cx - 200, y + 80, 196, 40, true, () -> { prevState = MAIN; state = SETTINGS; });
                button(g, "Выход", cx + 4, y + 80, 196, 40, true, () -> System.exit(0));
                g.setFont(new Font("SansSerif", Font.PLAIN, 13)); Ui.shadowText(g, "Voxel and Craft — Java 21", 8, lh - 10, Color.WHITE);
                String rt = "Версия 5 · чистый JDK"; Ui.shadowText(g, rt, lw - g.getFontMetrics().stringWidth(rt) - 8, lh - 10, Color.WHITE);
            }
            case WORLDS -> {
                title(g, hostMode ? "Сервер: выберите мир" : "Выбор мира", 38);
                int top = 56, bottom = lh - 100; lastListBottom = bottom;
                Ui.darkenStrip(g, 0, top, lw, bottom - top);
                int rw = Math.min(lw - 80, 560), x0 = cx - rw / 2;
                Shape oldClip = g.getClip(); g.setClip(0, top, lw, bottom - top);
                int total = saves.size() * 58; scroll = Math.max(0, Math.min(scroll, Math.max(0, total - (bottom - top) + 8)));
                SimpleDateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                for (int i = 0; i < saves.size(); i++) {
                    Save s = saves.get(i); Rectangle rc = new Rectangle(x0, top + 8 + i * 58 - scroll, rw, 54); rows.add(rc);
                    if (rc.contains(mx, my) && my > top && my < bottom) { g.setColor(new Color(255, 255, 255, 30)); g.fillRect(rc.x, rc.y, rc.width, rc.height); }
                    if (i == sel) { g.setColor(Color.WHITE); g.drawRect(rc.x, rc.y, rc.width - 1, rc.height - 1); g.drawRect(rc.x + 1, rc.y + 1, rc.width - 3, rc.height - 3); }
                    g.setFont(new Font("SansSerif", Font.BOLD, 18)); Ui.shadowText(g, s.name(), rc.x + 12, rc.y + 22, Color.WHITE);
                    g.setFont(new Font("SansSerif", Font.PLAIN, 13));
                    Ui.shadowText(g, "сид " + s.seed() + " · " + (s.creative() ? "Творчество" : "Выживание") + " · " + df.format(new Date(s.last())), rc.x + 12, rc.y + 42, new Color(170, 170, 170));
                }
                if (saves.isEmpty()) { g.setFont(new Font("SansSerif", Font.PLAIN, 16)); Ui.centerText(g, "Миров пока нет — создайте новый", cx, top + 60, Color.LIGHT_GRAY); }
                g.setClip(oldClip);
                int y1 = lh - 88, y2 = lh - 40;
                button(g, hostMode ? "Запустить сервер" : "Играть в выбранный мир", cx - 274, y1, 270, 40, sel >= 0, () -> startGame(saves.get(sel)));
                button(g, "Создать новый мир", cx + 4, y1, 270, 40, true, () -> { cName = ""; cSeed = ""; cFocus = 0; cCreative = false; state = CREATE; });
                button(g, confirmDel ? "Точно удалить?" : "Удалить", cx - 274, y2, 270, 40, sel >= 0, () -> {
                    if (!confirmDel) { confirmDel = true; return; }
                    saves.get(sel).delete(); confirmDel = false; refreshSaves();
                });
                button(g, "Назад", cx + 4, y2, 270, 40, true, () -> { hostMode = false; state = MAIN; });
            }
            case CREATE -> {
                title(g, "Создание нового мира", 40);
                g.setFont(new Font("SansSerif", Font.PLAIN, 14));
                Ui.shadowText(g, "Название мира", cx - 200, 104, new Color(190, 190, 190));
                Ui.field(g, fieldRect(0), cName, cFocus == 0);
                Ui.shadowText(g, "Сид генерации (пусто — случайный)", cx - 200, 184, new Color(190, 190, 190));
                Ui.field(g, fieldRect(1), cSeed, cFocus == 1);
                button(g, "Режим игры: " + (cCreative ? "Творчество" : "Выживание"), cx - 200, 262, 400, 40, true, () -> cCreative = !cCreative);
                g.setFont(new Font("SansSerif", Font.PLAIN, 13));
                Ui.centerText(g, cCreative ? "Бесконечные блоки, полёт, мгновенная добыча" : "Блоки добываются и тратятся", cx, 322, new Color(160, 160, 160));
                button(g, "Создать новый мир", cx - 200, lh - 90, 196, 40, true, this::createWorld);
                button(g, "Отмена", cx + 4, lh - 90, 196, 40, true, () -> state = WORLDS);
            }
            case DEAD -> {
                g.setFont(new Font("SansSerif", Font.BOLD, 44)); Ui.centerText(g, "Вы погибли!", cx, lh / 2 - 70, new Color(255, 255, 255));
                g.setFont(new Font("SansSerif", Font.PLAIN, 18)); Ui.centerText(g, p.cause, cx, lh / 2 - 36, new Color(255, 210, 210));
                g.setFont(new Font("SansSerif", Font.PLAIN, 14)); Ui.centerText(g, keepInv ? "Вещи сохранены" : "Вещи потеряны", cx, lh / 2 - 12, new Color(220, 190, 190));
                button(g, "Возродиться", cx - 150, lh / 2 + 10, 300, 40, true, this::respawn);
                button(g, "В главное меню", cx - 150, lh / 2 + 60, 300, 40, true, this::exitToMenu);
            }
            case SETTINGS -> {
                title(g, "Настройки", 44);
                int lx = cx - 204, rx = cx + 4, y = 84, dy = 48;
                g.setFont(new Font("SansSerif", Font.BOLD, 13)); Ui.centerText(g, "Графика", cx, y - 6, new Color(255, 230, 160));
                button(g, "Качество: " + QN[quality], lx, y, 200, 40, true, () -> { quality = (quality + 1) % 3; if (world != null) applyQuality(); saveSettings(); });
                button(g, "Дальность: " + VIEW[viewIdx] + " бл.", rx, y, 200, 40, true, () -> { viewIdx = (viewIdx + 1) % VIEW.length; if (r != null) r.viewDist = VIEW[viewIdx]; saveSettings(); });
                button(g, "Угол обзора: " + FOV[fovIdx] + "°", lx, y + dy, 200, 40, true, () -> { fovIdx = (fovIdx + 1) % FOV.length; if (r != null) r.setFov(FOV[fovIdx]); saveSettings(); });
                button(g, "FPS и координаты: " + (showInfo ? "Да" : "Нет"), rx, y + dy, 200, 40, true, () -> { showInfo = !showInfo; saveSettings(); });
                g.setFont(new Font("SansSerif", Font.BOLD, 13)); Ui.centerText(g, "Управление", cx, y + dy * 2 + 14, new Color(255, 230, 160));
                button(g, "Мышь: " + (int) (SENS[sensIdx] * 100) + "%", lx, y + dy * 2 + 20, 200, 40, true, () -> { sensIdx = (sensIdx + 1) % SENS.length; saveSettings(); });
                button(g, "Инверсия Y: " + (invertY ? "Да" : "Нет"), rx, y + dy * 2 + 20, 200, 40, true, () -> { invertY = !invertY; saveSettings(); });
                g.setFont(new Font("SansSerif", Font.BOLD, 13)); Ui.centerText(g, "Геймплей", cx, y + dy * 3 + 34, new Color(255, 230, 160));
                button(g, "Вещи при смерти: " + (keepInv ? "целы" : "теряем"), lx, y + dy * 3 + 40, 200, 40, true, () -> { keepInv = !keepInv; saveSettings(); });
                button(g, "Подсказки: " + (showHints ? "Да" : "Нет"), rx, y + dy * 3 + 40, 200, 40, true, () -> { showHints = !showHints; saveSettings(); });
                g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                Ui.centerText(g, "Качество — разрешение рендера; дальность и угол обзора настраиваются отдельно", cx, y + dy * 4 + 50, new Color(190, 190, 190));
                button(g, "Готово", cx - 200, lh - 70, 400, 40, true, () -> state = prevState);
            }
            case JOIN -> {
                title(g, "Подключение к серверу", 40);
                g.setFont(new Font("SansSerif", Font.PLAIN, 14));
                Ui.shadowText(g, "Ваш ник", cx - 200, 104, new Color(190, 190, 190));
                Ui.field(g, fieldRect(0), nick, joinFocus == 0);
                Ui.shadowText(g, "Адрес сервера (ip:порт, по умолчанию порт " + Net.DEFAULT_PORT + ")", cx - 200, 184, new Color(190, 190, 190));
                Ui.field(g, fieldRect(1), joinAddr, joinFocus == 1);
                if (!joinStatus.isEmpty()) { g.setFont(new Font("SansSerif", Font.BOLD, 14)); Ui.centerText(g, joinStatus, cx, 280, joinFailed ? new Color(255, 120, 120) : Color.WHITE); }
                button(g, "Подключиться", cx - 200, lh - 90, 196, 40, true, this::startJoin);
                button(g, "Отмена", cx + 4, lh - 90, 196, 40, true, () -> state = MAIN);
            }
            case JOINING -> {
                title(g, "Подключение", lh / 2 - 60);
                g.setFont(new Font("SansSerif", Font.PLAIN, 16)); Ui.centerText(g, joinStatus, cx, lh / 2 - 20, Color.WHITE);
                button(g, "Отмена", cx - 100, lh / 2 + 20, 200, 40, true, () -> { if (client != null) client.disconnect(); client = null; world = null; state = JOIN; });
            }
            case PAUSE -> {
                title(g, "Игра приостановлена", lh / 2 - 110);
                if (server != null || client != null) {
                    g.setFont(new Font("SansSerif", Font.PLAIN, 14));
                    if (server != null) {
                        if (localIps == null) localIps = localIps();
                        Ui.centerText(g, "Сервер: порт " + Net.DEFAULT_PORT + " · игроков " + (1 + remotes.size()) + " · адрес: " + String.join(", ", localIps), cx, lh / 2 - 84, new Color(180, 255, 180));
                    } else Ui.centerText(g, "Вы играете на чужом сервере · игроков " + (1 + remotes.size()), cx, lh / 2 - 84, new Color(180, 255, 180));
                }
                int y = lh / 2 - 80;
                button(g, "Вернуться к игре", cx - 200, y, 400, 40, true, () -> { state = PLAY; grab(true); });
                button(g, "Сохранить игру", cx - 200, y + 52, 400, 40, client == null, this::saveGame);
                button(g, "Настройки", cx - 200, y + 104, 400, 40, true, () -> { prevState = PAUSE; state = SETTINGS; });
                button(g, client != null ? "Отключиться" : server != null ? "Сохранить, остановить сервер и выйти" : "Сохранить и выйти в меню", cx - 200, y + 156, 400, 40, true, this::exitToMenu);
            }
            default -> { }
        }
    }

    void hud(Graphics2D g, int w, int h) {
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        if (showInfo) Ui.shadowText(g, String.format("XYZ %.1f %.1f %.1f  FPS %.0f  %s", p.x, p.y, p.z, fps, p.creative ? (p.flying ? "ПОЛЁТ" : "ТВОРЧЕСТВО") : "ВЫЖИВАНИЕ"), 10, 20, Color.WHITE);
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        if (showHints) Ui.shadowText(g, "[C] творчество  [E] инвентарь  [F5] сохранить  [F2] скриншот  [Esc] пауза", 10, 36, new Color(220, 220, 220));
        int sz = 44, x0 = w / 2 - sz * 9 / 2, y0 = h - sz - 10;
        for (int i = 0; i < 9; i++) {
            g.setColor(new Color(0, 0, 0, 140)); g.fillRect(x0 + i * sz, y0, sz - 2, sz - 2);
            g.setColor(i == p.selected ? Color.WHITE : Color.GRAY); g.drawRect(x0 + i * sz, y0, sz - 2, sz - 2);
            if (i == p.selected) g.drawRect(x0 + i * sz - 1, y0 - 1, sz, sz);
            if (p.cnt[i] > 0) icon(g, p.inv[i], x0 + i * sz + 4, y0 + 4, sz - 10, p.cnt[i]);
        }
        if (p.cnt[p.selected] > 0) { g.setFont(new Font("SansSerif", Font.BOLD, 14)); Ui.centerText(g, Blocks.nameOf(p.inv[p.selected]), w / 2, y0 - 22, Color.WHITE); }
        if (!p.creative) {
            for (int i = 0; i < 10; i++) {
                int hx = x0 + i * 16, hy = y0 - 30; int hv = p.health - i * 2;
                g.setColor(new Color(40, 0, 0, 200)); heart(g, hx - 1, hy - 1, 14);
                if (hv >= 2) { g.setColor(new Color(230, 30, 40)); heart(g, hx, hy, 12); }
                else if (hv == 1) { g.setColor(new Color(230, 30, 40)); Shape old = g.getClip(); g.clipRect(hx, hy, 6, 12); heart(g, hx, hy, 12); g.setClip(old); }
            }
            if (p.air < 10) for (int i = 0; i < (int) Math.ceil(p.air); i++) { g.setColor(new Color(170, 220, 255)); g.fillOval(x0 + 160 + 0 + i * 12 - 0 + 8, y0 - 48, 9, 9); g.setColor(Color.WHITE); g.drawOval(x0 + 168 + i * 12, y0 - 48, 9, 9); }
        }
        if (mine > 0 && mineX != -1) { double t = breakTime(world.get(mineX, mineY, mineZ)); g.setColor(Color.WHITE); g.fillRect(w / 2 - 30, h / 2 + 20, (int) (60 * Math.min(1, mine / Math.max(t, 1e-3))), 4); }
        if (toastT > 0) { g.setFont(new Font("SansSerif", Font.BOLD, 16)); Ui.centerText(g, toast, w / 2, 70, new Color(255, 255, 255, (int) Math.min(255, toastT * 255))); }
        if (server != null) Ui.shadowText(g, "Сервер :" + Net.DEFAULT_PORT + " · игроков " + (1 + remotes.size()), w - 220, 20, new Color(180, 255, 180));
        else if (client != null) Ui.shadowText(g, "Онлайн · игроков " + (1 + remotes.size()), w - 170, 20, new Color(180, 255, 180));
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        for (Remote rm : remotes) {
            double[] sp = r.toScreen(rm.x, rm.y + 2.3, rm.z); if (sp == null) continue;
            int sx = (int) (sp[0] * w / r.W), sy = (int) (sp[1] * h / r.H);
            g.setColor(new Color(0, 0, 0, 120)); int tw = g.getFontMetrics().stringWidth(rm.name); g.fillRect(sx - tw / 2 - 4, sy - 14, tw + 8, 18);
            Ui.centerText(g, rm.name, sx, sy, Color.WHITE);
        }
        if (targetMob != null) { String nm = targetMob.type == Mob.PIG ? "Свинья" : targetMob.type == Mob.FISH ? "Рыба" : "Зомби"; g.setFont(new Font("SansSerif", Font.BOLD, 14)); Ui.centerText(g, nm + "  " + (int) Math.ceil(targetMob.hp) + " HP", w / 2, h / 2 + 50, new Color(255, 230, 160)); }
        if (portalT > 0) { g.setColor(new Color(255, 170, 40, (int) Math.min(190, portalT / 1.6 * 190))); g.fillRect(0, 0, w, h); }
        if (world.dim == 1) Ui.shadowText(g, "Серное измерение", w - 150, 38, new Color(255, 190, 90));
        if (gui != 0) drawGui(g, w, h);
        if (!grabbed && gui == 0) Ui.shadowText(g, "Кликните, чтобы захватить мышь", w / 2 - 110, h / 2 - 40, Color.YELLOW);
    }
    void icon(Graphics2D g, int id, int x, int y, int s, int n) {
        Icons.draw(g, id, x, y, s);
        if (n > 1) { g.setFont(new Font("SansSerif", Font.BOLD, 12)); String t = "" + n; int tw = g.getFontMetrics().stringWidth(t);
            g.setColor(Color.BLACK); g.drawString(t, x + s - tw + 1, y + s + 1); g.setColor(Color.WHITE); g.drawString(t, x + s - tw, y + s); }
    }

    // ================= интерактивные блоки =================
    boolean interact() {
        if (r.hitFace < 0 || keys[KeyEvent.VK_SHIFT]) return false;
        int x = r.hitX, y = r.hitY, z = r.hitZ, id = world.get(x, y, z);
        if (id == Blocks.LEVER || id == Blocks.LEVER_ON) { world.set(x, y, z, id == Blocks.LEVER ? Blocks.LEVER_ON : Blocks.LEVER, 0, true); return true; }
        if (id == Blocks.CRAFT) { openGui(GUI_CRAFT); return true; }
        if (id == Blocks.FURNACE) {
            if (client != null) { toast("Печь доступна только на хосте"); return true; }
            furn = world.furnaces.computeIfAbsent(Fluid.pack(x, y, z), k -> new Furnace()); openGui(GUI_FURN); return true;
        }
        if (p.inv[p.selected] == Blocks.KEY && (id == Blocks.COAL_BLOCK || id == Blocks.DYNAMITE)) { lightPortal(x, y, z); return true; }
        return false;
    }

    // ================= GUI: инвентарь, верстак, печь =================
    void openGui(int kind) {
        gui = kind; lmb = false; mine = 0; grab(false);
    }
    void closeGui() { closeGui(true); }
    void closeGui(boolean regrab) {
        if (gui == 0) return;
        for (int i = 0; i < 9; i++) if (cgN[i] > 0) { p.add(cgId[i], cgN[i]); cgId[i] = 0; cgN[i] = 0; }
        if (curN > 0) { p.add(curId, curN); curId = 0; curN = 0; }
        gui = 0; furn = null; if (regrab && state == PLAY) grab(true);
    }
    int[] recipe() {
        if (gui == GUI_FURN) return null;
        int size = gui == GUI_CRAFT ? 3 : 2; int[] ids = new int[size * size];
        for (int i = 0; i < ids.length; i++) ids[i] = cgN[i] > 0 ? cgId[i] : 0;
        return Recipes.match(ids, size);
    }
    int sid(Slot s) {
        return switch (s.kind) { case 0 -> p.cnt[s.idx] > 0 ? p.inv[s.idx] : 0; case 1 -> cgN[s.idx] > 0 ? cgId[s.idx] : 0;
            case 2 -> { int[] r = recipe(); yield r == null ? 0 : r[0]; } case 3 -> furn.inN > 0 ? furn.inId : 0; case 4 -> furn.fuelN > 0 ? furn.fuelId : 0; default -> furn.outN > 0 ? furn.outId : 0; };
    }
    int sn(Slot s) {
        return switch (s.kind) { case 0 -> p.cnt[s.idx]; case 1 -> cgN[s.idx]; case 2 -> { int[] r = recipe(); yield r == null ? 0 : r[1]; } case 3 -> furn.inN; case 4 -> furn.fuelN; default -> furn.outN; };
    }
    void sset(Slot s, int id, int n) {
        if (n <= 0) { id = 0; n = 0; }
        switch (s.kind) {
            case 0 -> { p.inv[s.idx] = id; p.cnt[s.idx] = n; }
            case 1 -> { cgId[s.idx] = id; cgN[s.idx] = n; }
            case 3 -> { furn.inId = id; furn.inN = n; }
            case 4 -> { furn.fuelId = id; furn.fuelN = n; }
            case 5 -> { furn.outId = id; furn.outN = n; }
            default -> { }
        }
    }
    void guiClick(double x, double y, int btn) {
        for (Slot s : slots) if (s.r.contains(x, y)) {
            if (s.kind == 2) {
                int[] res = recipe(); if (res == null) return;
                if (curN == 0 || (curId == res[0] && curN + res[1] <= Blocks.stack(res[0]))) {
                    curId = res[0]; curN += res[1];
                    for (int i = 0; i < 9; i++) if (cgN[i] > 0 && (gui == GUI_CRAFT || i < 4)) { if (--cgN[i] == 0) cgId[i] = 0; }
                }
                return;
            }
            int id = sid(s), n = sn(s);
            if (s.kind == 5) { if (n > 0 && (curN == 0 || (curId == id && curN + n <= Blocks.stack(id)))) { curId = id; curN += n; sset(s, 0, 0); } return; }
            if (btn != 3) {
                if (curN == 0) { curId = id; curN = n; sset(s, 0, 0); }
                else if (n == 0) { sset(s, curId, curN); curId = 0; curN = 0; }
                else if (id == curId) { int mv = Math.min(Blocks.stack(id) - n, curN); sset(s, id, n + mv); curN -= mv; if (curN == 0) curId = 0; }
                else { sset(s, curId, curN); curId = id; curN = n; }
            } else {
                if (curN == 0) { int take = (n + 1) / 2; curId = id; curN = take; sset(s, id, n - take); if (curN == 0) curId = 0; }
                else if (n == 0) { sset(s, curId, 1); if (--curN == 0) curId = 0; }
                else if (id == curId && n < Blocks.stack(id)) { sset(s, id, n + 1); if (--curN == 0) curId = 0; }
                else { sset(s, curId, curN); curId = id; curN = n; }
            }
            return;
        }
    }
    void guiLayout(int w, int h) {
        slots.clear();
        int ox = w / 2 - 198, y1 = h / 2 - 10, y2 = y1 + 3 * 44 + 10;
        for (int i = 0; i < 27; i++) slots.add(new Slot(0, 9 + i, new Rectangle(ox + (i % 9) * 44, y1 + (i / 9) * 44, 40, 40)));
        for (int i = 0; i < 9; i++) slots.add(new Slot(0, i, new Rectangle(ox + i * 44, y2, 40, 40)));
        if (gui == GUI_INV) {
            for (int i = 0; i < 4; i++) slots.add(new Slot(1, i, new Rectangle(w / 2 + 10 + (i % 2) * 44, h / 2 - 130 + (i / 2) * 44, 40, 40)));
            slots.add(new Slot(2, 0, new Rectangle(w / 2 + 130, h / 2 - 108, 40, 40)));
        } else if (gui == GUI_CRAFT) {
            for (int i = 0; i < 9; i++) slots.add(new Slot(1, i, new Rectangle(w / 2 - 120 + (i % 3) * 44, h / 2 - 160 + (i / 3) * 44, 40, 40)));
            slots.add(new Slot(2, 0, new Rectangle(w / 2 + 60, h / 2 - 116, 40, 40)));
        } else if (gui == GUI_FURN) {
            slots.add(new Slot(3, 0, new Rectangle(w / 2 - 80, h / 2 - 150, 40, 40)));
            slots.add(new Slot(4, 0, new Rectangle(w / 2 - 80, h / 2 - 70, 40, 40)));
            slots.add(new Slot(5, 0, new Rectangle(w / 2 + 40, h / 2 - 110, 40, 40)));
        }
    }
    void drawGui(Graphics2D g, int w, int h) {
        guiLayout(w, h);
        Rectangle pn = new Rectangle(w / 2 - 216, h / 2 - 190, 432, 376);
        g.setColor(new Color(0, 0, 0, 150)); g.fillRect(0, 0, w, h);
        g.setColor(new Color(40, 40, 46, 245)); g.fillRect(pn.x, pn.y, pn.width, pn.height);
        g.setColor(new Color(150, 150, 160)); g.drawRect(pn.x, pn.y, pn.width - 1, pn.height - 1);
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        String ttl = gui == GUI_INV ? "Инвентарь" : gui == GUI_CRAFT ? "Верстак" : "Печь";
        Ui.shadowText(g, ttl, pn.x + 12, pn.y + 20, Color.WHITE);
        Ui.shadowText(g, "Инвентарь", pn.x + 12, h / 2 - 16, new Color(190, 190, 190));
        for (Slot s : slots) {
            Rectangle r = s.r; boolean hov = r.contains(mx, my);
            g.setColor(s.kind == 2 || s.kind == 5 ? new Color(70, 80, 50) : new Color(22, 22, 26)); g.fillRect(r.x, r.y, r.width, r.height);
            g.setColor(hov ? Color.WHITE : new Color(110, 110, 120)); g.drawRect(r.x, r.y, r.width - 1, r.height - 1);
            if (s.kind == 0 && s.idx == p.selected) { g.setColor(new Color(255, 230, 120)); g.drawRect(r.x - 1, r.y - 1, r.width + 1, r.height + 1); }
            int id = sid(s), n = sn(s);
            if (id != 0 && n > 0) icon(g, id, r.x + 4, r.y + 4, 32, n);
        }
        // стрелки / индикаторы
        g.setColor(new Color(200, 200, 210));
        if (gui == GUI_INV) { g.fillRect(w / 2 + 100, h / 2 - 90, 24, 6); }
        if (gui == GUI_CRAFT) { g.fillRect(w / 2 + 20, h / 2 - 98, 32, 6); }
        if (gui == GUI_FURN && furn != null) {
            double pr = Math.min(1, furn.progress / Furnace.SMELT_TIME);
            g.setColor(new Color(60, 60, 66)); g.fillRect(w / 2 - 20, h / 2 - 94, 50, 8); g.setColor(new Color(255, 190, 60)); g.fillRect(w / 2 - 20, h / 2 - 94, (int) (50 * pr), 8);
            int fh = furn.burnMax > 0 ? (int) (24 * Math.min(1, furn.burn / furn.burnMax)) : 0;
            g.setColor(new Color(60, 60, 66)); g.fillRect(w / 2 - 70 + 4, h / 2 - 104, 12, 24);
            g.setColor(new Color(255, 120, 30)); g.fillRect(w / 2 - 66, h / 2 - 104 + 24 - fh, 12, fh);
            g.setFont(new Font("SansSerif", Font.PLAIN, 12)); Ui.shadowText(g, "руда", w / 2 - 34, h / 2 - 122, new Color(190, 190, 190)); Ui.shadowText(g, "топливо", w / 2 - 34, h / 2 - 42, new Color(190, 190, 190));
        }
        // подсказка и предмет на курсоре
        for (Slot s : slots) if (s.r.contains(mx, my)) { int id = sid(s); if (id != 0 && curN == 0) { g.setFont(new Font("SansSerif", Font.BOLD, 13)); String nm = Blocks.nameOf(id);
            int tw = g.getFontMetrics().stringWidth(nm); g.setColor(new Color(10, 10, 20, 230)); g.fillRect(mx + 12, my - 4, tw + 12, 22); g.setColor(Color.WHITE); g.drawString(nm, mx + 18, my + 12); } }
        if (curN > 0) icon(g, curId, mx - 16, my - 16, 32, curN);
    }

    // ================= портал и измерения =================
    void applyDim() {
        if (r == null) return;
        boolean s = world != null && world.dim == 1;
        r.skyTopOv = s ? 0x1c0606 : -1; r.skyHorOv = s ? 0x5a2012 : -1; r.lightOv = s ? .62 : -1;
    }
    World ensureWorld(int dim) {
        if (dim == 0) return overworld;
        if (sulfur == null) { sulfur = new World(overworld.seed + 7919, save, 1); }
        return sulfur;
    }
    int[] findFrame(int x, int y, int z) {
        for (int axis = 0; axis < 2; axis++) for (int w0 = 0; w0 < 4; w0++) for (int h0 = 0; h0 < 7; h0++) {
            int ox = x - (axis == 0 ? w0 : 0), oy = y - h0, oz = z - (axis == 1 ? w0 : 0);
            if (oy < 1 || oy + 6 >= World.H) continue;
            boolean ok = true;
            for (int w = 0; w < 4 && ok; w++) for (int hh = 0; hh < 7 && ok; hh++) {
                int id = world.get(ox + (axis == 0 ? w : 0), oy + hh, oz + (axis == 1 ? w : 0));
                int need = (w == 0 || w == 3) ? Blocks.COAL_BLOCK : (hh == 0 || hh == 6) ? Blocks.DYNAMITE : -1;
                if (need >= 0 ? id != need : !(id == 0 || id == Blocks.PORTAL)) ok = false;
            }
            if (ok) return new int[]{ox, oy, oz, axis};
        }
        return null;
    }
    void lightPortal(int x, int y, int z) {
        if (server != null || client != null) { toast("Портал не работает в сетевой игре"); return; }
        int[] f = findFrame(x, y, z);
        if (f == null) { toast("Рама неверная: 4×7, по бокам угольные блоки, сверху и снизу динамит, внутри пусто"); return; }
        for (int w = 1; w <= 2; w++) for (int hh = 1; hh <= 5; hh++) world.set(f[0] + (f[3] == 0 ? w : 0), f[1] + hh, f[2] + (f[3] == 1 ? w : 0), Blocks.PORTAL);
        if (!p.creative) { if (--p.cnt[p.selected] <= 0) { p.cnt[p.selected] = 0; p.inv[p.selected] = 0; } }
        toast("Серный портал открыт");
    }
    void collapsePortals(int x, int y, int z) {
        for (int dx = -6; dx <= 6; dx++) for (int dy = -7; dy <= 7; dy++) for (int dz = -6; dz <= 6; dz++)
            if (world.get(x + dx, y + dy, z + dz) == Blocks.PORTAL) world.set(x + dx, y + dy, z + dz, 0);
    }
    void portalLogic(double dt) {
        int fx = (int) Math.floor(p.x), fy = (int) Math.floor(p.y + .1), fz = (int) Math.floor(p.z);
        boolean inP = world.get(fx, fy, fz) == Blocks.PORTAL || world.get(fx, fy + 1, fz) == Blocks.PORTAL;
        portalMsgT -= dt;
        if (needExit) { if (!inP) needExit = false; portalT = 0; return; }
        if (inP) {
            if (server != null || client != null) { if (portalMsgT <= 0) { toast("Портал не работает в сетевой игре"); portalMsgT = 5; } return; }
            portalT += dt; if (portalT > 1.6) travel();
        } else portalT = Math.max(0, portalT - dt * 2);
    }
    void travel() {
        int target = world.dim == 0 ? 1 : 0; World dest = ensureWorld(target);
        double[] pos = arrival(dest, (int) Math.floor(p.x), (int) Math.floor(p.z));
        world = dest; p.x = pos[0]; p.y = pos[1]; p.z = pos[2]; p.vx = p.vy = p.vz = 0;
        mobs.clear(); needExit = true; portalT = 0; mine = 0; applyDim();
        toast(target == 1 ? "Вы вошли в Серное измерение" : "Вы вернулись в Верхний мир");
        saveGame();
    }
    /** Находит ближайший портал в мире назначения или строит новый. */
    double[] arrival(World dest, int x, int z) {
        long best = -1; double bd = 64.0 * 64.0;
        for (long k : dest.portals) { int[] q = Fluid.unpack(k); double d = (q[0] - x) * (double) (q[0] - x) + (q[2] - z) * (double) (q[2] - z); if (d < bd) { bd = d; best = k; } }
        if (best >= 0) {
            int[] q = Fluid.unpack(best); int py = q[1]; while (dest.get(q[0], py - 1, q[2]) == Blocks.PORTAL) py--;
            boolean axisX = dest.get(q[0] + 1, py, q[2]) == Blocks.PORTAL || dest.get(q[0] - 1, py, q[2]) == Blocks.PORTAL;
            double[][] cand = axisX ? new double[][]{{q[0] + .5, q[2] + 2.5}, {q[0] + .5, q[2] - 1.5}} : new double[][]{{q[0] + 2.5, q[2] + .5}, {q[0] - 1.5, q[2] + .5}};
            for (double[] c : cand) if (!dest.solid((int) Math.floor(c[0]), py, (int) Math.floor(c[1])) && !dest.solid((int) Math.floor(c[0]), py + 1, (int) Math.floor(c[1])) && dest.solid((int) Math.floor(c[0]), py - 1, (int) Math.floor(c[1])))
                return new double[]{c[0], py, c[1]};
            return new double[]{q[0] + .5, py, q[2] + .5};
        }
        int gy = dest.dim == 0 ? Math.max(dest.surface(x, z) + 1, World.SEA + 2) : Math.max(dest.surface(x, z) + 1, World.LAVA_LEVEL + 3);
        gy = Math.max(3, Math.min(gy, World.H - 12)); int ox = x - 1, oz = z;
        for (int dx = -1; dx <= 4; dx++) for (int dz = -1; dz <= 4; dz++) {
            for (int dy = 0; dy < 8; dy++) dest.set(ox + dx, gy + dy, oz + dz, 0);
            if (!dest.solid(ox + dx, gy - 1, oz + dz)) dest.set(ox + dx, gy - 1, oz + dz, Blocks.SULFUR_STONE);
        }
        for (int w = 0; w < 4; w++) for (int hh = 0; hh < 7; hh++) dest.set(ox + w, gy + hh, oz, (w == 0 || w == 3) ? Blocks.COAL_BLOCK : (hh == 0 || hh == 6) ? Blocks.DYNAMITE : Blocks.PORTAL);
        return new double[]{ox + 2.0, gy, oz + 2.5};
    }

    // ================= динамит =================
    void tickDynamite(double dt) {
        if (world.primed.isEmpty()) return;
        List<Long> boom = new ArrayList<>();
        for (Map.Entry<Long, Double> e : world.primed.entrySet()) { e.setValue(e.getValue() - dt); if (e.getValue() <= 0) boom.add(e.getKey()); }
        for (long k : boom) { world.primed.remove(k); int[] q = Fluid.unpack(k); if (world.get(q[0], q[1], q[2]) == Blocks.DYNAMITE) explode(q[0] + .5, q[1] + .5, q[2] + .5, 3.6); }
    }
    void explode(double cx, double cy, double cz, double R) {
        int rr = (int) Math.ceil(R), bx = (int) Math.floor(cx), by = (int) Math.floor(cy), bz = (int) Math.floor(cz);
        for (int dx = -rr; dx <= rr; dx++) for (int dy = -rr; dy <= rr; dy++) for (int dz = -rr; dz <= rr; dz++) {
            double d2 = dx * dx + dy * dy + dz * dz; if (d2 > R * R) continue;
            int x = bx + dx, y = by + dy, z = bz + dz, id = world.get(x, y, z); if (id == 0 || y <= 0) continue;
            if (id == Blocks.PORTAL) { world.set(x, y, z, 0); continue; }
            if (id == Blocks.BEDROCK || id == Blocks.WATER || id == Blocks.LAVA) continue;
            if (Math.sqrt(d2) > R * .72 && Noise.h(x, y, z, 901) < .5) continue;
            if (id == Blocks.DYNAMITE) { world.primed.putIfAbsent(Fluid.pack(x, y, z), .25 + Noise.h(x, y, z, 902) * .4); continue; }
            if (id == Blocks.FURNACE) world.furnaces.remove(Fluid.pack(x, y, z));
            world.set(x, y, z, 0);
        }
        double dd = Math.sqrt((p.x - cx) * (p.x - cx) + (p.y + 1 - cy) * (p.y + 1 - cy) + (p.z - cz) * (p.z - cz));
        if (dd < R + 2 && !p.creative) p.hurt(Math.ceil((1 - dd / (R + 2)) * 14), "Вы взорвались");
        for (Remote rm : remotes) { double d = Math.sqrt((rm.x - cx) * (rm.x - cx) + (rm.y + 1 - cy) * (rm.y + 1 - cy) + (rm.z - cz) * (rm.z - cz)); if (d < R + 2 && server != null) server.sendDamage(rm, (int) Math.ceil((1 - d / (R + 2)) * 14)); }
        for (Mob m : mobs.mobs) { double d = Math.sqrt((m.x - cx) * (m.x - cx) + (m.y + .5 - cy) * (m.y + .5 - cy) + (m.z - cz) * (m.z - cz)); if (d < R + 2) { m.hp -= (1 - d / (R + 2)) * 40; m.hurt = .4; m.vy = 6; } }
        toast("Бабах!");
    }

    // ================= печи: сохранение =================
    void saveFurnaces() {
        if (save == null) return;
        StringBuilder sb = new StringBuilder();
        for (World w : new World[]{overworld, sulfur}) if (w != null) for (Map.Entry<Long, Furnace> e : w.furnaces.entrySet()) { int[] q = Fluid.unpack(e.getKey()); sb.append(w.dim).append(' ').append(q[0]).append(' ').append(q[1]).append(' ').append(q[2]).append(' ').append(e.getValue().serialize()).append('\n'); }
        try { java.nio.file.Files.writeString(new File(save.dir, "furnaces.txt").toPath(), sb.toString()); } catch (Exception e) { }
    }
    void loadFurnaces() {
        File f = new File(save.dir, "furnaces.txt"); if (!f.isFile()) return;
        try {
            for (String line : java.nio.file.Files.readAllLines(f.toPath())) {
                String[] t = line.trim().split(" "); if (t.length < 13) continue;
                int dim = Integer.parseInt(t[0]); World w = ensureWorld(dim);
                w.furnaces.put(Fluid.pack(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3])), Furnace.parse(t, 4));
            }
        } catch (Exception e) { }
    }

    static List<String> localIps() {
        List<String> out = new ArrayList<>();
        try { for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) { if (!ni.isUp() || ni.isLoopback()) continue;
            for (InetAddress a : Collections.list(ni.getInetAddresses())) if (a instanceof Inet4Address) out.add(a.getHostAddress()); } } catch (Exception e) { }
        if (out.isEmpty()) out.add("127.0.0.1"); return out;
    }
    void shot() { try { javax.imageio.ImageIO.write(img, "png", new File("screenshot.png")); } catch (Exception e) { } }

    public static void main(String[] a) throws Exception {
        if (a.length > 0 && a[0].equals("--headless")) { headless(a.length > 1 ? Integer.parseInt(a[1]) : 12345); return; }
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Voxel and Craft (Java)"); Game g = new Game();
            f.setContentPane(g); f.pack(); f.setLocationRelativeTo(null); f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            f.addWindowListener(new WindowAdapter() { public void windowClosing(WindowEvent e) { g.saveGame(); System.exit(0); } });
            f.setVisible(true);
        });
    }
    static void headless(int seed) throws Exception {
        long t0 = System.currentTimeMillis();
        World w = new World(seed); Player p = new Player(); Renderer r = new Renderer(640, 360);
        int[] sp = w.findSpawn(); p.x = sp[0] + .5; p.y = sp[1] + 2; p.z = sp[2] + .5; p.yaw = .6; p.pitch = -.25;
        for (int i = 0; i < 60; i++) p.update(w, .016, 0, 0, false, false);
        r.render(w, p, 1, 0, 0);
        BufferedImage im = new BufferedImage(640, 360, BufferedImage.TYPE_INT_RGB); im.setRGB(0, 0, 640, 360, r.px, 0, 640);
        javax.imageio.ImageIO.write(im, "png", new File("headless.png"));
        System.out.println("OK y=" + p.y + " ground=" + p.onGround + " ms=" + (System.currentTimeMillis() - t0));
    }
}
