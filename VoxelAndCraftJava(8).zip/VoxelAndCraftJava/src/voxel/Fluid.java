package voxel;

import java.util.*;

/**
 * Физика воды. meta: 0 — источник, 1..7 — растекающаяся (дальше от источника = больше),
 * 8 — падающая вода (над ней есть вода). Каждая клетка «подтягивает» своё состояние из соседей.
 */
final class Fluid {
    final World w;
    final LinkedHashMap<Long, Boolean> pending = new LinkedHashMap<>();
    static final int[][] H4 = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    static final int BUDGET = 600;

    Fluid(World w) { this.w = w; }

    static long pack(int x, int y, int z) { return ((long) (x + 8388608) << 40) | ((long) (y & 0xff) << 32) | (z + 8388608); }

    static int[] unpack(long k) { return new int[]{(int) (k >>> 40) - 8388608, (int) ((k >>> 32) & 0xff), (int) (k & 0xffffffL) - 8388608}; }

    void schedule(int x, int y, int z, boolean ext) {
        if (y < 0 || y >= World.H) return;
        pending.merge(pack(x, y, z), ext, (a, b) -> a || b);
    }
    void onChange(int x, int y, int z, boolean ext) {
        schedule(x, y, z, ext);
        schedule(x + 1, y, z, ext); schedule(x - 1, y, z, ext); schedule(x, y, z + 1, ext); schedule(x, y, z - 1, ext);
        schedule(x, y + 1, z, ext); schedule(x, y - 1, z, ext);
    }
    boolean active() { return !pending.isEmpty(); }

    void tick() {
        if (pending.isEmpty()) return;
        List<Map.Entry<Long, Boolean>> batch = new ArrayList<>();
        Iterator<Map.Entry<Long, Boolean>> it = pending.entrySet().iterator();
        while (it.hasNext() && batch.size() < BUDGET) { Map.Entry<Long, Boolean> e = it.next(); batch.add(Map.entry(e.getKey(), e.getValue())); it.remove(); }
        for (Map.Entry<Long, Boolean> e : batch) {
            long k = e.getKey();
            int x = (int) (k >>> 40) - 8388608, y = (int) ((k >>> 32) & 0xff), z = (int) (k & 0xffffffL) - 8388608;
            update(x, y, z, e.getValue());
        }
    }

    boolean canSpread(int x, int y, int z) {
        int below = w.get(x, y - 1, z);
        return Blocks.solid[below] || (below == Blocks.WATER && w.getMeta(x, y - 1, z) == 0) || y == 0;
    }

    void update(int x, int y, int z, boolean ext) {
        int id = w.get(x, y, z);
        boolean water = id == Blocks.WATER;
        if (id != 0 && !water) return;
        if (water) {
            if (ext) for (int[] d : H4) schedule(x + d[0], y, z + d[1], false);
            if (y > 0 && w.get(x, y - 1, z) == 0) schedule(x, y - 1, z, false);
            if (w.getMeta(x, y, z) == 0) return; // источник
        }
        int desired;
        if (w.get(x, y + 1, z) == Blocks.WATER) desired = 8;
        else {
            int best = 8;
            for (int[] d : H4) {
                int nx = x + d[0], nz = z + d[1];
                if (w.get(nx, y, nz) != Blocks.WATER) continue;
                int m = w.getMeta(nx, y, nz), eff = m == 8 ? 0 : m;
                if (canSpread(nx, y, nz) && eff + 1 <= 7) best = Math.min(best, eff + 1);
            }
            desired = best <= 7 ? best : -1;
        }
        if (desired == -1) { if (water) w.set(x, y, z, 0, 0, false); }
        else if (!water || w.getMeta(x, y, z) != desired) w.set(x, y, z, Blocks.WATER, desired, false);
    }
}
