package voxel;

/**
 * Жадное слияние граней (Greedy Meshing): соседние одинаковые видимые грани
 * одного блока и одного освещения объединяются в один большой прямоугольник.
 */
final class Mesher {
    static final int[] SIZE = {16, World.H, 16};

    static Mesh build(World w, int cx, int cz) {
        Mesh m = new Mesh();
        byte[] c = w.chunk(cx, cz); short[] top = w.top(cx, cz);
        int bx = cx * 16, bz = cz * 16;
        int[] base = {bx, 0, bz};
        byte[] mt = w.metas.get(World.key(cx, cz)); byte[] oc = null;
        int[] mask = new int[16 * World.H], p = new int[3];
        for (int d = 0; d < 6; d++) {
            int ax = d >> 1, sgn = (d & 1) == 0 ? 1 : -1;
            int a = ax == 0 ? 2 : 0, b = ax == 1 ? 2 : 1;
            int N = SIZE[ax], NA = SIZE[a], NB = SIZE[b];
            for (int s = 0; s < N; s++) {
                boolean any = false;
                for (int j = 0; j < NB; j++) for (int i = 0; i < NA; i++) {
                    p[ax] = s; p[a] = i; p[b] = j;
                    int id = c[p[1] * 256 + p[2] * 16 + p[0]] & 0xff, key = 0;
                    if (id != 0 && (Blocks.shaped[id] || (id == Blocks.WATER && mt != null && flow(mt[p[1] * 256 + p[2] * 16 + p[0]] & 0xff)))) id = 0;
                    if (id != 0) {
                        int nx = p[0] + (ax == 0 ? sgn : 0), ny = p[1] + (ax == 1 ? sgn : 0), nz = p[2] + (ax == 2 ? sgn : 0), nid;
                        if (ny < 0) nid = Blocks.BEDROCK; else if (ny >= World.H) nid = 0;
                        else if (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) nid = c[ny * 256 + nz * 16 + nx] & 0xff;
                        else nid = w.get(bx + nx, ny, bz + nz);
                        boolean vis = nid == 0 || (Blocks.seeThrough(nid) && nid != id) || Blocks.shaped[nid];
                        if (!vis && id == Blocks.WATER && nid == Blocks.WATER && ny >= 0 && ny < World.H) {
                            int nm = (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) ? (mt == null ? 0 : mt[ny * 256 + nz * 16 + nx] & 0xff) : w.getMeta(bx + nx, ny, bz + nz);
                            vis = flow(nm);
                        }
                        if (vis) {
                            boolean sh = false;
                            if (ny >= 0 && ny < World.H) {
                                short[] t = (nx >= 0 && nx < 16 && nz >= 0 && nz < 16) ? top : w.top(Math.floorDiv(bx + nx, 16), Math.floorDiv(bz + nz, 16));
                                sh = ny <= t[((bz + nz) & 15) * 16 + ((bx + nx) & 15)];
                            }
                            int cls = 0;
                            if (id == Blocks.WATER && w.dim == 0) { if (oc == null) { oc = new byte[256]; for (int q = 0; q < 256; q++) oc[q] = (byte) w.ocean(bx + (q & 15), bz + (q >> 4)); } cls = oc[p[2] * 16 + p[0]]; }
                            key = id | (sh ? 256 : 0) | 512 | (cls << 10); any = true;
                        }
                    }
                    mask[j * NA + i] = key;
                }
                if (!any) continue;
                for (int j = 0; j < NB; j++) for (int i = 0; i < NA; i++) {
                    int k = mask[j * NA + i]; if (k == 0) continue;
                    int ww = 1; while (i + ww < NA && mask[j * NA + i + ww] == k) ww++;
                    int hh = 1;
                    outer:
                    while (j + hh < NB) { for (int q = 0; q < ww; q++) if (mask[(j + hh) * NA + i + q] != k) break outer; hh++; }
                    for (int y = 0; y < hh; y++) for (int q = 0; q < ww; q++) mask[(j + y) * NA + i + q] = 0;
                    int id = k & 255;
                    Mesh.IntList L = Blocks.alpha[id] < 1 ? m.tr : m.op;
                    L.add(d); L.add(base[ax] + s + (sgn > 0 ? 1 : 0)); L.add(base[a] + i); L.add(base[b] + j);
                    L.add(ww); L.add(hh); L.add(id); L.add(((k & 256) != 0 ? 1 : 0) | (((k >> 10) & 3) << 1));
                }
            }
        }
        shapes(w, c, mt, top, cx, cz, m);
        return m;
    }
    static boolean flow(int meta) { return meta >= 1 && meta <= 7; }
    static boolean occl(int id) { return Blocks.solid[id] && !Blocks.shaped[id] && Blocks.alpha[id] >= 1 && !Blocks.cutout[id]; }

    /** Грани неполных блоков: плит, ступенек и растекающейся воды (уровень падает с расстоянием от источника). */
    static void shapes(World w, byte[] c, byte[] mt, short[] top, int cx, int cz, Mesh m) {
        int bx0 = cx * 16, bz0 = cz * 16;
        for (int y = 0; y < World.H; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            int idx = y * 256 + z * 16 + x, id = c[idx] & 0xff; if (id == 0) continue;
            int meta = mt == null ? 0 : mt[idx] & 0xff;
            boolean water = id == Blocks.WATER && flow(meta);
            if (!water && !Blocks.shaped[id]) continue;
            int wx = bx0 + x, wz = bz0 + z;
            double[][] bs = water ? new double[][]{{0, 0, 0, 1, World.waterH(meta), 1}} : World.boxes(id, meta);
            double shade = y < top[z * 16 + x] ? .62 : 1.0, al = Blocks.alpha[id] * 256;
            for (double[] b : bs) {
                double x0 = wx + b[0], y0 = y + b[1], z0 = wz + b[2], x1 = wx + b[3], y1 = y + b[4], z1 = wz + b[5], dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
                for (int f = 0; f < 6; f++) {
                    boolean edge = switch (f) { case 0 -> b[3] >= 1; case 1 -> b[0] <= 0; case 2 -> b[4] >= 1 && !water; case 3 -> b[1] <= 0; case 4 -> b[5] >= 1; default -> b[2] <= 0; };
                    if (water && f == 2) edge = true;
                    if (edge) {
                        int nx = wx + (f == 0 ? 1 : f == 1 ? -1 : 0), ny = y + (f == 2 ? 1 : f == 3 ? -1 : 0), nz = wz + (f == 4 ? 1 : f == 5 ? -1 : 0);
                        int nid = w.get(nx, ny, nz);
                        if (occl(nid)) continue;
                        if (water) {
                            if (nid == Blocks.WATER) { if (f == 2 || f == 3) continue; if (World.waterH(w.getMeta(nx, ny, nz)) >= b[4]) continue; }
                        } else if (nid == id && meta == w.getMeta(nx, ny, nz) && !Blocks.shaped[id]) continue;
                    }
                    switch (f) {
                        case 0 -> m.sh.add(x1, y0, z0, 0, dy, 0, 0, 0, dz, id, al, shade);
                        case 1 -> m.sh.add(x0, y0, z0, 0, 0, dz, 0, dy, 0, id, al, shade);
                        case 2 -> m.sh.add(x0, y1, z0, 0, 0, dz, dx, 0, 0, id, al, shade);
                        case 3 -> m.sh.add(x0, y0, z0, dx, 0, 0, 0, 0, dz, id, al, shade);
                        case 4 -> m.sh.add(x0, y0, z1, dx, 0, 0, 0, dy, 0, id, al, shade);
                        default -> m.sh.add(x0, y0, z0, 0, dy, 0, dx, 0, 0, id, al, shade);
                    }
                }
            }
        }
    }
}
