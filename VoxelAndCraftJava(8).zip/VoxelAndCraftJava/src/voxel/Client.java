package voxel;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Клиент: подключается к хосту, получает мир/блоки/игроков/мобов и рисует их там, где сказал сервер. */
final class Client implements Net.Handler {
    final Game game; final ConcurrentLinkedQueue<Runnable> inbox = new ConcurrentLinkedQueue<>();
    Net.Link link; int myId = -1; double tPos; volatile boolean closedByUs;

    Client(Game g) { game = g; }

    /** Подключение в отдельном потоке, чтобы окно не зависало. */
    void connectAsync(String host, int port, String nick) {
        Thread t = new Thread(() -> {
            try {
                Socket s = new Socket(); s.connect(new InetSocketAddress(host, port), 5000);
                link = new Net.Link(s, inbox, this);
                link.send(Net.frame(Net.HELLO, o -> { o.writeInt(Net.PROTOCOL); o.writeUTF(nick); }));
                game.joinStatus = "Подключено. Загрузка мира...";
            } catch (Exception e) { game.joinStatus = "Не удалось подключиться: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()); game.joinFailed = true; }
        }, "net-connect"); t.setDaemon(true); t.start();
    }
    void disconnect() { closedByUs = true; if (link != null) link.close(); }
    boolean connected() { return link != null && link.alive; }

    public void handle(Net.Link l, int type, DataInputStream in) throws IOException {
        switch (type) {
            case Net.WELCOME -> { myId = in.readInt(); int seed = in.readInt(); double time = in.readDouble(), x = in.readDouble(), y = in.readDouble(), z = in.readDouble(); boolean cr = in.readBoolean(); game.clientWelcome(seed, time, x, y, z, cr); }
            case Net.CHUNKDIFF -> { int cx = in.readInt(), cz = in.readInt(), n = in.readInt(); int[] d = new int[n]; for (int i = 0; i < n; i++) d[i] = in.readInt(); if (game.world != null) game.world.applyDiff(cx, cz, d); }
            case Net.DIFFDONE -> game.clientReady();
            case Net.BLOCKS -> {
                int n = in.readInt();
                for (int i = 0; i < n; i++) { int x = in.readInt(), y = in.readInt(), z = in.readInt(), id = in.readUnsignedByte(), meta = in.readUnsignedByte();
                    if (game.world != null) { game.world.quiet = true; game.world.set(x, y, z, id, meta, false); game.world.quiet = false; } }
            }
            case Net.PLAYERS -> {
                int n = in.readInt(); Map<Integer, Remote> old = new HashMap<>(); for (Remote r : game.remotes) old.put(r.id, r);
                List<Remote> now = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    int id = in.readInt(); String name = in.readUTF(); double x = in.readFloat(), y = in.readFloat(), z = in.readFloat(), yaw = in.readFloat(), pitch = in.readFloat();
                    if (id == myId) continue;
                    Remote r = old.get(id); if (r == null) { r = new Remote(); r.id = id; }
                    r.name = name; r.setTarget(x, y, z, yaw, pitch); now.add(r);
                }
                game.remotes.clear(); game.remotes.addAll(now);
            }
            case Net.MOBS -> game.mobs.readSnapshot(in);
            case Net.TIME -> game.time = in.readDouble();
            case Net.DAMAGE -> { int d = in.readInt(); if (!game.p.creative) game.p.hurt(d); }
            case Net.KICK -> { String why = in.readUTF(); closedByUs = true; game.onDisconnected(why); }
            default -> { }
        }
    }
    public void closed(Net.Link l) { if (!closedByUs) game.onDisconnected("Соединение потеряно"); }

    void tick(double dt) {
        for (int i = 0; i < 400; i++) { Runnable r = inbox.poll(); if (r == null) break; r.run(); }
        tPos += dt;
        if (tPos >= .05 && connected() && game.state == Game.PLAY) {
            tPos = 0; Player p = game.p;
            link.send(Net.frame(Net.POS, o -> { o.writeFloat((float) p.x); o.writeFloat((float) p.y); o.writeFloat((float) p.z); o.writeFloat((float) p.yaw); o.writeFloat((float) p.pitch); }));
        }
    }
    void sendBlock(int[] a) { if (connected()) link.send(Net.frame(Net.BLOCK, o -> { o.writeInt(a[0]); o.writeInt(a[1]); o.writeInt(a[2]); o.writeByte(a[3]); o.writeByte(a[4]); })); }
    void sendAttack(int mobId, double dmg, double kx, double kz) { if (connected()) link.send(Net.frame(Net.ATTACK, o -> { o.writeInt(mobId); o.writeFloat((float) dmg); o.writeFloat((float) kx); o.writeFloat((float) kz); })); }
}
