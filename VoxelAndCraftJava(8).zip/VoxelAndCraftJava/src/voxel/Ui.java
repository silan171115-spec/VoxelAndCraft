package voxel;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/** Элементы интерфейса в стиле классических кубических игр: кнопки с фасками, пиксельный логотип из камня, фон из земли. */
final class Ui {
    static final String[] GLYPH_KEYS = "ACDEFLNORTVX&_".split("");
    static final Map<Character, String[]> G = new HashMap<>();
    static {
        g('A', "01110", "10001", "10001", "11111", "10001", "10001", "10001");
        g('C', "01111", "10000", "10000", "10000", "10000", "10000", "01111");
        g('D', "11110", "10001", "10001", "10001", "10001", "10001", "11110");
        g('E', "11111", "10000", "10000", "11110", "10000", "10000", "11111");
        g('F', "11111", "10000", "10000", "11110", "10000", "10000", "10000");
        g('L', "10000", "10000", "10000", "10000", "10000", "10000", "11111");
        g('N', "10001", "11001", "10101", "10011", "10001", "10001", "10001");
        g('O', "01110", "10001", "10001", "10001", "10001", "10001", "01110");
        g('R', "11110", "10001", "10001", "11110", "10100", "10010", "10001");
        g('T', "11111", "00100", "00100", "00100", "00100", "00100", "00100");
        g('V', "10001", "10001", "10001", "10001", "10001", "01010", "00100");
        g('X', "10001", "10001", "01010", "00100", "01010", "10001", "10001");
        g(' ', "000", "000", "000", "000", "000", "000", "000");
    }
    static void g(char c, String... rows) { G.put(c, rows); }

    static BufferedImage dirtTile, logoImg; static int logoScale;
    static BufferedImage dirtTile() {
        if (dirtTile == null) {
            dirtTile = new BufferedImage(16, 16, BufferedImage.TYPE_INT_RGB);
            for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) dirtTile.setRGB(x, y, Textures.mul(Textures.get(Blocks.DIRT, 1, x, y), .38));
        }
        return dirtTile;
    }
    static void dirtBackground(Graphics2D g, int w, int h) {
        BufferedImage t = dirtTile(); int s = 64;
        for (int y = 0; y < h; y += s) for (int x = 0; x < w; x += s) g.drawImage(t, x, y, s, s, null);
    }
    static void darkenStrip(Graphics2D g, int x, int y, int w, int h) {
        g.setColor(new Color(0, 0, 0, 140)); g.fillRect(x, y, w, h);
        g.setPaint(new GradientPaint(0, y, new Color(0, 0, 0, 200), 0, y + 6, new Color(0, 0, 0, 0))); g.fillRect(x, y, w, 6);
        g.setPaint(new GradientPaint(0, y + h - 6, new Color(0, 0, 0, 0), 0, y + h, new Color(0, 0, 0, 200))); g.fillRect(x, y + h - 6, w, 6);
    }

    static void shadowText(Graphics2D g, String s, int x, int y, Color c) {
        g.setColor(new Color(0, 0, 0, 170)); g.drawString(s, x + 2, y + 2); g.setColor(c); g.drawString(s, x, y);
    }
    static void centerText(Graphics2D g, String s, int cx, int y, Color c) {
        shadowText(g, s, cx - g.getFontMetrics().stringWidth(s) / 2, y, c);
    }

    static void button(Graphics2D g, Rectangle r, String label, boolean hover, boolean enabled) {
        Color base = !enabled ? new Color(70, 70, 70) : hover ? new Color(122, 134, 190) : new Color(112, 112, 112);
        g.setColor(Color.BLACK); g.fillRect(r.x, r.y, r.width, r.height);
        g.setColor(base); g.fillRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4);
        g.setColor(!enabled ? new Color(100, 100, 100) : hover ? new Color(176, 188, 240) : new Color(168, 168, 168)); g.fillRect(r.x + 2, r.y + 2, r.width - 4, 2); g.fillRect(r.x + 2, r.y + 2, 2, r.height - 4);
        g.setColor(!enabled ? new Color(45, 45, 45) : hover ? new Color(70, 78, 130) : new Color(66, 66, 66)); g.fillRect(r.x + 2, r.y + r.height - 4, r.width - 4, 2); g.fillRect(r.x + r.width - 4, r.y + 2, 2, r.height - 4);
        g.setFont(new Font("SansSerif", Font.BOLD, 16));
        FontMetrics fm = g.getFontMetrics();
        centerText(g, label, r.x + r.width / 2, r.y + (r.height + fm.getAscent() - fm.getDescent()) / 2 - 1, !enabled ? new Color(150, 150, 150) : hover ? new Color(255, 255, 160) : Color.WHITE);
    }

    static void field(Graphics2D g, Rectangle r, String text, boolean focus) {
        g.setColor(focus ? Color.WHITE : new Color(160, 160, 160)); g.fillRect(r.x, r.y, r.width, r.height);
        g.setColor(Color.BLACK); g.fillRect(r.x + 2, r.y + 2, r.width - 4, r.height - 4);
        g.setFont(new Font("SansSerif", Font.PLAIN, 16)); g.setColor(Color.WHITE);
        FontMetrics fm = g.getFontMetrics();
        g.drawString(text + (focus && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : ""), r.x + 8, r.y + (r.height + fm.getAscent() - fm.getDescent()) / 2);
    }

    /** Логотип: пиксельные буквы, залитые текстурой камня, с фасками и тенью. Возвращает высоту. */
    static int logo(Graphics2D g, String text, int cx, int y, int maxW) {
        int cells = 0; for (char ch : text.toCharArray()) cells += G.get(ch)[0].length() + 1; cells--;
        int s = Math.max(2, Math.min(10, maxW / cells));
        if (logoImg == null || logoScale != s) {
            logoScale = s;
            int w = cells * s, h = 7 * s;
            BufferedImage im = new BufferedImage(w + s, h + s, BufferedImage.TYPE_INT_ARGB);
            int x0 = 0;
            for (char ch : text.toCharArray()) {
                String[] rows = G.get(ch);
                for (int ry = 0; ry < 7; ry++) for (int rx = 0; rx < rows[ry].length(); rx++) if (rows[ry].charAt(rx) == '1') {
                    for (int py = 0; py < s; py++) for (int pxl = 0; pxl < s; pxl++) {
                        int X = (x0 + rx) * s + pxl, Y = ry * s + py;
                        int c = Textures.get(Blocks.STONE, 1, (X / 2) & 15, (Y / 2) & 15);
                        c = Textures.mul(c, 1.25);
                        if (py < Math.max(1, s / 5) || pxl < Math.max(1, s / 5)) c = Textures.add(c, 40);
                        else if (py >= s - Math.max(1, s / 5) || pxl >= s - Math.max(1, s / 5)) c = Textures.mul(c, .55);
                        im.setRGB(X, Y, 0xff000000 | c);
                    }
                }
                x0 += rows[0].length() + 1;
            }
            // тень
            BufferedImage out = new BufferedImage(w + s, h + s, BufferedImage.TYPE_INT_ARGB);
            for (int Y = 0; Y < h + s; Y++) for (int X = 0; X < w + s; X++) {
                int sx = X - s / 2, sy = Y - s / 2;
                int a = im.getRGB(X, Y);
                if ((a >>> 24) != 0) out.setRGB(X, Y, a);
                else if (sx >= 0 && sy >= 0 && sx < w + s && sy < h + s && (im.getRGB(sx, sy) >>> 24) != 0) out.setRGB(X, Y, 0xaa000000);
            }
            logoImg = out;
        }
        g.drawImage(logoImg, cx - logoImg.getWidth() / 2, y, null);
        return logoImg.getHeight();
    }
}
