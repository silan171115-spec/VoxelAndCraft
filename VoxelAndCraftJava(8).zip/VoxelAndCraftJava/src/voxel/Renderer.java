package voxel;

import java.util.*;
import java.util.stream.IntStream;

/**
 * Программный растеризатор мешей чанков (после Greedy Meshing) с z-буфером.
 * Каждый объединённый прямоугольник рисуется аналитическим пересечением луча с плоскостью.
 * Прозрачные грани (вода, стекло, лёд) рисуются после непрозрачных, от дальних к ближним.
 */
public final class Renderer {
    /** Сущность, умеющая нарисовать себя набором граней (мобы, другие игроки). */
    public interface Renderable { void emit(Renderer r); }
    double[] eq = new double[20 * 512]; int enq; public double hitDist;
    public final int W, H;
    public final int[] px;
    public int hitX, hitY, hitZ, hitFace = -1, prevX, prevY, prevZ;
    public double reach = 6;
    public int viewDist = 64;
    public int lastQuads;
    /** Переопределение неба и освещения (для измерений без смены дня и ночи). */
    public int skyTopOv = -1, skyHorOv = -1; public double lightOv = -1;
    static final double RL = 9;
    final double[] lampX = new double[12], lampY = new double[12], lampZ = new double[12]; int nl;
    final Mesh.IntList ol = new Mesh.IntList();

    final double[] dX, dY, dZ, zb;
    double tanH = Math.tan(Math.toRadians(35)); final double asp;
    /** Вертикальный угол обзора в градусах. */
    public void setFov(double deg) { tanH = Math.tan(Math.toRadians(deg / 2)); }
    final int[] fog = new int[258];
    static final double NEAR = .05;
    static final double[] DIRF = {.8, .8, 1, .5, .65, .65};

    final Mesh.IntList oq = new Mesh.IntList(), ob = new Mesh.IntList(), tq = new Mesh.IntList(), tb = new Mesh.IntList();
    double ex, ey, ez; int uwFlag, lightQ, skyH;
    final double[] sx = new double[8], sy = new double[8], sz = new double[8], tx = new double[8], ty = new double[8], tz = new double[8];
    double fx, fy, fz, rx, rz, ux, uy, uz;

    public Renderer(int w, int h) {
        W = w; H = h; px = new int[w * h]; asp = (double) w / h;
        dX = new double[w * h]; dY = new double[w * h]; dZ = new double[w * h]; zb = new double[w * h];
    }
    static int mix(int a, int b, double t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t), g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public void render(World w, Player p, double day, double mine, double time) { render(w, p, day, mine, time, Collections.emptyList()); }

    public void render(World w, Player p, double day, double mine, double time, List<? extends Renderable> ents) {
        ex = p.x; ey = p.eyeY(); ez = p.z;
        double cy = Math.cos(p.yaw), sy_ = Math.sin(p.yaw), cp = Math.cos(p.pitch), sp = Math.sin(p.pitch);
        fx = -sy_ * cp; fy = sp; fz = -cy * cp; rx = cy; rz = -sy_; ux = sy_ * sp; uy = cp; uz = cy * sp;
        final boolean uw = w.get((int) Math.floor(ex), (int) Math.floor(ey), (int) Math.floor(ez)) == Blocks.WATER;
        final int skyTop = skyTopOv >= 0 ? skyTopOv : Textures.rgb(40 + 95 * day, 70 + 135 * day, 110 + 140 * day), skyHor = skyHorOv >= 0 ? skyHorOv : Textures.rgb(60 + 130 * day, 80 + 140 * day, 120 + 120 * day);
        final int fogCol = uw ? 0x1c3f7a : skyHor;
        final double light = lightOv >= 0 ? lightOv : .25 + .75 * day;
        for (int i = 0; i <= 256; i++) fog[i] = (int) (256 * Math.min(1, Math.pow(i / 256.0, 2.2)));
        // лучи + небо
        IntStream.range(0, H).parallel().forEach(j -> {
            double v = (1 - 2.0 * (j + .5) / H) * tanH;
            for (int i = 0; i < W; i++) {
                double u = (2.0 * (i + .5) / W - 1) * tanH * asp;
                double dx = fx + rx * u + ux * v, dy = fy + uy * v, dz = fz + rz * u + uz * v;
                double l = Math.sqrt(dx * dx + dy * dy + dz * dz); dx /= l; dy /= l; dz /= l;
                int q = j * W + i; dX[q] = dx; dY[q] = dy; dZ[q] = dz; zb[q] = 1e30;
                px[q] = uw ? fogCol : mix(skyHor, skyTop, Math.max(0, Math.min(1, dy * 2)));
            }
        });
        // подготовка мешей
        int pcx = Math.floorDiv((int) Math.floor(ex), 16), pcz = Math.floorDiv((int) Math.floor(ez), 16), R = viewDist / 16 + 2;
        List<int[]> missing = new ArrayList<>();
        for (int dz = -R; dz <= R; dz++) for (int dx = -R; dx <= R; dx++) {
            long k = World.key(pcx + dx, pcz + dz);
            boolean dirty = w.dirty.contains(k);
            if (dirty || !w.meshes.containsKey(k)) missing.add(new int[]{pcx + dx, pcz + dz, dirty ? -1 : dx * dx + dz * dz});
        }
        missing.sort(Comparator.comparingInt(m -> m[2]));
        List<int[]> todo = missing.subList(0, Math.min(missing.size(), 24));
        for (int[] m : todo) w.dirty.remove(World.key(m[0], m[1]));
        todo.parallelStream().forEach(m -> w.meshes.put(World.key(m[0], m[1]), Mesher.build(w, m[0], m[1])));
        // сбор квадов
        oq.n = ob.n = tq.n = tb.n = ol.n = 0; enq = 0;
        // ближайшие горящие лампы
        nl = 0;
        if (!w.lights.isEmpty()) {
            List<double[]> ls = new ArrayList<>();
            for (long k : w.lights) { int[] q = Fluid.unpack(k); double d2 = (q[0] + .5 - ex) * (q[0] + .5 - ex) + (q[1] + .5 - ey) * (q[1] + .5 - ey) + (q[2] + .5 - ez) * (q[2] + .5 - ez); if (d2 < 40 * 40) ls.add(new double[]{d2, q[0] + .5, q[1] + .5, q[2] + .5}); }
            ls.sort(Comparator.comparingDouble(a -> a[0]));
            for (int i = 0; i < Math.min(12, ls.size()); i++) { lampX[i] = ls.get(i)[1]; lampY[i] = ls.get(i)[2]; lampZ[i] = ls.get(i)[3]; nl++; }
        }
        double maxD = viewDist + 24; int[] bb = new int[4];
        for (int dz = -R; dz <= R; dz++) for (int dx = -R; dx <= R; dx++) {
            int cx = pcx + dx, cz = pcz + dz;
            double ddx = cx * 16 + 8 - ex, ddz = cz * 16 + 8 - ez;
            if (ddx * ddx + ddz * ddz > maxD * maxD) continue;
            Mesh m = w.meshes.get(World.key(cx, cz)); if (m == null) continue;
            gather(m.op, oq, ob, ol, bb, true); gather(m.tr, tq, tb, null, bb, false);
            for (int o = 0; o < m.sh.n; o += 12) { double[] a = m.sh.a; tquad(a[o], a[o + 1], a[o + 2], a[o + 3], a[o + 4], a[o + 5], a[o + 6], a[o + 7], a[o + 8], (int) a[o + 9], (int) a[o + 10], a[o + 11]); }
        }
        int shapesN = enq; enq = shapesN; for (Renderable e : ents) e.emit(this);
        lastQuads = oq.n / 8 + tq.n / 8;
        // сортировка прозрачных: дальние первыми
        int nt = tq.n / 8; long[] order = new long[nt];
        for (int i = 0; i < nt; i++) {
            int o = i * 8, d = tq.a[o], ax = d >> 1, a = ax == 0 ? 2 : 0, b = ax == 1 ? 2 : 1;
            double[] c = {0, 0, 0}; c[ax] = tq.a[o + 1]; c[a] = tq.a[o + 2] + tq.a[o + 4] * .5; c[b] = tq.a[o + 3] + tq.a[o + 5] * .5;
            double dd = Math.sqrt((c[0] - ex) * (c[0] - ex) + (c[1] - ey) * (c[1] - ey) + (c[2] - ez) * (c[2] - ez));
            order[i] = ((long) (dd * 64) << 20) | i;
        }
        Arrays.sort(order);
        final int[] sortedIdx = new int[nt];
        for (int i = 0; i < nt; i++) sortedIdx[i] = (int) (order[nt - 1 - i] & 0xfffff);
        final int bands = (H + 15) / 16;
        IntStream.range(0, bands).parallel().forEach(bi -> {
            int j0 = bi * 16, j1 = Math.min(H, j0 + 16), n = oq.n / 8;
            for (int i = 0; i < n; i++) drawQuad(oq.a, ob.a, i, j0, j1, false, light, uw, fogCol, ol.a[i]);
            for (int i = 0; i < enq; i++) drawEnt(i, j0, j1, light, uw, fogCol, false);
        });
        IntStream.range(0, bands).parallel().forEach(bi -> {
            int j0 = bi * 16, j1 = Math.min(H, j0 + 16);
            for (int k = 0; k < nt; k++) drawQuad(tq.a, tb.a, sortedIdx[k], j0, j1, true, light, uw, fogCol, 0);
            for (int i = 0; i < enq; i++) drawEnt(i, j0, j1, light, uw, fogCol, true);
        });
        pick(w, fx, fy, fz);
        int cxm = W / 2, cym = H / 2;
        for (int k = -3; k <= 3; k++) { px[cym * W + cxm + k] ^= 0xffffff; if (k != 0) px[(cym + k) * W + cxm] ^= 0xffffff; }
    }

    void gather(Mesh.IntList src, Mesh.IntList dq, Mesh.IntList db, Mesh.IntList lm, int[] bb, boolean cull) {
        for (int o = 0; o < src.n; o += 8) {
            int d = src.a[o], plane = src.a[o + 1];
            if (cull) {
                int ax = d >> 1; double e = ax == 0 ? ex : ax == 1 ? ey : ez;
                if ((d & 1) == 0 ? e < plane : e > plane) continue;
            }
            if (!project(src.a, o, bb)) continue;
            for (int k = 0; k < 8; k++) dq.add(src.a[o + k]);
            if (lm != null) {
                int mask = 0;
                if (nl > 0) {
                    int ax = d >> 1, a = ax == 0 ? 2 : 0, b = ax == 1 ? 2 : 1; double sgn = (d & 1) == 0 ? 1 : -1;
                    double a0 = src.a[o + 2], a1 = a0 + src.a[o + 4], b0 = src.a[o + 3], b1 = b0 + src.a[o + 5];
                    for (int l = 0; l < nl; l++) {
                        double[] lc = {lampX[l], lampY[l], lampZ[l]};
                        double dp = lc[ax] - plane, da = Math.max(a0, Math.min(a1, lc[a])) - lc[a], dbb = Math.max(b0, Math.min(b1, lc[b])) - lc[b];
                        if (dp * sgn > -.01 && dp * dp + da * da + dbb * dbb < RL * RL) mask |= 1 << l;
                    }
                }
                lm.add(mask);
            }
            db.add(bb[0]); db.add(bb[1]); db.add(bb[2]); db.add(bb[3]);
        }
    }

    boolean project(int[] q, int o, int[] bb) {
        int d = q[o], ax = d >> 1, a = ax == 0 ? 2 : 0, b = ax == 1 ? 2 : 1;
        int a0 = q[o + 2], b0 = q[o + 3], a1 = a0 + q[o + 4], b1 = b0 + q[o + 5];
        double[] c = new double[3];
        int[] ca = {a0, a1, a1, a0}, cb = {b0, b0, b1, b1};
        for (int k = 0; k < 4; k++) {
            c[ax] = q[o + 1]; c[a] = ca[k]; c[b] = cb[k];
            double rxx = c[0] - ex, ryy = c[1] - ey, rzz = c[2] - ez;
            sz[k] = rxx * fx + ryy * fy + rzz * fz; sx[k] = rxx * rx + rzz * rz; sy[k] = rxx * ux + ryy * uy + rzz * uz;
        }
        return clipBox(bb);
    }

    boolean clipBox(int[] bb) {
        int m = 0;
        for (int k = 0; k < 4; k++) {
            int n = (k + 1) & 3; boolean ik = sz[k] >= NEAR, in = sz[n] >= NEAR;
            if (ik) { tx[m] = sx[k]; ty[m] = sy[k]; tz[m] = sz[k]; m++; }
            if (ik != in) { double t = (NEAR - sz[k]) / (sz[n] - sz[k]); tx[m] = sx[k] + (sx[n] - sx[k]) * t; ty[m] = sy[k] + (sy[n] - sy[k]) * t; tz[m] = NEAR; m++; }
        }
        if (m < 3) return false;
        double minX = 1e30, maxX = -1e30, minY = 1e30, maxY = -1e30;
        for (int k = 0; k < m; k++) {
            double X = (tx[k] / tz[k] / (tanH * asp) + 1) * .5 * W, Y = (1 - ty[k] / tz[k] / tanH) * .5 * H;
            minX = Math.min(minX, X); maxX = Math.max(maxX, X); minY = Math.min(minY, Y); maxY = Math.max(maxY, Y);
        }
        int i0 = (int) Math.max(0, Math.floor(minX) - 1), i1 = (int) Math.min(W - 1, Math.ceil(maxX) + 1);
        int j0 = (int) Math.max(0, Math.floor(minY) - 1), j1 = (int) Math.min(H - 1, Math.ceil(maxY) + 1);
        if (i0 > i1 || j0 > j1) return false;
        bb[0] = i0; bb[1] = i1; bb[2] = j0; bb[3] = j1; return true;
    }

    void drawQuad(int[] q, int[] bbs, int idx, int bj0, int bj1, boolean trans, double light, boolean uw, int fogCol, int lmask) {
        int o = idx * 8, bo = idx * 4;
        int j0 = Math.max(bbs[bo + 2], bj0), j1 = Math.min(bbs[bo + 3], bj1 - 1);
        if (j0 > j1) return;
        int i0 = bbs[bo], i1 = bbs[bo + 1];
        int d = q[o], ax = d >> 1, a = ax == 0 ? 2 : 0, b = ax == 1 ? 2 : 1, id = q[o + 6];
        double plane = q[o + 1], a0 = q[o + 2] - 1e-4, b0 = q[o + 3] - 1e-4, a1 = q[o + 2] + q[o + 4] + 1e-4, b1 = q[o + 3] + q[o + 5] + 1e-4;
        double[] dA = ax == 0 ? dX : ax == 1 ? dY : dZ, da = a == 0 ? dX : a == 1 ? dY : dZ, db = b == 0 ? dX : b == 1 ? dY : dZ;
        double eAx = ax == 0 ? ex : ax == 1 ? ey : ez, ea = a == 0 ? ex : a == 1 ? ey : ez, eb = b == 0 ? ex : b == 1 ? ey : ez;
        double fl = DIRF[d] * (Blocks.glow[id] ? 1.2 : light) * ((q[o + 7] & 1) != 0 && !Blocks.glow[id] ? .55 : 1);
        int sh = (int) (fl * 256), tf = d == 2 ? 0 : d == 3 ? 2 : 1, al = (int) (Blocks.alpha[id] * 256);
        boolean sideY = ax != 1;
        int wc = id == Blocks.WATER ? (q[o + 7] >> 1) & 3 : 0, tr = wc == 1 ? 150 : wc == 2 ? 135 : 256, tg = wc == 1 ? 195 : wc == 2 ? 292 : 256, tbl = wc == 1 ? 245 : wc == 2 ? 275 : 256;
        int fr = (fogCol >> 16) & 255, fg = (fogCol >> 8) & 255, fb = fogCol & 255;
        double invView = 256.0 / viewDist;
        for (int j = j0; j <= j1; j++) {
            int row = j * W;
            for (int i = i0; i <= i1; i++) {
                int pi = row + i; double dn = dA[pi]; if (dn == 0) continue;
                double t = (plane - eAx) / dn;
                if (t <= 0 || t >= zb[pi]) continue;
                double pa = ea + t * da[pi]; if (pa < a0 || pa >= a1) continue;
                double pb = eb + t * db[pi]; if (pb < b0 || pb >= b1) continue;
                int u = (int) (pa * 16 + 1048576) & 15, v = (int) (pb * 16 + 1048576) & 15;
                if (sideY) v = 15 - v;
                int col = Textures.T[id][tf][v * 16 + u]; if (col < 0) continue;
                int r = Math.min(255, (((col >> 16) & 255) * sh * tr) >> 16), g = Math.min(255, (((col >> 8) & 255) * sh * tg) >> 16), bl = Math.min(255, ((col & 255) * sh * tbl) >> 16);
                if (lmask != 0) {
                    double acc = 0; double[] hc = new double[3]; hc[ax] = plane; hc[a] = pa; hc[b] = pb;
                    for (int l = 0; l < nl; l++) if ((lmask >> l & 1) != 0) {
                        double ddx = lampX[l] - hc[0], ddy = lampY[l] - hc[1], ddz = lampZ[l] - hc[2], dist = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
                        if (dist < RL) { double lf = 1 - dist / RL; acc += lf * lf; }
                    }
                    if (acc > 0) { acc = Math.min(1.1, acc); r = Math.min(255, r + (int) (acc * 235)); g = Math.min(255, g + (int) (acc * 185)); bl = Math.min(255, bl + (int) (acc * 100)); }
                }
                int f = uw ? Math.min(256, (int) (t / 24 * 256)) : fog[Math.min(256, (int) (t * invView))];
                r += ((fr - r) * f) >> 8; g += ((fg - g) * f) >> 8; bl += ((fb - bl) * f) >> 8;
                if (trans) {
                    int dst = px[pi], dr = (dst >> 16) & 255, dg = (dst >> 8) & 255, dbb = dst & 255;
                    r = dr + (((r - dr) * al) >> 8); g = dg + (((g - dg) * al) >> 8); bl = dbb + (((bl - dbb) * al) >> 8);
                } else zb[pi] = t;
                px[pi] = (r << 16) | (g << 8) | bl;
            }
        }
    }


    static final double LX = .35 / .9, LY = .8 / .9, LZ = .45 / .9;
    /** Добавляет грань сущности. A x B * sign — внешняя нормаль. detail — особый узор (глаза и т.п.). */
    public void quad(double ox, double oy, double oz, double ax, double ay, double az, double bx, double by, double bz, int color, int detail, double sign) {
        double nx = (ay * bz - az * by) * sign, ny = (az * bx - ax * bz) * sign, nz = (ax * by - ay * bx) * sign;
        double nl = Math.sqrt(nx * nx + ny * ny + nz * nz); if (nl < 1e-9) return; nx /= nl; ny /= nl; nz /= nl;
        if ((ex - ox) * nx + (ey - oy) * ny + (ez - oz) * nz <= 0) return;
        double[] px_ = {ox, ox + ax, ox + ax + bx, ox + bx}, py_ = {oy, oy + ay, oy + ay + by, oy + by}, pz_ = {oz, oz + az, oz + az + bz, oz + bz};
        for (int k = 0; k < 4; k++) {
            double rxx = px_[k] - ex, ryy = py_[k] - ey, rzz = pz_[k] - ez;
            sz[k] = rxx * fx + ryy * fy + rzz * fz; sx[k] = rxx * rx + rzz * rz; sy[k] = rxx * ux + ryy * uy + rzz * uz;
        }
        int[] bb = new int[4]; if (!clipBox(bb)) return;
        if ((enq + 1) * 20 > eq.length) eq = Arrays.copyOf(eq, eq.length * 2);
        int o = enq++ * 20;
        eq[o] = ox; eq[o + 1] = oy; eq[o + 2] = oz; eq[o + 3] = ax; eq[o + 4] = ay; eq[o + 5] = az; eq[o + 6] = bx; eq[o + 7] = by; eq[o + 8] = bz;
        eq[o + 9] = nx; eq[o + 10] = ny; eq[o + 11] = nz; eq[o + 12] = color; eq[o + 13] = detail;
        double sh = .5 + .5 * (nx * LX + ny * LY + nz * LZ); eq[o + 14] = Math.max(.5, Math.min(1.05, sh));
        eq[o + 15] = bb[0]; eq[o + 16] = bb[1]; eq[o + 17] = bb[2]; eq[o + 18] = bb[3];
    }

    static boolean dark(int detail, double s, double r) {
        switch (detail) {
            case 1: return r > .42 && r < .62 && ((s > .15 && s < .3) || (s > .7 && s < .85));
            case 2: return r > .35 && r < .68 && ((s > .22 && s < .4) || (s > .6 && s < .78));
            case 3: return (r > .5 && r < .68 && ((s > .12 && s < .36) || (s > .64 && s < .88))) || (r > .14 && r < .3 && s > .3 && s < .7);
            case 4: return r > .42 && r < .6 && ((s > .15 && s < .35) || (s > .65 && s < .85));
            default: return false;
        }
    }

    /** Текстурированная грань неполного блока (плита, ступенька, вода пониженного уровня). Нормаль = A x B. */
    public void tquad(double ox, double oy, double oz, double ax, double ay, double az, double bx, double by, double bz, int id, int alpha, double shade) {
        int before = enq;
        quad(ox, oy, oz, ax, ay, az, bx, by, bz, id, -1, 1);
        if (enq == before) return;
        int o = before * 20; eq[o + 14] *= shade; eq[o + 19] = alpha;
    }

    void drawEnt(int idx, int bj0, int bj1, double light, boolean uw, int fogCol, boolean transPass) {
        int o = idx * 20;
        boolean tex = eq[o + 13] < 0; int alpha = tex ? (int) eq[o + 19] : 256;
        if ((alpha < 256) != transPass) return;
        int i0 = (int) eq[o + 15], i1 = (int) eq[o + 16], j0 = Math.max((int) eq[o + 17], bj0), j1 = Math.min((int) eq[o + 18], bj1 - 1);
        if (j0 > j1) return;
        double ox = eq[o], oy = eq[o + 1], oz = eq[o + 2], ax = eq[o + 3], ay = eq[o + 4], az = eq[o + 5], bx = eq[o + 6], by = eq[o + 7], bz = eq[o + 8];
        double nx = eq[o + 9], ny = eq[o + 10], nz = eq[o + 11];
        double aa = ax * ax + ay * ay + az * az, bb2 = bx * bx + by * by + bz * bz;
        int col = (int) eq[o + 12], detail = (int) eq[o + 13];
        double num = nx * (ox - ex) + ny * (oy - ey) + nz * (oz - ez);
        int sh = (int) (eq[o + 14] * Math.max(.35, light) * 256);
        int fr = (fogCol >> 16) & 255, fg = (fogCol >> 8) & 255, fb = fogCol & 255; double invView = 256.0 / viewDist;
        for (int j = j0; j <= j1; j++) {
            int row = j * W;
            for (int i = i0; i <= i1; i++) {
                int pi = row + i;
                double den = nx * dX[pi] + ny * dY[pi] + nz * dZ[pi]; if (den >= -1e-9) continue;
                double t = num / den; if (t <= 0 || t >= zb[pi]) continue;
                double hx = ex + t * dX[pi] - ox, hy = ey + t * dY[pi] - oy, hz = ez + t * dZ[pi] - oz;
                double s = (hx * ax + hy * ay + hz * az) / aa, rr = (hx * bx + hy * by + hz * bz) / bb2;
                if (s < 0 || s >= 1 || rr < 0 || rr >= 1) continue;
                int c = col;
                if (tex) {
                    double wx = ox + hx, wy = oy + hy, wz = oz + hz; int tf = ny > .5 ? 0 : ny < -.5 ? 2 : 1, u, v;
                    if (tf != 1) { u = (int) Math.floor((wx - Math.floor(wx)) * 16); v = (int) Math.floor((wz - Math.floor(wz)) * 16); }
                    else { double hh = Math.abs(nx) > .5 ? wz : wx; u = (int) Math.floor((hh - Math.floor(hh)) * 16); v = 15 - (int) Math.floor((wy - Math.floor(wy)) * 16); }
                    c = Textures.T[col][tf][(v & 15) * 16 + (u & 15)]; if (c < 0) continue;
                } else
                if (detail != 0 && dark(detail, s, rr)) c = detail == 4 ? 0x2a3a8a : 0x1a1a1a;
                else { int nz_ = (((int) (s * 6) * 7 + (int) (rr * 6) * 13 + o) & 7) - 3; c = Textures.add(c, nz_ * 2.5); }
                int r = Math.min(255, (((c >> 16) & 255) * sh) >> 8), g = Math.min(255, (((c >> 8) & 255) * sh) >> 8), bl = Math.min(255, ((c & 255) * sh) >> 8);
                int f = uw ? Math.min(256, (int) (t / 24 * 256)) : fog[Math.min(256, (int) (t * invView))];
                r += ((fr - r) * f) >> 8; g += ((fg - g) * f) >> 8; bl += ((fb - bl) * f) >> 8;
                if (alpha < 256) { int dst = px[pi], dr = (dst >> 16) & 255, dg = (dst >> 8) & 255, dbb = dst & 255; r = dr + (((r - dr) * alpha) >> 8); g = dg + (((g - dg) * alpha) >> 8); bl = dbb + (((bl - dbb) * alpha) >> 8); px[pi] = (r << 16) | (g << 8) | bl; continue; }
                zb[pi] = t; px[pi] = (r << 16) | (g << 8) | bl;
            }
        }
    }

    /** Проекция мировой точки на экран рендера (в пикселях W x H) или null, если точка сзади. */
    public double[] toScreen(double x, double y, double z) {
        double rxx = x - ex, ryy = y - ey, rzz = z - ez;
        double cz = rxx * fx + ryy * fy + rzz * fz; if (cz < .1) return null;
        double cx = rxx * rx + rzz * rz, cy = rxx * ux + ryy * uy + rzz * uz;
        return new double[]{(cx / cz / (tanH * asp) + 1) * .5 * W, (1 - cy / cz / tanH) * .5 * H};
    }

    /** Луч выбора блока (DDA) — только для прицела, не для отрисовки. */
    void pick(World w, double dx, double dy, double dz) {
        double l = Math.sqrt(dx * dx + dy * dy + dz * dz); dx /= l; dy /= l; dz /= l;
        int mx = (int) Math.floor(ex), my = (int) Math.floor(ey), mz = (int) Math.floor(ez), lx = mx, ly = my, lz = mz, face = 0;
        double ddx = dx == 0 ? 1e30 : Math.abs(1 / dx), ddy = dy == 0 ? 1e30 : Math.abs(1 / dy), ddz = dz == 0 ? 1e30 : Math.abs(1 / dz);
        int stx = dx < 0 ? -1 : 1, sty = dy < 0 ? -1 : 1, stz = dz < 0 ? -1 : 1;
        double tX = (dx < 0 ? ex - mx : mx + 1 - ex) * ddx, tY = (dy < 0 ? ey - my : my + 1 - ey) * ddy, tZ = (dz < 0 ? ez - mz : mz + 1 - ez) * ddz, t;
        hitFace = -1; hitDist = 1e30;
        while (true) {
            lx = mx; ly = my; lz = mz;
            if (tX < tY && tX < tZ) { t = tX; tX += ddx; mx += stx; face = 2; }
            else if (tY < tZ) { t = tY; tY += ddy; my += sty; face = sty > 0 ? 3 : 0; }
            else { t = tZ; tZ += ddz; mz += stz; face = 1; }
            if (t > reach) return;
            int id = w.get(mx, my, mz);
            if (id == 0 || id == Blocks.WATER || id == Blocks.LAVA) continue;
            hitX = mx; hitY = my; hitZ = mz; prevX = lx; prevY = ly; prevZ = lz; hitFace = face; hitDist = t; return;
        }
    }
}
