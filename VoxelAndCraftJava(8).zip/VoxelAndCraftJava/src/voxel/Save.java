package voxel;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Сохранение мира: saves/<папка>/level.properties + chunks/<cx>_<cz>.bin (только изменённые чанки, gzip). */
final class Save {
    static final File ROOT = new File("saves");
    final File dir;
    final Properties info = new Properties();

    Save(File dir) { this.dir = dir; }

    String name() { return info.getProperty("name", dir.getName()); }
    int seed() { return Integer.parseInt(info.getProperty("seed", "0")); }
    long last() { return Long.parseLong(info.getProperty("last", "0")); }
    boolean creative() { return Boolean.parseBoolean(info.getProperty("creative", "false")); }
    boolean hasPlayer() { return info.containsKey("x"); }

    static final String[] RU = {"a","b","v","g","d","e","yo","zh","z","i","y","k","l","m","n","o","p","r","s","t","u","f","h","c","ch","sh","sch","","y","","e","yu","ya"};
    /** Имя папки только из латиницы/цифр — надёжно на любой ОС и кодировке. */
    static String slug(String name) {
        StringBuilder sb = new StringBuilder();
        for (char ch : name.toLowerCase().toCharArray()) {
            if (ch >= 'a' && ch <= 'z' || ch >= '0' && ch <= '9' || ch == '_' || ch == '-') sb.append(ch);
            else if (ch >= '\u0430' && ch <= '\u044f') sb.append(RU[ch - '\u0430']);
            else if (ch == '\u0451') sb.append("yo");
            else if (ch == ' ') sb.append('_');
        }
        return sb.length() > 24 ? sb.substring(0, 24) : sb.toString();
    }
    static List<Save> list() {
        List<Save> out = new ArrayList<>();
        File[] fs = ROOT.listFiles();
        if (fs != null) for (File f : fs) {
            File lv = new File(f, "level.properties");
            if (!lv.isFile()) continue;
            Save s = new Save(f);
            try (Reader r = new InputStreamReader(new FileInputStream(lv), StandardCharsets.UTF_8)) { s.info.load(r); out.add(s); } catch (Exception e) { }
        }
        out.sort((a, b) -> Long.compare(b.last(), a.last()));
        return out;
    }
    static Save create(String name, int seed, boolean creative) {
        String base = slug(name); if (base.isEmpty()) base = "world";
        File d = new File(ROOT, base); int i = 2;
        while (d.exists()) d = new File(ROOT, base + "_" + i++);
        d.mkdirs(); new File(d, "chunks").mkdirs();
        Save s = new Save(d);
        s.info.setProperty("name", name.isBlank() ? "Новый мир" : name); s.info.setProperty("seed", "" + seed);
        s.info.setProperty("creative", "" + creative); s.info.setProperty("last", "" + System.currentTimeMillis());
        s.flush(); return s;
    }
    void flush() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(new File(dir, "level.properties")), StandardCharsets.UTF_8)) { info.store(w, "Voxel and Craft"); } catch (IOException e) { e.printStackTrace(); }
    }
    void delete() { del(dir); }
    static void del(File f) { File[] c = f.listFiles(); if (c != null) for (File x : c) del(x); f.delete(); }

    static String chunkDirName(int dim) { return dim == 0 ? "chunks" : "chunks_d" + dim; }
    File chunkFile(int dim, int cx, int cz) { return new File(dir, chunkDirName(dim) + "/" + cx + "_" + cz + ".bin"); }
    void writeChunk(int dim, int cx, int cz, byte[] ids, byte[] meta) {
        new File(dir, chunkDirName(dim)).mkdirs();
        try (DataOutputStream o = new DataOutputStream(new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(chunkFile(dim, cx, cz)))))) {
            o.write(ids); o.write(meta);
        } catch (IOException e) { e.printStackTrace(); }
    }
    /** @return {ids, meta} или null */
    byte[][] readChunk(int dim, int cx, int cz) {
        File f = chunkFile(dim, cx, cz); if (!f.isFile()) return null;
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(new BufferedInputStream(new FileInputStream(f))))) {
            byte[] ids = new byte[16 * 16 * World.H], meta = new byte[ids.length];
            in.readFully(ids); in.readFully(meta); return new byte[][]{ids, meta};
        } catch (IOException e) { return null; }
    }
    void writePlayer(Player p, double time, boolean flying) {
        info.setProperty("x", "" + p.x); info.setProperty("y", "" + p.y); info.setProperty("z", "" + p.z);
        info.setProperty("yaw", "" + p.yaw); info.setProperty("pitch", "" + p.pitch); info.setProperty("health", "" + p.health);
        info.setProperty("creative", "" + p.creative); info.setProperty("flying", "" + flying); info.setProperty("time", "" + time);
        info.setProperty("sel", "" + p.selected); info.setProperty("last", "" + System.currentTimeMillis());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 36; i++) sb.append(p.inv[i]).append(':').append(p.cnt[i]).append(i < 35 ? "," : "");
        info.setProperty("inv", sb.toString());
        flush();
    }
    void readPlayer(Player p) {
        p.x = d("x", 0); p.y = d("y", 80); p.z = d("z", 0); p.yaw = d("yaw", 0); p.pitch = d("pitch", 0);
        p.health = Math.max(1, (int) d("health", 20)); p.creative = creative(); p.flying = Boolean.parseBoolean(info.getProperty("flying", "false"));
        p.selected = (int) d("sel", 0);
        String inv = info.getProperty("inv");
        if (inv != null) { String[] t = inv.split(","); for (int i = 0; i < Math.min(36, t.length); i++) { String[] a = t[i].split(":"); p.inv[i] = Integer.parseInt(a[0]); p.cnt[i] = Integer.parseInt(a[1]); } }
    }
    double d(String k, double def) { try { return Double.parseDouble(info.getProperty(k)); } catch (Exception e) { return def; } }
}
