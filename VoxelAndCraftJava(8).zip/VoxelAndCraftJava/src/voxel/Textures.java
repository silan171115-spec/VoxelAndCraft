package voxel;

/** Процедурные текстуры 16x16 в духе классических кубических игр: [блок][грань 0=верх,1=бок,2=низ][256]. */
final class Textures {
    static final int[][][] T = new int[Blocks.NB][3][];

    static int rgb(double r, double g, double b) { return (cl(r) << 16) | (cl(g) << 8) | cl(b); }
    static int cl(double v) { return (int) Math.max(0, Math.min(255, v)); }
    static int r(int c) { return (c >> 16) & 255; }
    static int g(int c) { return (c >> 8) & 255; }
    static int b(int c) { return c & 255; }
    static int mul(int c, double f) { return rgb(r(c) * f, g(c) * f, b(c) * f); }
    static int add(int c, double d) { return rgb(r(c) + d, g(c) + d, b(c) + d); }
    static int lerp(int a, int c, double t) { return rgb(r(a) + (r(c) - r(a)) * t, g(a) + (g(c) - g(a)) * t, b(a) + (b(c) - b(a)) * t); }
    static double n(int x, int y, int s) { return Noise.t(((x % 16) + 16) % 16, ((y % 16) + 16) % 16, s); }

    /** Базовая заливка: шум + мягкие пятна. */
    static int[] make(int br, int bg, int bb, double var, int seed) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double d = (n(x, y, seed) - .5) * var + (Noise.tn(x, y, 4, seed + 5) - .5) * var * .9 + (Noise.tn(x, y, 8, seed + 9) - .5) * var * .5;
            p[y * 16 + x] = rgb(br + d, bg + d, bb + d);
        }
        return p;
    }
    /** Ячейки Вороного: возвращает {id ячейки, расстояние до границы}. */
    static double[] vor(int x, int y, int cells, int seed) {
        double cs = 16.0 / cells, best = 1e9, second = 1e9, id = 0;
        for (int gy = -1; gy <= cells; gy++) for (int gx = -1; gx <= cells; gx++) {
            int wx = ((gx % cells) + cells) % cells, wy = ((gy % cells) + cells) % cells;
            double fx = (gx + .15 + .7 * Noise.t(wx, wy, seed)) * cs, fy = (gy + .15 + .7 * Noise.t(wx, wy, seed + 1)) * cs;
            double d = Math.hypot(x + .5 - fx, y + .5 - fy);
            if (d < best) { second = best; best = d; id = wy * cells + wx; } else if (d < second) second = d;
        }
        return new double[]{id, second - best};
    }
    static void set(int id, int[] all) { T[id][0] = T[id][1] = T[id][2] = all; }

    static int[] stone(int seed) {
        int[] p = make(128, 128, 128, 26, seed);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double q = n(x, y, seed + 20);
            if (q < .08) p[y * 16 + x] = add(p[y * 16 + x], -26); else if (q > .94) p[y * 16 + x] = add(p[y * 16 + x], 18);
        }
        return p;
    }
    static int[] cobble() {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double[] v = vor(x, y, 4, 61);
            double sh = 108 + 38 * Noise.t((int) v[0], 1, 62) + (n(x, y, 63) - .5) * 20;
            if (v[1] < 1.6) sh = 62 + v[1] * 10; else if (v[1] < 2.6) sh += 10;
            p[y * 16 + x] = rgb(sh, sh, sh);
        }
        return p;
    }
    static int[] dirt() {
        int[] p = make(124, 88, 60, 24, 2);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double q = n(x, y, 3);
            if (q < .07) p[y * 16 + x] = rgb(86, 60, 40); else if (q > .955) p[y * 16 + x] = rgb(150, 150, 140); else if (q > .9) p[y * 16 + x] = rgb(150, 108, 76);
        }
        return p;
    }
    static int[] grassTop(int seed, int br, int bg, int bb) {
        int[] p = make(br, bg, bb, 30, seed);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double q = n(x, y, seed + 30);
            if (q < .12) p[y * 16 + x] = mul(p[y * 16 + x], .82); else if (q > .88) p[y * 16 + x] = add(mul(p[y * 16 + x], 1.1), 8);
        }
        return p;
    }
    static int[] ore(int col, int hi, int seed) {
        int[] p = stone(1);
        for (int k = 0; k < 4; k++) {
            int cx = 2 + (int) (n(k, 0, seed) * 12), cy = 2 + (int) (n(k, 1, seed) * 12);
            int[][] sh = {{0, 0}, {1, 0}, {0, 1}, {1, 1}, {-1, 0}, {0, -1}};
            for (int i = 0; i < 4 + (int) (n(k, 2, seed) * 2); i++) {
                int x = cx + sh[i][0], y = cy + sh[i][1];
                if (x < 0 || y < 0 || x > 15 || y > 15) continue;
                p[y * 16 + x] = (i == 0) ? hi : (i == 3 ? mul(col, .7) : col);
            }
        }
        return p;
    }
    static int[] planks(int br, int bg, int bb, int seed) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int board = y / 4; double off = Noise.t(board, 0, seed) * 16;
            double grain = Noise.tn((int) (x + off) & 15, y * 3 & 15, 8, seed + 2) - .5;
            double sh = 1 + grain * .28 + (Noise.t(board, 5, seed) - .5) * .18;
            int c = rgb(br * sh, bg * sh, bb * sh);
            if (y % 4 == 3) c = mul(c, .68); else if (y % 4 == 0) c = add(c, 8);
            int nx = (int) ((off + 8) % 16); if ((x == 1 || x == 14) && y % 4 == 1) c = mul(c, .6);
            p[y * 16 + x] = c;
        }
        return p;
    }
    static int[] logTop(int ring, int core, int bark, int seed) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double d = Math.hypot(x - 7.5, y - 7.5); int c;
            if (d > 6.9) c = mul(bark, .9 + n(x, y, seed) * .2);
            else { double w = (d * 1.25 + Noise.t(x, y, seed) * .4) % 2; c = w < 1 ? ring : core; c = mul(c, .94 + n(x, y, seed + 1) * .12); }
            p[y * 16 + x] = c;
        }
        return p;
    }
    static int[] bark(int br, int bg, int bb, int seed, double dark) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double col = Noise.t(x, 0, seed), vert = Noise.tn(x, y / 4 * 4, 8, seed + 3);
            double sh = .78 + col * .3 + (vert - .5) * .35 + (n(x, y, seed + 7) - .5) * .12;
            if (col > .72) sh *= dark;
            p[y * 16 + x] = rgb(br * sh, bg * sh, bb * sh);
        }
        return p;
    }

    static {
        int[] stone = stone(1), dirt = dirt(), gtop = grassTop(3, 96, 158, 58);
        int[] gside = dirt.clone();
        for (int x = 0; x < 16; x++) {
            int hgt = 2 + (int) (n(x, 0, 71) * 3.2);
            for (int y = 0; y < hgt; y++) gside[y * 16 + x] = y == hgt - 1 ? mul(gtop[y * 16 + x], .78) : gtop[y * 16 + x];
        }
        T[Blocks.GRASS][0] = gtop; T[Blocks.GRASS][1] = gside; T[Blocks.GRASS][2] = dirt;
        set(Blocks.DIRT, dirt); set(Blocks.STONE, stone);
        int[] sand = make(220, 207, 152, 16, 4);
        for (int i = 0; i < 256; i++) if (n(i & 15, i >> 4, 44) < .08) sand[i] = mul(sand[i], .88);
        set(Blocks.SAND, sand);
        int[] snow = make(244, 247, 252, 9, 5); set(Blocks.SNOW, snow);
        int[] wat = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double w = Math.sin((x + y * .5) * Math.PI / 4) * 10 + Math.sin((y * 2 - x) * Math.PI / 8) * 8;
            wat[y * 16 + x] = rgb(38 + w * .6 + (n(x, y, 6) - .5) * 14, 92 + w * .9, 205 + w);
        }
        set(Blocks.WATER, wat);
        int[] lv = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double q = Noise.tn(x, y, 4, 7) * .55 + n(x, y, 8) * .45;
            int c = q < .3 ? rgb(24, 70, 22) : q < .62 ? rgb(46, 118, 36) : q < .85 ? rgb(66, 150, 50) : rgb(88, 176, 66);
            lv[y * 16 + x] = c;
        }
        set(Blocks.LEAVES, lv);
        T[Blocks.LOG][0] = T[Blocks.LOG][2] = logTop(rgb(172, 138, 86), rgb(146, 112, 66), rgb(98, 74, 44), 9);
        T[Blocks.LOG][1] = bark(104, 78, 48, 8, .72);
        set(Blocks.PLANKS, planks(172, 138, 84, 10));
        set(Blocks.COBBLE, cobble());
        int[] bed = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { double[] v = vor(x, y, 4, 12); double s = 36 + 40 * Noise.t((int) v[0], 2, 13) + (v[1] < 1.2 ? -18 : 0); bed[y * 16 + x] = rgb(s, s, s); }
        set(Blocks.BEDROCK, bed);
        set(Blocks.COAL_ORE, ore(rgb(34, 34, 36), rgb(80, 80, 84), 20)); set(Blocks.IRON_ORE, ore(rgb(216, 170, 138), rgb(245, 214, 190), 21));
        set(Blocks.GOLD_ORE, ore(rgb(246, 208, 50), rgb(255, 242, 150), 22)); set(Blocks.DIAMOND_ORE, ore(rgb(60, 226, 220), rgb(200, 255, 252), 23));
        int[] ct = planks(168, 126, 70, 30);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) if (x % 5 == 0 || y % 5 == 0) ct[y * 16 + x] = rgb(84, 56, 30);
        T[Blocks.CRAFT][0] = ct;
        int[] cs = planks(150, 110, 62, 31);
        for (int y = 3; y < 13; y++) for (int x = 2; x < 14; x++) if (y == 3 || y == 12 || x == 2 || x == 13) cs[y * 16 + x] = rgb(80, 54, 30);
        for (int x = 4; x < 7; x++) for (int y = 5; y < 9; y++) cs[y * 16 + x] = (x + y) % 2 == 0 ? rgb(160, 160, 165) : rgb(110, 110, 116);
        T[Blocks.CRAFT][1] = cs; T[Blocks.CRAFT][2] = planks(172, 138, 84, 10);
        int[] gl = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            boolean edge = x == 0 || y == 0 || x == 15 || y == 15;
            gl[y * 16 + x] = edge ? rgb(210, 235, 245) : ((x == y && x > 2 && x < 7) || (x == y + 1 && x > 2 && x < 7) ? rgb(255, 255, 255) : rgb(190, 225, 238));
        }
        set(Blocks.GLASS, gl);
        int[] f = cobble(); T[Blocks.FURNACE][0] = T[Blocks.FURNACE][2] = f;
        int[] fs = f.clone();
        for (int y = 5; y < 13; y++) for (int x = 3; x < 13; x++) fs[y * 16 + x] = (y == 5 || x == 3) ? rgb(30, 30, 30) : rgb(18, 18, 18);
        for (int y = 9; y < 12; y++) for (int x = 5; x < 11; x++) fs[y * 16 + x] = y == 11 ? rgb(255, 150, 30) : rgb(220, 90, 20);
        for (int x = 3; x < 13; x++) fs[2 * 16 + x] = rgb(50, 50, 54);
        T[Blocks.FURNACE][1] = fs;
        int[] gr = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { double[] v = vor(x, y, 5, 33); double s = 105 + 70 * Noise.t((int) v[0], 3, 34); if (v[1] < 1) s *= .7; gr[y * 16 + x] = rgb(s, s * .97, s * .95); }
        set(Blocks.GRAVEL, gr);
        int[] ss = make(214, 198, 142, 12, 34);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) if (y % 5 == 4) ss[y * 16 + x] = mul(ss[y * 16 + x], .88);
        set(Blocks.SANDSTONE, ss);
        int[] cac = new int[256], cacTop = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double s = x % 4 == 0 ? .72 : (x % 4 == 2 ? 1.1 : .95); int c = rgb(38 * s + 4, 128 * s, 48 * s);
            if (x % 4 == 2 && y % 4 == 1) c = rgb(225, 232, 190);
            cac[y * 16 + x] = c;
            double d = Math.max(Math.abs(x - 7.5), Math.abs(y - 7.5)); cacTop[y * 16 + x] = d > 6 ? rgb(30, 100, 40) : rgb(60 + (d % 3) * 12, 150, 66);
        }
        T[Blocks.CACTUS][0] = T[Blocks.CACTUS][2] = cacTop; T[Blocks.CACTUS][1] = cac;
        int[] br = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int row = y / 4, off = (row % 2) * 4, bx = (x + off) % 16 / 8;
            int c = rgb(162 + 26 * Noise.t(row, bx, 36) - 12, 78 + 14 * Noise.t(row, bx, 37), 62 + 10 * Noise.t(row, bx, 38));
            c = mul(c, .94 + n(x, y, 39) * .12);
            if (y % 4 == 3 || (x + off) % 8 == 7) c = rgb(186 + n(x, y, 40) * 14, 180, 170);
            br[y * 16 + x] = c;
        }
        set(Blocks.BRICKS, br);
        int[] sb = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int bx = ((x + (y / 8) * 4) % 16) / 8, by = y / 8;
            double s = 132 + 16 * Noise.t(bx, by, 41) + (n(x, y, 42) - .5) * 16;
            if (y % 8 == 7 || (x + (y / 8) * 4) % 8 == 7) s = 84; else if (y % 8 == 0 || (x + (y / 8) * 4) % 8 == 0) s += 12;
            sb[y * 16 + x] = rgb(s, s, s);
        }
        set(Blocks.STONEBRICKS, sb);
        int[] lava = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double q = Noise.tn(x, y, 4, 38) * .6 + Noise.tn(x, y, 8, 39) * .4;
            lava[y * 16 + x] = q > .66 ? rgb(255, 214, 70) : q > .45 ? rgb(250, 130, 20) : q > .3 ? rgb(214, 70, 12) : rgb(150, 36, 8);
        }
        set(Blocks.LAVA, lava);
        int[] ice = make(150, 200, 242, 14, 39);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) if ((x + y) % 11 == 0 || (x * 2 + y) % 13 == 0) ice[y * 16 + x] = rgb(214, 238, 252);
        set(Blocks.ICE, ice);
        T[Blocks.BIRCH][0] = T[Blocks.BIRCH][2] = logTop(rgb(210, 190, 140), rgb(190, 168, 118), rgb(226, 224, 212), 40);
        int[] bi = make(228, 226, 214, 14, 40);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { double q = n(x / 3, y, 45); if (n(x, y / 3, 46) > .8 && y % 4 < 2 && (x + y * 3) % 5 < 3) bi[y * 16 + x] = rgb(50, 46, 44); }
        T[Blocks.BIRCH][1] = bi;
        set(Blocks.CLAY, make(160, 166, 182, 10, 41));
        T[Blocks.SPRUCE][0] = T[Blocks.SPRUCE][2] = logTop(rgb(130, 98, 60), rgb(110, 82, 48), rgb(60, 42, 28), 42);
        T[Blocks.SPRUCE][1] = bark(72, 52, 34, 42, .65);
        set(Blocks.SPRUCE_PLANKS, planks(112, 82, 50, 43));
        int[] sl = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { double q = Noise.tn(x, y, 4, 44) * .5 + n(x, y, 47) * .5; sl[y * 16 + x] = q < .3 ? rgb(16, 52, 32) : q < .65 ? rgb(28, 80, 46) : rgb(42, 104, 60); }
        set(Blocks.SPRUCE_LEAVES, sl);
        int[] pod = make(104, 74, 42, 30, 45);
        for (int i = 0; i < 256; i++) { double q = n(i & 15, i >> 4, 48); if (q < .15) pod[i] = rgb(70, 46, 26); else if (q > .85) pod[i] = rgb(150, 100, 52); }
        T[Blocks.PODZOL][0] = pod; T[Blocks.PODZOL][1] = dirt; T[Blocks.PODZOL][2] = dirt;
    }

    // ======================= механизмы и серное измерение =======================
    static final int TRANSP = 0x80000000; // прозрачный пиксель
    static final int[][] gearFrames = new int[8][], portalFrames = new int[16][];

    static int[] gearTex(double theta, boolean on) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double dx = x - 7.5, dy = y - 7.5, r = Math.hypot(dx, dy), ph = Math.atan2(dy, dx);
            boolean edge = x == 0 || y == 0 || x == 15 || y == 15;
            int c = on ? rgb(58 + n(x, y, 81) * 10, 44, 30) : rgb(46 + n(x, y, 81) * 10, 46, 52);
            if (edge) c = mul(c, .6);
            double tooth = Math.cos(6 * (ph - theta));
            double rt = tooth > -.15 ? 6.6 : 5.0;
            if (r < rt && r > 1.7) {
                double lit = .85 + .3 * Math.cos(ph - 2.3);
                c = on ? rgb(236 * lit, 168 * lit, 52 * lit) : rgb(150 * lit, 154 * lit, 164 * lit);
                if (r > rt - 1.1) c = mul(c, .78);
                // спицы
                if (r > 3.2 && r < 4.6 && Math.cos(3 * (ph - theta)) > .55) c = on ? rgb(70, 50, 28) : rgb(60, 60, 68);
            } else if (r <= 1.7) c = on ? rgb(255, 232, 140) : rgb(30, 30, 34);
            p[y * 16 + x] = c;
        }
        return p;
    }
    static int[] leverTex(boolean on) {
        int[] p = cobble().clone();
        double lean = on ? 1 : -1;
        for (int s = 0; s <= 90; s++) {
            double f = s / 90.0, x = 7.5 + lean * 4.5 * f, y = 13.5 - 10 * f;
            for (int ox = 0; ox <= 1; ox++) { int ix = (int) x + ox, iy = (int) y; if (ix >= 0 && ix < 16 && iy >= 0 && iy < 16) p[iy * 16 + ix] = f > .88 ? (on ? rgb(255, 60, 40) : rgb(190, 40, 30)) : rgb(110, 76, 40); }
        }
        for (int x = 4; x < 12; x++) for (int y = 13; y < 16; y++) p[y * 16 + x] = rgb(70, 70, 74);
        return p;
    }
    static int[] lampTex(boolean on) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            boolean frame = x < 2 || y < 2 || x > 13 || y > 13 || x == 7 || x == 8 || y == 7 || y == 8;
            double d = Math.hypot(x - 7.5, y - 7.5);
            if (frame) p[y * 16 + x] = on ? rgb(200, 150, 60) : rgb(70, 62, 52);
            else p[y * 16 + x] = on ? rgb(255, 245 - d * 7, 150 - d * 8) : rgb(106 + n(x, y, 83) * 14, 98, 70);
        }
        return p;
    }
    static int[] doorTex(boolean open) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int wood = rgb(150 + n(x, y, 84) * 18, 104 + n(x, y, 84) * 12, 58);
            boolean frameEdge = x < 2 || x > 13 || y < 1 || y > 14;
            boolean panel = (x > 3 && x < 12) && ((y > 2 && y < 7) || (y > 8 && y < 14));
            int c = frameEdge ? mul(wood, .72) : panel ? mul(wood, 1.12) : wood;
            if (x >= 11 && x <= 12 && y >= 7 && y <= 9) c = rgb(220, 200, 90); // ручка
            if (open) { if (x > 2) c = TRANSP; else c = mul(wood, .8); }
            p[y * 16 + x] = c;
        }
        return p;
    }
    static int[] sulfurMottled(int br, int bg, int bb, double var, int seed, int spotCol, double spot) {
        int[] p = make(br, bg, bb, var, seed);
        for (int i = 0; i < 256; i++) if (n(i & 15, i >> 4, seed + 40) < spot) p[i] = spotCol;
        return p;
    }
    static int[] portalTex(double t) {
        int[] p = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double a = Math.sin(x * Math.PI / 4 + t) + Math.sin(y * Math.PI / 4 - t) + Math.sin((x + y) * Math.PI / 8 + 2 * t) + Math.sin((x - y) * Math.PI / 8 - t) * .8;
            double v = (a + 3.6) / 7.2;
            int c = v > .75 ? rgb(255, 238, 120) : v > .5 ? rgb(255, 188, 44) : v > .3 ? rgb(232, 112, 20) : rgb(160, 52, 12);
            if (n(x, y, 85 + (int) (t * 2.5)) > .93) c = rgb(255, 255, 220);
            p[y * 16 + x] = c;
        }
        return p;
    }
    static void initMech() {
        for (int i = 0; i < 8; i++) gearFrames[i] = gearTex(i * (Math.PI / 3) / 8, true);
        for (int i = 0; i < 16; i++) portalFrames[i] = portalTex(i * Math.PI * 2 / 16);
        set(Blocks.GEAR, gearTex(0, false)); set(Blocks.GEAR_ON, gearFrames[0]);
        set(Blocks.LEVER, leverTex(false)); set(Blocks.LEVER_ON, leverTex(true));
        set(Blocks.LAMP, lampTex(false)); set(Blocks.LAMP_ON, lampTex(true));
        set(Blocks.DOOR, doorTex(false)); set(Blocks.DOOR_OPEN, doorTex(true));
        set(Blocks.SULFUR_STONE, sulfurMottled(212, 188, 64, 34, 90, rgb(240, 222, 110), .09));
        set(Blocks.BRIMSTONE, sulfurMottled(92, 40, 36, 28, 91, rgb(50, 20, 20), .12));
        set(Blocks.CRIMSON, sulfurMottled(168, 44, 36, 34, 92, rgb(214, 90, 60), .1));
        int[] so = sulfurMottled(92, 40, 36, 28, 91, rgb(50, 20, 20), .12);
        for (int k = 0; k < 5; k++) { int cx = 2 + (int) (n(k, 3, 93) * 12), cy = 2 + (int) (n(k, 4, 93) * 12);
            for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) so[((cy + dy) & 15) * 16 + ((cx + dx) & 15)] = (dx + dy == 0) ? rgb(255, 245, 150) : rgb(240, 214, 60); }
        set(Blocks.SULFUR_ORE, so);
        int[] cr = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double d = Math.abs(x - 7.5) * .9 + Math.abs(y - 7.5) * .5; double s = 1 - d / 12 + (n(x, y, 94) - .5) * .2;
            cr[y * 16 + x] = rgb(255 * Math.max(.5, s), 232 * Math.max(.45, s), 70 * Math.max(.3, s));
            if ((x + y) % 5 == 0) cr[y * 16 + x] = rgb(255, 250, 190);
        }
        set(Blocks.SULFUR_CRYSTAL, cr);
        set(Blocks.PORTAL, portalFrames[0]);
        // угольный блок: чёрные глыбы с блеском
        int[] cb = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double[] v = vor(x, y, 4, 95); double s = 24 + 22 * Noise.t((int) v[0], 4, 96) + (n(x, y, 97) - .5) * 10;
            if (v[1] < 1.3) s = 10; else if (v[1] < 2.2 && (x + y) % 2 == 0) s += 14;
            if (n(x, y, 98) > .93) s += 46;
            cb[y * 16 + x] = rgb(s, s, s * 1.06);
        }
        set(Blocks.COAL_BLOCK, cb);
        // динамит: красные шашки со стяжками, сверху круг с фитилём
        int[] ds = new int[256], dt = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int stick = x / 4; double sh = (x % 4 == 0) ? .8 : (x % 4 == 3 ? .85 : 1.0);
            int c = rgb((196 + stick * 6) * sh, (36 + n(x, y, 99) * 10) * sh, 30 * sh);
            if (y >= 4 && y <= 5 || y >= 10 && y <= 11) c = rgb(212, 196, 150);
            if (y == 0 || y == 15) c = mul(c, .7);
            ds[y * 16 + x] = c;
            double d = Math.hypot(x - 7.5, y - 7.5);
            dt[y * 16 + x] = d < 1.6 ? rgb(30, 26, 22) : d < 2.4 ? rgb(236, 200, 80) : d < 6.4 ? rgb(214, 190, 140) : rgb(150, 30, 26);
        }
        T[Blocks.DYNAMITE][0] = T[Blocks.DYNAMITE][2] = dt; T[Blocks.DYNAMITE][1] = ds;
    }
    static void initExtra() {
        int[] cal = make(226, 224, 214, 16, 120);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { double[] v = vor(x, y, 4, 121); if (v[1] < .9) cal[y * 16 + x] = mul(cal[y * 16 + x], .86); if (n(x, y, 122) > .92) cal[y * 16 + x] = rgb(250, 248, 240); }
        set(Blocks.CALCITE, cal);
        int[] cbr = new int[256];
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            int row = y / 4, off = (row % 2) * 4; boolean mortar = y % 4 == 3 || (x + off) % 8 == 7;
            int base = rgb(232 + (n(x / 8 + row * 2, row, 123) - .5) * 14, 229 + (n(x / 8 + row * 2, row, 123) - .5) * 14, 218 + (n(x / 8 + row * 2, row, 123) - .5) * 14);
            base = add(base, (n(x, y, 124) - .5) * 8);
            cbr[y * 16 + x] = mortar ? rgb(176, 172, 160) : ((y % 4 == 0) ? add(base, 8) : base);
        }
        set(Blocks.CALCITE_BRICKS, cbr);
        int[] sm = make(238, 236, 228, 7, 125);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { if (x == 0 || y == 0) sm[y * 16 + x] = add(sm[y * 16 + x], 6); if (x == 15 || y == 15) sm[y * 16 + x] = add(sm[y * 16 + x], -10); }
        set(Blocks.SMOOTH_CALCITE, sm);
        int[][] cc = {{214, 62, 74}, {236, 190, 52}, {64, 120, 220}};
        for (int k = 0; k < 3; k++) {
            int[] p = new int[256];
            for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
                double[] v = vor(x, y, 5, 130 + k); double s = .72 + .5 * Noise.t((int) v[0], k, 131); if (v[1] < 1.1) s *= .7;
                p[y * 16 + x] = rgb(cc[k][0] * s, cc[k][1] * s, cc[k][2] * s);
            }
            set(Blocks.CORAL_RED + k, p);
        }
        for (int k = 0; k < Blocks.MATS.length; k++) { T[Blocks.SLAB0 + k] = T[Blocks.MATS[k]]; T[Blocks.STAIR0 + k] = T[Blocks.MATS[k]]; }
    }
    static { initMech(); initExtra(); }
    /** Анимированные текстуры: вращающиеся шестерёнки и вихрь портала. */
    static void animate(double time) {
        set(Blocks.GEAR_ON, gearFrames[(int) (time * 10) & 7]);
        set(Blocks.PORTAL, portalFrames[(int) (time * 9) & 15]);
    }
    static int get(int id, int face, int u, int v) {
        int[][] t = T[id]; if (t[0] == null) return 0xff00ff;
        return t[face][(v & 15) * 16 + (u & 15)];
    }
}
