package voxel;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Мир: чанки 16x16x96, генерация рельефа, биомов, пещер, руд и деревьев. */
public final class World {
    public static final int H = 96, SEA = 30;
    public final int seed;
    Save save;
    /** Вызывается при каждом изменении блока: {x,y,z,id,meta,ext}. Для сети. */
    java.util.function.Consumer<int[]> blockListener; boolean quiet, noFluid;
    final Fluid fluid = new Fluid(this);
    final Map<Long, byte[]> metas = new ConcurrentHashMap<>();
    final Set<Long> modified = ConcurrentHashMap.newKeySet(), dirty = ConcurrentHashMap.newKeySet();
    final Map<Long, byte[]> chunks = new ConcurrentHashMap<>();
    final Map<Long, Mesh> meshes = new ConcurrentHashMap<>();
    final Map<Long, short[]> tops = new ConcurrentHashMap<>();

    public final int dim;
    final Mech mech = new Mech(this);
    final Set<Long> lights = ConcurrentHashMap.newKeySet(), portals = ConcurrentHashMap.newKeySet();
    final Map<Long, Furnace> furnaces = new HashMap<>();
    boolean noMech;
    final Map<Long, Maze> mazes = new ConcurrentHashMap<>();
    /** Динамит с зажжённым фитилём: позиция -> секунд до взрыва. */
    final Map<Long, Double> primed = new HashMap<>();
    public World(int seed) { this(seed, null, 0); }
    public World(int seed, Save save) { this(seed, save, 0); }
    public World(int seed, Save save, int dim) { this.seed = seed; this.save = save; this.dim = dim; Noise.seed = seed; }

    static long key(int cx, int cz) { return ((long) cx << 32) ^ (cz & 0xffffffffL); }
    static int bi(int x, int y, int z) { return y * 256 + z * 16 + x; }

    /** Запоминает светящиеся лампы и блоки портала загруженного чанка. */
    void scan(byte[] c, int cx, int cz) {
        for (int i = 0; i < c.length; i++) {
            int id = c[i] & 0xff;
            if (id == Blocks.LAMP_ON || id == Blocks.PORTAL) {
                int y = i >> 8, z = (i >> 4) & 15, x = i & 15; long pk = Fluid.pack(cx * 16 + x, y, cz * 16 + z);
                (id == Blocks.LAMP_ON ? lights : portals).add(pk);
            }
        }
    }
    public int get(int x, int y, int z) {
        if (y < 0) return Blocks.BEDROCK;
        if (y >= H) return 0;
        byte[] c = chunk(Math.floorDiv(x, 16), Math.floorDiv(z, 16));
        return c[bi(Math.floorMod(x, 16), y, Math.floorMod(z, 16))] & 0xff;
    }
    public void set(int x, int y, int z, int id) { set(x, y, z, id, 0, true); }
    public int getMeta(int x, int y, int z) {
        if (y < 0 || y >= H) return 0;
        byte[] m = metas.get(key(Math.floorDiv(x, 16), Math.floorDiv(z, 16)));
        return m == null ? 0 : m[bi(Math.floorMod(x, 16), y, Math.floorMod(z, 16))] & 0xff;
    }
    /** ext = изменение сделано игроком (тогда вода пересчитывается и вокруг). */
    public void set(int x, int y, int z, int id, int meta, boolean ext) {
        if (y < 0 || y >= H) return;
        int cxx = Math.floorDiv(x, 16), czz = Math.floorDiv(z, 16), lx = Math.floorMod(x, 16), lz = Math.floorMod(z, 16);
        byte[] c = chunk(cxx, czz); long k = key(cxx, czz);
        int idx = bi(lx, y, lz);
        c[idx] = (byte) id;
        if (meta != 0) metas.computeIfAbsent(k, kk -> new byte[c.length])[idx] = (byte) meta;
        else { byte[] m = metas.get(k); if (m != null) m[idx] = 0; }
        modified.add(k); dirty.add(k);
        if (lx == 0) dirty.add(key(cxx - 1, czz)); if (lx == 15) dirty.add(key(cxx + 1, czz));
        if (lz == 0) dirty.add(key(cxx, czz - 1)); if (lz == 15) dirty.add(key(cxx, czz + 1));
        short[] t = top(cxx, czz);
        int i = lz * 16 + lx;
        if (Blocks.solid[id]) { if (y > t[i]) t[i] = (short) y; }
        else if (y == t[i]) { int yy = y - 1; while (yy > 0 && !Blocks.solid[c[bi(lx, yy, lz)] & 0xff]) yy--; t[i] = (short) yy; }
        long pk = Fluid.pack(x, y, z);
        if (id == Blocks.LAMP_ON) lights.add(pk); else lights.remove(pk);
        if (id == Blocks.PORTAL) portals.add(pk); else portals.remove(pk);
        if (!noMech) mech.onChange(x, y, z);
        if (!noFluid) fluid.onChange(x, y, z, ext);
        if (blockListener != null && !quiet) blockListener.accept(new int[]{x, y, z, id, meta, ext ? 1 : 0});
    }
    /** Отличия чанка от свежесгенерированного: упакованные {idx<<16|id<<8|meta}. null — чанк не менялся. */
    public int[] chunkDiff(int cx, int cz) {
        byte[] cur = chunk(cx, cz), fresh = gen(cx, cz), m = metas.get(key(cx, cz));
        int[] tmp = new int[cur.length]; int n = 0;
        for (int i = 0; i < cur.length; i++) {
            int mt = m == null ? 0 : m[i] & 0xff;
            if (cur[i] != fresh[i] || mt != 0) tmp[n++] = (i << 16) | ((cur[i] & 0xff) << 8) | mt;
        }
        return n == 0 ? null : java.util.Arrays.copyOf(tmp, n);
    }
    /** Применяет присланные сервером отличия (клиент). */
    public void applyDiff(int cx, int cz, int[] d) {
        byte[] c = chunk(cx, cz); long k = key(cx, cz);
        for (int v : d) {
            int i = v >>> 16; c[i] = (byte) ((v >> 8) & 0xff); int mt = v & 0xff;
            if (mt != 0) metas.computeIfAbsent(k, kk -> new byte[c.length])[i] = (byte) mt; else { byte[] m = metas.get(k); if (m != null) m[i] = 0; }
        }
        short[] t = tops.get(k);
        for (int i = 0; i < 256; i++) { int y = H - 1; while (y > 0 && !Blocks.solid[c[bi(i & 15, y, i >> 4)] & 0xff]) y--; t[i] = (short) y; }
        scan(c, cx, cz);
        dirty.add(k); dirty.add(key(cx - 1, cz)); dirty.add(key(cx + 1, cz)); dirty.add(key(cx, cz - 1)); dirty.add(key(cx, cz + 1));
    }
    /** Ключи чанков, где возможны правки: файлы сохранения + ещё не сохранённые. */
    public java.util.Set<Long> editedChunks() {
        java.util.Set<Long> s = new java.util.HashSet<>(modified);
        if (save != null) {
            String[] fs = new java.io.File(save.dir, Save.chunkDirName(dim)).list();
            if (fs != null) for (String f : fs) { try { String[] p = f.replace(".bin", "").split("_"); s.add(key(Integer.parseInt(p[0]), Integer.parseInt(p[1]))); } catch (Exception e) { } }
        }
        return s;
    }
    /** Записывает на диск изменённые чанки. */
    public int saveModified() {
        if (save == null) return 0;
        int n = 0;
        for (Long k : new ArrayList<>(modified)) {
            int cx = (int) (k >> 32), cz = (int) (k & 0xffffffffL);
            byte[] c = chunks.get(k); if (c == null) { modified.remove(k); continue; }
            byte[] m = metas.get(k); if (m == null) m = new byte[c.length];
            save.writeChunk(dim, cx, cz, c, m); modified.remove(k); n++;
        }
        return n;
    }
    /** Высота самого верхнего твёрдого блока в колонке (для быстрых теней). */
    public short[] top(int cx, int cz) {
        chunk(cx, cz); return tops.get(key(cx, cz));
    }
    public byte[] chunk(int cx, int cz) {
        long k = key(cx, cz);
        byte[] c = chunks.get(k);
        if (c == null) { byte[][] ld = save != null ? save.readChunk(dim, cx, cz) : null; if (ld != null) { c = ld[0]; metas.put(k, ld[1]); } else c = gen(cx, cz); short[] t = new short[256]; for (int i = 0; i < 256; i++) { int y = H - 1; while (y > 0 && !Blocks.solid[c[bi(i & 15, y, i >> 4)] & 0xff]) y--; t[i] = (short) y; } tops.put(k, t); scan(c, cx, cz); byte[] prev = chunks.putIfAbsent(k, c); if (prev != null) c = prev; }
        return c;
    }
    public boolean solid(int x, int y, int z) { return Blocks.solid[get(x, y, z)]; }

    static final double[][] FULL = {{0, 0, 0, 1, 1, 1}}, BOT = {{0, 0, 0, 1, .5, 1}}, TOP = {{0, .5, 0, 1, 1, 1}};
    static final double[][][] STAIR = new double[8][][];
    static {
        double[][] st = {{.5, 1}, {0, .5}};
        for (int f = 0; f < 4; f++) for (int up = 0; up < 2; up++) {
            double x0 = 0, x1 = 1, z0 = 0, z1 = 1;
            if (f == 0) x0 = .5; else if (f == 1) x1 = .5; else if (f == 2) z0 = .5; else z1 = .5;
            STAIR[f + up * 4] = up == 0 ? new double[][]{{0, 0, 0, 1, .5, 1}, {x0, .5, z0, x1, 1, z1}} : new double[][]{{0, .5, 0, 1, 1, 1}, {x0, 0, z0, x1, .5, z1}};
        }
    }
    /** Объёмы блока внутри клетки: [x0,y0,z0,x1,y1,z1]. Для воды meta 1..7 — пониженный уровень. */
    static double[][] boxes(int id, int meta) {
        if (!Blocks.shaped[id]) return FULL;
        if (id < Blocks.STAIR0) return meta == 1 ? TOP : BOT;
        return STAIR[meta & 7];
    }
    /** Высота воды в клетке: 1 для источника/падающей, меньше при растекании. */
    static double waterH(int meta) { return meta >= 1 && meta <= 7 ? (8 - meta) / 8.0 : 1.0; }
    /** Пересекает ли прямоугольный объём твёрдые блоки (с учётом плит и ступенек). */
    public boolean hitsBox(double x0, double y0, double z0, double x1, double y1, double z1) {
        for (int bx = (int) Math.floor(x0); bx <= (int) Math.floor(x1); bx++)
            for (int by = (int) Math.floor(y0); by <= (int) Math.floor(y1 - 1e-4); by++)
                for (int bz = (int) Math.floor(z0); bz <= (int) Math.floor(z1); bz++) {
                    int id = get(bx, by, bz);
                    if (!Blocks.solid[id]) continue;
                    if (!Blocks.shaped[id]) return true;
                    for (double[] b : boxes(id, getMeta(bx, by, bz)))
                        if (x0 < bx + b[3] - 1e-6 && x1 > bx + b[0] + 1e-6 && y0 < by + b[4] - 1e-6 && y1 > by + b[1] + 1e-6 && z0 < bz + b[5] - 1e-6 && z1 > bz + b[2] + 1e-6) return true;
                }
        return false;
    }

    public static final int LAVA_LEVEL = 22;
    /** Серное измерение: красные и жёлтые камни, лавовые озёра, серные руды, кристаллы. */
    byte[] genSulfur(int cx, int cz) {
        byte[] c = new byte[16 * 16 * H];
        for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            int wx = cx * 16 + x, wz = cz * 16 + z;
            double n1 = Noise.fbm2(wx / 80.0, wz / 80.0, 4, 101), n2 = Noise.fbm2(wx / 26.0, wz / 26.0, 3, 102);
            int h = Math.max(6, Math.min(72, (int) (28 + (n1 - .45) * 46 + (n2 - .5) * 12)));
            boolean crimson = Noise.fbm2(wx / 20.0, wz / 20.0, 2, 103) > .58;
            for (int y = 0; y <= Math.max(h, LAVA_LEVEL); y++) {
                int id;
                if (y == 0) id = Blocks.BEDROCK;
                else if (y > h) id = Blocks.LAVA;
                else {
                    double n3 = Noise.v3(wx / 9.0, y / 9.0, wz / 9.0, 311);
                    id = n3 > .55 ? Blocks.BRIMSTONE : Blocks.SULFUR_STONE;
                    if (crimson && y > h - 3) id = Blocks.CRIMSON;
                    double r = Noise.h(wx, y, wz, 201);
                    if (y < h - 2 && r < .014) id = Blocks.SULFUR_ORE;
                    else if (y < h - 2 && r > .014 && r < .0185 && y < 40) id = Blocks.GOLD_ORE;
                    else if (y < h - 2 && r > .0185 && r < .0215 && y < 26) id = Blocks.DIAMOND_ORE;
                    if (y > 3 && y < h - 4 && Noise.v3(wx / 16.0, y / 10.0, wz / 16.0, 57) > .75) id = y < 12 ? Blocks.LAVA : Blocks.AIR;
                }
                c[bi(x, y, z)] = (byte) id;
            }
            if (h > LAVA_LEVEL + 1 && x > 0 && x < 15 && z > 0 && z < 15 && Noise.h(wx, 5, wz, 207) < .01) {
                int ch = 1 + (int) (Noise.h(wx, 6, wz, 208) * 3);
                for (int i = 1; i <= ch && h + i < H - 2; i++) c[bi(x, h + i, z)] = (byte) Blocks.SULFUR_CRYSTAL;
            }
        }
        return c;
    }
    public int height(int x, int z) {
        Noise.seed = seed;
        double cont = Noise.fbm2(x / 160.0, z / 160.0, 4, 1);
        double hill = Noise.fbm2(x / 48.0, z / 48.0, 4, 2);
        double mount = Math.max(0, Noise.fbm2(x / 120.0, z / 120.0, 3, 3) - .55) * 2;
        return (int) (SEA - 2 + (cont - .45) * 30 + (hill - .5) * 16 + mount * 40);
    }
    /** Температура океана: 0 обычный, 1 холодный, 2 тёплый. */
    public int ocean(int x, int z) {
        double n = Noise.fbm2(x / 230.0, z / 230.0, 3, 21);
        return n > .55 ? 2 : n < .45 ? 1 : 0;
    }
    /** 0 равнина,1 пустыня,2 тайга,3 снег,4 горы-лес */
    public int biome(int x, int z) {
        double t = Noise.fbm2(x / 200.0, z / 200.0, 3, 11), m = Noise.fbm2(x / 200.0, z / 200.0, 3, 12);
        if (t > .62 && m < .5) return 1;
        if (t < .35) return m > .5 ? 2 : 3;
        return 0;
    }

    /** Кальцитовая зона: белый камень вместо обычного и более просторные пещеры. */
    boolean calciteZone(int x, int y, int z) { return y > 4 && y < 46 && Noise.v3(x / 46.0, y / 22.0, z / 46.0, 61) > .6; }

    byte[] gen(int cx, int cz) {
        Noise.seed = seed;
        if (dim == 1) return genSulfur(cx, cz);
        byte[] c = new byte[16 * 16 * H];
        for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
            int wx = cx * 16 + x, wz = cz * 16 + z, h = Math.min(H - 12, Math.max(2, height(wx, wz))), bm = biome(wx, wz);
            int oc = h < SEA ? ocean(wx, wz) : 0; Maze mz = Maze.at(this, wx, wz); Noise.seed = seed;
            for (int y = 0; y <= Math.max(h, SEA); y++) {
                int id;
                if (y == 0) id = Blocks.BEDROCK;
                else if (y == h + 1 && oc == 2 && h < SEA - 2 && h > 3 && Noise.h(wx, 3, wz, 24) < .04) id = Blocks.CORAL_RED + (int) (Noise.h(wx, 4, wz, 25) * 3);
                else if (y > h) id = (bm == 3 && y == SEA) ? Blocks.ICE : (oc == 1 && y == SEA && h < SEA - 1 && Noise.fbm2(wx / 9.0, wz / 9.0, 2, 23) > .6) ? Blocks.ICE : Blocks.WATER;
                else if (y == h) {
                    if (oc == 1 && h < SEA - 1) id = Blocks.GRAVEL;
                    else if (h <= SEA + 1) id = Blocks.SAND;
                    else id = bm == 1 ? Blocks.SAND : bm == 3 ? Blocks.SNOW : bm == 2 ? Blocks.PODZOL : Blocks.GRASS;
                    if (h > 62) id = Blocks.SNOW;
                } else if (y > h - 4) id = (bm == 1 || h <= SEA + 1) ? (y > h - 3 ? Blocks.SAND : Blocks.SANDSTONE) : Blocks.DIRT;
                else {
                    id = Blocks.STONE;
                    double r = Noise.h(wx, y, wz, 77);
                    if (y < 50 && r < .012) id = Blocks.COAL_ORE;
                    else if (y < 40 && r > .012 && r < .019) id = Blocks.IRON_ORE;
                    else if (y < 22 && r > .019 && r < .0225) id = Blocks.GOLD_ORE;
                    else if (y < 14 && r > .0225 && r < .0245) id = Blocks.DIAMOND_ORE;
                    else if (y < h - 5 && y > 3 && Noise.v3(wx / 14.0, y / 9.0, wz / 14.0, 55) > (calciteZone(wx, y, wz) ? .62 : .72)) id = Blocks.AIR; // пещеры
                    if (id == Blocks.STONE && calciteZone(wx, y, wz)) id = Blocks.CALCITE;
                }
                if (mz != null) { int mb = mz.block(wx, y, wz); if (mb >= 0) id = mb; else if (mb == -2 && id == Blocks.STONE) id = Blocks.CALCITE; }
                c[bi(x, y, z)] = (byte) id;
            }
        }
        // деревья/кактусы
        for (int z = 2; z < 14; z++) for (int x = 2; x < 14; x++) {
            int wx = cx * 16 + x, wz = cz * 16 + z, h = Math.max(2, height(wx, wz)), bm = biome(wx, wz);
            if (h <= SEA + 1 || h > 60 || h >= H - 12) continue;
            int top = c[bi(x, h, z)] & 0xff;
            double r = Noise.h(wx, 0, wz, 99);
            if (bm == 1 && top == Blocks.SAND && r < .006) { for (int i = 1; i <= 3; i++) c[bi(x, h + i, z)] = (byte) Blocks.CACTUS; }
            else if ((top == Blocks.GRASS || top == Blocks.PODZOL || top == Blocks.SNOW) && r < (bm == 0 ? .012 : .02)) tree(c, x, h, z, bm, wx, wz);
        }
        return c;
    }
    void tree(byte[] c, int x, int h, int z, int bm, int wx, int wz) {
        boolean spruce = bm == 2 || bm == 3, birch = !spruce && Noise.h(wx, 1, wz, 5) < .3;
        int log = spruce ? Blocks.SPRUCE : birch ? Blocks.BIRCH : Blocks.LOG, lv = spruce ? Blocks.SPRUCE_LEAVES : Blocks.LEAVES;
        int th = 4 + (int) (Noise.h(wx, 2, wz, 6) * 3);
        for (int dy = th - 2; dy <= th + 1; dy++) {
            int rad = spruce ? Math.max(0, (th + 1 - dy) / 2 + (dy < th ? 1 : 0)) : (dy >= th ? 1 : 2);
            for (int dz = -rad; dz <= rad; dz++) for (int dx = -rad; dx <= rad; dx++) {
                if (Math.abs(dx) == rad && Math.abs(dz) == rad && rad > 1) continue;
                int xx = x + dx, zz = z + dz, yy = h + dy;
                if (xx < 0 || xx > 15 || zz < 0 || zz > 15 || yy >= H) continue;
                if (c[bi(xx, yy, zz)] == 0) c[bi(xx, yy, zz)] = (byte) lv;
            }
        }
        for (int i = 1; i <= th; i++) c[bi(x, h + i, z)] = (byte) log;
    }

    /** Ищет сушу рядом с началом координат. */
    public int[] findSpawn() {
        for (int r = 0; r < 600; r += 6) for (int a = 0; a < 360; a += 30) {
            int x = (int) (Math.cos(Math.toRadians(a)) * r), z = (int) (Math.sin(Math.toRadians(a)) * r);
            int y = surface(x, z);
            if (y > SEA + 1 && y < 60 && get(x, y + 1, z) == 0) return new int[]{x, y + 1, z};
        }
        return new int[]{0, surface(0, 0) + 1, 0};
    }
    public int surface(int x, int z) {
        for (int y = H - 1; y > 0; y--) if (Blocks.solid[get(x, y, z)]) return y;
        return SEA;
    }
}
