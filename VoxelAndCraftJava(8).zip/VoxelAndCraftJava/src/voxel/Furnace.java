package voxel;

/** Состояние печи: руда сверху, топливо снизу, результат справа. */
final class Furnace {
    int inId, inN, fuelId, fuelN, outId, outN;
    double progress, burn, burnMax;
    static final double SMELT_TIME = 3.0;

    static double fuelValue(int id) {
        if (id == Blocks.COAL) return 24;
        if (id == Blocks.LOG || id == Blocks.BIRCH || id == Blocks.SPRUCE) return 6;
        if (id == Blocks.PLANKS || id == Blocks.SPRUCE_PLANKS) return 3;
        if (id == Blocks.STICK) return 1.5;
        return 0;
    }
    boolean lit() { return burn > 0; }

    void update(double dt) {
        int target = Recipes.smelt(inId);
        boolean can = inN > 0 && target > 0 && (outN == 0 || (outId == target && outN < Blocks.stack(target)));
        if (can && burn <= 0 && fuelN > 0 && fuelValue(fuelId) > 0) {
            burnMax = burn = fuelValue(fuelId); if (--fuelN == 0) fuelId = 0;
        }
        if (burn > 0) burn = Math.max(0, burn - dt);
        if (can && burn > 0) {
            progress += dt;
            if (progress >= SMELT_TIME) {
                progress = 0; if (--inN == 0) inId = 0;
                outId = target; outN++;
            }
        } else progress = Math.max(0, progress - dt * 2);
    }

    String serialize() { return inId + " " + inN + " " + fuelId + " " + fuelN + " " + outId + " " + outN + " " + progress + " " + burn + " " + burnMax; }
    static Furnace parse(String[] t, int o) {
        Furnace f = new Furnace();
        f.inId = Integer.parseInt(t[o]); f.inN = Integer.parseInt(t[o + 1]); f.fuelId = Integer.parseInt(t[o + 2]); f.fuelN = Integer.parseInt(t[o + 3]);
        f.outId = Integer.parseInt(t[o + 4]); f.outN = Integer.parseInt(t[o + 5]); f.progress = Double.parseDouble(t[o + 6]); f.burn = Double.parseDouble(t[o + 7]); f.burnMax = Double.parseDouble(t[o + 8]);
        return f;
    }
}
