package voxel;

/** Реестр блоков и предметов. Идентификаторы совпадают с HTML-версией. */
public final class Blocks {
    public static final int AIR = 0, GRASS = 1, DIRT = 2, STONE = 3, SAND = 4, SNOW = 5, WATER = 6, LEAVES = 7, LOG = 8, PLANKS = 9,
        COBBLE = 10, BEDROCK = 11, COAL_ORE = 12, IRON_ORE = 13, GOLD_ORE = 14, DIAMOND_ORE = 15, CRAFT = 16, GLASS = 17, FURNACE = 18,
        GRAVEL = 19, SANDSTONE = 20, CACTUS = 21, BRICKS = 22, STONEBRICKS = 23, LAVA = 24, ICE = 25, BIRCH = 26, CLAY = 27,
        SPRUCE = 28, SPRUCE_PLANKS = 29, SPRUCE_LEAVES = 30, PODZOL = 31,
        GEAR = 32, GEAR_ON = 33, LEVER = 34, LEVER_ON = 35, LAMP = 36, LAMP_ON = 37, DOOR = 38, DOOR_OPEN = 39,
        SULFUR_STONE = 40, BRIMSTONE = 41, CRIMSON = 42, SULFUR_ORE = 43, SULFUR_CRYSTAL = 44, PORTAL = 45, COAL_BLOCK = 46, DYNAMITE = 47,
        CALCITE = 48, CALCITE_BRICKS = 49, SMOOTH_CALCITE = 50, CORAL_RED = 51, CORAL_YELLOW = 52, CORAL_BLUE = 53,
        SLAB0 = 64, STAIR0 = 72;
    /** Материалы плит и ступенек: плита = SLAB0+k, ступеньки = STAIR0+k. */
    public static final int[] MATS = {PLANKS, COBBLE, STONEBRICKS, BRICKS, SANDSTONE, CALCITE_BRICKS, SMOOTH_CALCITE, SPRUCE_PLANKS};
    public static final int NB = 128;
    public static final String[] name = new String[NB];
    public static final float[] hard = new float[NB];
    public static final int[] tool = new int[NB];      // 0 нет, 1 кирка, 2 топор, 3 лопата
    public static final int[] minTier = new int[NB];
    public static final boolean[] solid = new boolean[NB];
    public static final float[] alpha = new float[NB];
    public static final boolean[] glow = new boolean[NB];
    public static final int[] drop = new int[NB];       // -1 сам блок, 0 ничего, иначе id предмета
    public static final boolean[] shaped = new boolean[NB]; // плиты и ступеньки: неполные блоки
    public static final boolean[] cutout = new boolean[NB]; // в текстуре есть прозрачные пиксели

    // предметы
    public static final int COAL = 300, IRON_INGOT = 301, GOLD_INGOT = 302, DIAMOND = 303, CLAY_BALL = 305, BRICK = 306, KEY = 310, SULFUR = 311, STICK = 393;
    public static final String[] iname = new String[1024];
    public static final int[] kind = new int[1024], tier = new int[1024];
    public static final String[] TIERN = {"", "Деревянн", "Каменн", "Железн", "Алмазн"};
    public static final String[] KINDN = {"", "кирка", "топор", "лопата", "меч"};
    public static final String[] KINDE = {"", "ая", "ый", "ая", "ый"};
    public static final float[] SPEED = {1, 2, 4, 6, 8};
    public static final int[] DUR = {0, 60, 132, 250, 800};
    public static final int[] TIER_MAT = {0, PLANKS, COBBLE, IRON_INGOT, DIAMOND};

    static void b(int id, String n, float h, int t, int dr, int minT) {
        name[id] = n; hard[id] = h; tool[id] = t; drop[id] = dr; minTier[id] = minT; solid[id] = true; alpha[id] = 1;
    }
    static {
        b(GRASS, "Трава", .6f, 3, DIRT, 0); b(DIRT, "Земля", .5f, 3, -1, 0); b(STONE, "Камень", 1.5f, 1, COBBLE, 0);
        b(SAND, "Песок", .4f, 3, -1, 0); b(SNOW, "Снег", .3f, 3, -1, 0);
        b(WATER, "Вода", 999, 0, 0, 0); solid[WATER] = false; alpha[WATER] = .55f;
        b(LEAVES, "Листва", .2f, 2, 0, 0); b(LOG, "Дубовое бревно", 1f, 2, -1, 0); b(PLANKS, "Доски", .8f, 2, -1, 0);
        b(COBBLE, "Булыжник", 1.5f, 1, -1, 0); b(BEDROCK, "Бедрок", 999, 0, 0, 0);
        b(COAL_ORE, "Угольная руда", 1.5f, 1, COAL, 0); b(IRON_ORE, "Железная руда", 2f, 1, -1, 2);
        b(GOLD_ORE, "Золотая руда", 2f, 1, -1, 3); b(DIAMOND_ORE, "Алмазная руда", 3f, 1, DIAMOND, 3);
        b(CRAFT, "Верстак", .8f, 2, -1, 0); b(GLASS, "Стекло", .3f, 0, 0, 0); alpha[GLASS] = .3f;
        b(FURNACE, "Печь", 1.5f, 1, -1, 0); b(GRAVEL, "Гравий", .6f, 3, -1, 0); b(SANDSTONE, "Песчаник", .8f, 1, -1, 0);
        b(CACTUS, "Кактус", .4f, 0, -1, 0); b(BRICKS, "Кирпичи", 2f, 1, -1, 0); b(STONEBRICKS, "Каменные кирпичи", 1.5f, 1, -1, 0);
        b(LAVA, "Лава", 999, 0, 0, 0); solid[LAVA] = false; glow[LAVA] = true;
        b(ICE, "Лёд", .5f, 1, 0, 0); alpha[ICE] = .8f; b(BIRCH, "Берёзовое бревно", 1f, 2, -1, 0);
        b(CLAY, "Глина", .6f, 3, CLAY_BALL, 0); b(SPRUCE, "Еловое бревно", 1f, 2, -1, 0);
        b(SPRUCE_PLANKS, "Еловые доски", .8f, 2, -1, 0); b(SPRUCE_LEAVES, "Еловая хвоя", .2f, 2, 0, 0);
        b(PODZOL, "Подзол", .5f, 3, DIRT, 0);
        // --- механизмы ---
        b(GEAR, "Шестерёнка", .8f, 1, -1, 0); b(GEAR_ON, "Шестерёнка", .8f, 1, GEAR, 0); glow[GEAR_ON] = true;
        b(LEVER, "Рычаг", .5f, 1, -1, 0); b(LEVER_ON, "Рычаг", .5f, 1, LEVER, 0);
        b(LAMP, "Лампа", .5f, 0, -1, 0); b(LAMP_ON, "Лампа", .5f, 0, LAMP, 0); glow[LAMP_ON] = true;
        b(DOOR, "Дверь", 1f, 2, -1, 0); b(DOOR_OPEN, "Дверь", 1f, 2, DOOR, 0); solid[DOOR_OPEN] = false; cutout[DOOR_OPEN] = true;
        // --- серное измерение ---
        b(SULFUR_STONE, "Серный камень", 1.5f, 1, -1, 0); b(BRIMSTONE, "Сернистый базальт", 2.2f, 1, -1, 0); b(CRIMSON, "Багровый камень", 1.8f, 1, -1, 0);
        b(SULFUR_ORE, "Серная руда", 2.5f, 1, 0, 1); b(SULFUR_CRYSTAL, "Серный кристалл", .8f, 1, 0, 0); glow[SULFUR_CRYSTAL] = true;
        b(COAL_BLOCK, "Угольный блок", 2f, 1, -1, 0); b(DYNAMITE, "Динамит", .1f, 0, -1, 0);
        b(CALCITE, "Кальцит", 1.2f, 1, -1, 0); b(CALCITE_BRICKS, "Кальцитовые кирпичи", 1.6f, 1, -1, 0); b(SMOOTH_CALCITE, "Гладкий кальцит", 1.4f, 1, -1, 0);
        b(CORAL_RED, "Красный коралл", .6f, 1, -1, 0); b(CORAL_YELLOW, "Жёлтый коралл", .6f, 1, -1, 0); b(CORAL_BLUE, "Синий коралл", .6f, 1, -1, 0);
        for (int k = 0; k < MATS.length; k++) {
            int m = MATS[k];
            b(SLAB0 + k, name[m] + " (плита)", hard[m], tool[m], -1, 0); b(STAIR0 + k, name[m] + " (ступеньки)", hard[m], tool[m], -1, 0);
            shaped[SLAB0 + k] = shaped[STAIR0 + k] = true;
        }
        b(PORTAL, "Серный портал", 999, 0, 0, 0); solid[PORTAL] = false; alpha[PORTAL] = .72f; glow[PORTAL] = true;

        item(KEY, "Серный ключ"); item(SULFUR, "Сера");
        item(COAL, "Уголь"); item(IRON_INGOT, "Железный слиток"); item(GOLD_INGOT, "Золотой слиток");
        item(DIAMOND, "Алмаз"); item(CLAY_BALL, "Глиняный шар"); item(BRICK, "Кирпич"); item(STICK, "Палка");
        for (int k = 1; k <= 4; k++) for (int t = 1; t <= 4; t++) {
            int id = k * 10 + 200 + t;
            iname[id] = TIERN[t] + KINDE[k] + " " + KINDN[k]; kind[id] = k; tier[id] = t;
        }
    }
    static void item(int id, String n) { iname[id] = n; }

    /** Через блок что-то видно (вода, стекло, дверь с прозрачными пикселями). */
    public static boolean seeThrough(int id) { return id != 0 && (alpha[id] < 1 || cutout[id]); }
    public static boolean isBlock(int id) { return id > 0 && id < NB && name[id] != null; }
    public static boolean isTool(int id) { return id >= 200 && id < 1024 && kind[id] > 0; }
    public static String nameOf(int id) { return isBlock(id) ? name[id] : (id >= 0 && id < 1024 && iname[id] != null ? iname[id] : "#" + id); }
    public static int stack(int id) { return isTool(id) ? 1 : 64; }
    public static int toolId(int kind, int tier) { return kind * 10 + 200 + tier; }
}
