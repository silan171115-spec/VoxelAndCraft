package voxel;

import java.util.*;

/**
 * Механизмы: шестерёнки проводят сигнал (уровень 15, затухание на 1 за клетку), рычаг — источник,
 * лампа и дверь — потребители. Пересчёт идёт только на хосте / в одиночной игре; клиенты получают итоговые блоки по сети.
 */
final class Mech {
    final World w;
    final LinkedHashSet<Long> q = new LinkedHashSet<>();
    static final int[][] N6 = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};

    Mech(World w) { this.w = w; }

    static boolean isMech(int id) { return (id >= Blocks.GEAR && id <= Blocks.DOOR_OPEN) || id == Blocks.DYNAMITE; }

    void onChange(int x, int y, int z) {
        boolean any = isMech(w.get(x, y, z));
        if (!any) for (int[] d : N6) if (isMech(w.get(x + d[0], y + d[1], z + d[2]))) { any = true; break; }
        if (!any) return;
        q.add(Fluid.pack(x, y, z));
        for (int[] d : N6) if (y + d[1] >= 0 && y + d[1] < World.H) q.add(Fluid.pack(x + d[0], y + d[1], z + d[2]));
    }

    void tick() {
        for (int guard = 0; !q.isEmpty() && guard < 100; guard++) {
            List<Long> batch = new ArrayList<>(q); q.clear();
            Set<Long> seen = new HashSet<>();
            for (long k : batch) { int[] p = Fluid.unpack(k); eval(p[0], p[1], p[2], seen); }
        }
    }

    int sourcePower(int id) { return id == Blocks.LEVER_ON ? 15 : 0; }

    int powerInto(int x, int y, int z) {
        int p = 0;
        for (int[] d : N6) {
            int nx = x + d[0], ny = y + d[1], nz = z + d[2], id = w.get(nx, ny, nz);
            if (id == Blocks.GEAR_ON) p = Math.max(p, w.getMeta(nx, ny, nz));
            else p = Math.max(p, sourcePower(id));
        }
        return p;
    }

    void eval(int x, int y, int z, Set<Long> seen) {
        int id = w.get(x, y, z);
        switch (id) {
            case Blocks.GEAR, Blocks.GEAR_ON -> { if (!seen.contains(Fluid.pack(x, y, z))) component(x, y, z, seen); }
            case Blocks.LAMP, Blocks.LAMP_ON -> { boolean on = powerInto(x, y, z) > 0; if ((id == Blocks.LAMP_ON) != on) w.set(x, y, z, on ? Blocks.LAMP_ON : Blocks.LAMP, 0, false); }
            case Blocks.DOOR, Blocks.DOOR_OPEN -> { boolean on = powerInto(x, y, z) > 0; if ((id == Blocks.DOOR_OPEN) != on) w.set(x, y, z, on ? Blocks.DOOR_OPEN : Blocks.DOOR, 0, false); }
            case Blocks.DYNAMITE -> { if (powerInto(x, y, z) > 0) w.primed.putIfAbsent(Fluid.pack(x, y, z), 1.0); }
            default -> { }
        }
    }

    /** Связная группа шестерёнок: уровни от источников с затуханием по группе. */
    void component(int sx, int sy, int sz, Set<Long> seen) {
        List<int[]> comp = new ArrayList<>(); Map<Long, Integer> idx = new HashMap<>(); List<List<Integer>> adj = new ArrayList<>();
        comp.add(new int[]{sx, sy, sz}); idx.put(Fluid.pack(sx, sy, sz), 0);
        for (int h = 0; h < comp.size() && comp.size() < 2500; h++) {
            int[] c = comp.get(h); List<Integer> a = new ArrayList<>(); adj.add(a);
            for (int[] d : N6) {
                int nx = c[0] + d[0], ny = c[1] + d[1], nz = c[2] + d[2], id = w.get(nx, ny, nz);
                if (id != Blocks.GEAR && id != Blocks.GEAR_ON) continue;
                long k = Fluid.pack(nx, ny, nz); Integer j = idx.get(k);
                if (j == null) { j = comp.size(); idx.put(k, j); comp.add(new int[]{nx, ny, nz}); }
                a.add(j);
            }
        }
        while (adj.size() < comp.size()) adj.add(new ArrayList<>());
        int[] lvl = new int[comp.size()];
        for (int i = 0; i < comp.size(); i++) {
            int[] c = comp.get(i); seen.add(Fluid.pack(c[0], c[1], c[2])); int p = 0;
            for (int[] d : N6) p = Math.max(p, sourcePower(w.get(c[0] + d[0], c[1] + d[1], c[2] + d[2])));
            lvl[i] = p;
        }
        boolean ch = true; int guard = 0;
        while (ch && guard++ < 40) { ch = false; for (int i = 0; i < comp.size(); i++) for (int j : adj.get(i)) if (lvl[j] - 1 > lvl[i]) { lvl[i] = lvl[j] - 1; ch = true; } }
        for (int i = 0; i < comp.size(); i++) {
            int[] c = comp.get(i); int id = w.get(c[0], c[1], c[2]), cur = id == Blocks.GEAR_ON ? w.getMeta(c[0], c[1], c[2]) : 0;
            if (cur != lvl[i] || (id == Blocks.GEAR_ON) != (lvl[i] > 0)) w.set(c[0], c[1], c[2], lvl[i] > 0 ? Blocks.GEAR_ON : Blocks.GEAR, lvl[i], false);
        }
    }
}
