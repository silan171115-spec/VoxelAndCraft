package voxel;

/** Игрок: физика AABB, полёт, вода, урон от падения, инвентарь. */
public final class Player {
    public double x, y, z, vx, vy, vz, yaw, pitch;
    public boolean onGround, creative, flying;
    public int health = 20, selected;
    public final int[] inv = new int[36], cnt = new int[36];
    static final double W = .3, HGT = 1.8, EYE = 1.62;
    static double EYE_H() { return EYE; }
    double lavaAcc, fallStart, sinceHurt = 99, regenT, drownT, air = 10;
    public boolean dead; public String cause = "";

    public Player() { this(true); }
    /** full=false — пустой инвентарь (выживание с нуля). */
    public Player(boolean full) {
        if (!full) return;
        int[] start = {Blocks.toolId(1, 3), Blocks.toolId(2, 3), Blocks.toolId(3, 3), Blocks.toolId(4, 4), Blocks.PLANKS, Blocks.COBBLE, Blocks.GLASS, Blocks.GEAR, Blocks.LEVER};
        for (int i = 0; i < start.length; i++) { inv[i] = start[i]; cnt[i] = Blocks.stack(start[i]) == 1 ? 1 : 64; }
        add(Blocks.LAMP, 16); add(Blocks.DOOR, 8); add(Blocks.CRAFT, 4); add(Blocks.FURNACE, 4); add(Blocks.LOG, 32); add(Blocks.SAND, 32); add(Blocks.WATER, 16);
        add(Blocks.COAL_BLOCK, 16); add(Blocks.DYNAMITE, 6); add(Blocks.KEY, 2); add(Blocks.COAL, 32); add(Blocks.IRON_INGOT, 16); add(Blocks.GOLD_INGOT, 8); add(Blocks.IRON_ORE, 16); add(Blocks.STICK, 16);
        add(Blocks.BRICKS, 32); add(Blocks.STONEBRICKS, 32);
        add(Blocks.CALCITE, 32); add(Blocks.CALCITE_BRICKS, 32); add(Blocks.SMOOTH_CALCITE, 32);
        add(Blocks.SLAB0 + 2, 16); add(Blocks.SLAB0 + 5, 16); add(Blocks.SLAB0, 16); add(Blocks.STAIR0 + 2, 16); add(Blocks.STAIR0 + 5, 16); add(Blocks.STAIR0, 16);
    }
    public boolean add(int id, int n) {
        for (int i = 0; i < 36 && n > 0; i++) if (inv[i] == id && cnt[i] < Blocks.stack(id)) { int t = Math.min(n, Blocks.stack(id) - cnt[i]); cnt[i] += t; n -= t; }
        for (int i = 0; i < 36 && n > 0; i++) if (cnt[i] == 0) { inv[i] = id; int t = Math.min(n, Blocks.stack(id)); cnt[i] = t; n -= t; }
        return n == 0;
    }
    boolean hits(World w, double px, double py, double pz) { return w.hitsBox(px - W, py, pz - W, px + W, py + HGT, pz + W); }
    boolean inFluid(World w, int id) { return w.get((int) Math.floor(x), (int) Math.floor(y + .5), (int) Math.floor(z)) == id; }

    public void update(World w, double dt, double fwd, double strafe, boolean jump, boolean sneak) {
        if (dead) return;
        sinceHurt += dt;
        if (!creative) {
            if (health < 20 && sinceHurt > 6) { regenT += dt; if (regenT >= 2.5) { regenT = 0; health++; } } else regenT = 0;
            boolean head = w.get((int) Math.floor(x), (int) Math.floor(y + EYE), (int) Math.floor(z)) == Blocks.WATER;
            if (head) { air -= dt; if (air <= 0) { air = 0; drownT += dt; if (drownT >= 1) { drownT = 0; hurt(2, "Вы утонули"); } } }
            else { air = Math.min(10, air + dt * 5); drownT = 0; }
        } else air = 10;
        boolean water = inFluid(w, Blocks.WATER), lava = inFluid(w, Blocks.LAVA);
        double sp = flying ? 10 : (sneak ? 1.8 : 4.3);
        if (water || lava) sp *= .6;
        double sin = Math.sin(yaw), cos = Math.cos(yaw);
        double wx = (-sin * fwd + cos * strafe) * sp, wz = (-cos * fwd - sin * strafe) * sp;
        vx += (wx - vx) * Math.min(1, dt * 12); vz += (wz - vz) * Math.min(1, dt * 12);
        if (flying) { vy = jump ? 8 : sneak ? -8 : 0; }
        else if (water || lava) { vy += (jump ? 3 : -2.5 - vy) * Math.min(1, dt * 4); if (lava && !creative) { lavaAcc += dt * 4; if (lavaAcc >= 1) { hurt(lavaAcc, "Вы сгорели в лаве"); lavaAcc = 0; } } }
        else { vy -= 28 * dt; if (jump && onGround) { vy = 8.6; } }
        if (vy < -50) vy = -50;
        move(w, vx * dt, 0, 0); move(w, 0, 0, vz * dt);
        boolean was = onGround; onGround = false;
        double ny = y + vy * dt;
        if (hits(w, x, ny, z)) {
            if (vy < 0) { onGround = true; double dmg = fallStart - y; if (!creative && !flying && dmg > 3.5 && !water) hurt(Math.floor(dmg - 3), "Вы разбились при падении"); }
            vy = 0;
        } else y = ny;
        if (onGround || water || lava || flying) fallStart = y; else if (y > fallStart) fallStart = y;
        if (y < -20) { y = 80; vy = 0; hurt(5, "Вы упали в бездну"); }
    }
    void move(World w, double dx, double dy, double dz) {
        if (!hits(w, x + dx, y, z + dz)) { x += dx; z += dz; return; }
        if (onGround || vy == 0) for (double s = .1; s <= 1.0; s += .1) if (!hits(w, x + dx, y + s, z + dz)) { x += dx; z += dz; y += s; return; }
        if (dx != 0) vx = 0; if (dz != 0) vz = 0;
    }
    void hurt(double d) { hurt(d, "Вы погибли"); }
    void hurt(double d, String why) {
        if (dead || creative) return;
        health -= (int) Math.ceil(d); sinceHurt = 0;
        if (health <= 0) { health = 0; dead = true; cause = why; vx = vz = 0; }
    }
    public double eyeY() { return y + EYE; }
}
