package voxel;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;

/** Иконки предметов: блоки — изометрические кубики из текстур, предметы и инструменты — пиксель-арт 16x16. */
final class Icons {
    static final Map<Integer, BufferedImage> cache = new HashMap<>();
    static final int[] TIER_COL = {0, 0xa07840, 0x8c8c8c, 0xe0e0e0, 0x4af0e0};

    static synchronized BufferedImage get(int id) { return cache.computeIfAbsent(id, Icons::make); }

    static void draw(Graphics2D g, int id, int x, int y, int size) { g.drawImage(get(id), x, y, size, size, null); }

    static BufferedImage make(int id) {
        if (Blocks.isBlock(id)) return cube(id);
        BufferedImage im = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        if (Blocks.isTool(id)) tool(im, Blocks.kind[id], TIER_COL[Blocks.tier[id]]);
        else item(im, id);
        return im;
    }

    // ---------- блоки ----------
    static BufferedImage cube(int id) {
        BufferedImage im = new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        // грань: начало, вектор u, вектор v (в пикселях на 16 текселей), индекс текстуры, яркость
        face(im, id, 16, 1, 14, 7, -14, 7, 0, 1.0);
        face(im, id, 2, 8, 14, 7, 0, 15, 1, .75);
        face(im, id, 16, 15, 14, -7, 0, 15, 1, .55);
        return im;
    }
    static void face(BufferedImage im, int id, double ox, double oy, double ax, double ay, double bx, double by, int tf, double br) {
        double det = ax * by - ay * bx;
        for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++) {
            double sx = x + .5 - ox, sy = y + .5 - oy;
            double u = (sx * by - sy * bx) / det * 16, v = (ax * sy - ay * sx) / det * 16;
            if (u < 0 || v < 0 || u >= 16 || v >= 16) continue;
            int c = Textures.get(id, tf, (int) u, (int) v); if (c < 0) continue;
            int r = (int) (((c >> 16) & 255) * br), g = (int) (((c >> 8) & 255) * br), b = (int) ((c & 255) * br);
            int a = (int) (Blocks.alpha[id] < 1 ? Math.max(.6, Blocks.alpha[id]) * 255 : 255);
            im.setRGB(x, y, (a << 24) | (r << 16) | (g << 8) | b);
        }
    }

    // ---------- предметы ----------
    static void px(BufferedImage im, int x, int y, int rgb) { if (x >= 0 && y >= 0 && x < 16 && y < 16) im.setRGB(x, y, 0xff000000 | rgb); }
    static int dk(int c, double f) { return (((int) (((c >> 16) & 255) * f)) << 16) | (((int) (((c >> 8) & 255) * f)) << 8) | (int) ((c & 255) * f); }
    static void disc(BufferedImage im, double cx, double cy, double r, int col) {
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) {
            double d = Math.hypot(x + .5 - cx, y + .5 - cy);
            if (d <= r) px(im, x, y, d > r - 1.2 ? dk(col, .7) : (x + y) % 5 == 0 ? dk(col, 1.15 > 1 ? .9 : 1) : col);
        }
    }
    static void item(BufferedImage im, int id) {
        if (id == Blocks.COAL) { disc(im, 8, 8.5, 5.5, 0x2c2c2c); px(im, 6, 6, 0x666666); px(im, 7, 6, 0x555555); }
        else if (id == Blocks.CLAY_BALL) disc(im, 8, 8, 5.5, 0xa0a5b4);
        else if (id == Blocks.IRON_INGOT || id == Blocks.GOLD_INGOT) {
            int c = id == Blocks.IRON_INGOT ? 0xdcdcdc : 0xf5d130;
            for (int y = 5; y < 11; y++) for (int x = 2 + (10 - y) / 2; x < 12 + (10 - y) / 2; x++) px(im, x, y, y == 5 ? dk(c, 1.0) : y == 10 ? dk(c, .6) : dk(c, .85));
            for (int x = 4; x < 11; x++) px(im, x, 5, c);
        }
        else if (id == Blocks.DIAMOND) {
            int c = 0x4af0e0;
            for (int y = 3; y < 13; y++) { int w = y < 7 ? y - 2 : 13 - y; for (int x = (int) (8 - w * 1.2); x < 8 + w * 1.2; x++) px(im, x, y, y < 7 ? c : dk(c, .72)); }
            px(im, 6, 5, 0xffffff); px(im, 7, 5, 0xc0ffff);
        }
        else if (id == Blocks.BRICK) {
            for (int y = 4; y < 12; y++) for (int x = 2; x < 14; x++) px(im, x, y, (y == 4 || x == 2) ? 0xd27a62 : (y == 11 || x == 13) ? 0x7a3322 : 0xb4503c);
            for (int x = 3; x < 13; x++) px(im, x, 8, 0xc8bcb0);
        }
        else if (id == Blocks.SULFUR) { for (int k = 0; k < 40; k++) { double a = k * 2.4, rr = 1 + (k % 6); int x = (int) (8 + Math.cos(a) * rr * .9), y = (int) (9 + Math.sin(a) * rr * .6); px(im, x, y, k % 3 == 0 ? 0xfff0a0 : k % 3 == 1 ? 0xeccb3c : 0xc8a828); } }
        else if (id == Blocks.KEY) {
            disc(im, 5, 5.5, 3.2, 0xf0c838); px(im, 5, 5, 0x302000); px(im, 4, 5, 0x302000);
            for (int k = 6; k < 14; k++) { px(im, k, k - 0 > 13 ? 13 : k, 0xd8aa20); px(im, k + 1, k, 0xf0c838); }
            px(im, 11, 12, 0xd8aa20); px(im, 12, 11, 0xd8aa20); px(im, 13, 13, 0xd8aa20);
        }
        else if (id == Blocks.STICK) { for (int i = 0; i < 11; i++) { px(im, 3 + i, 12 - i, 0x8a6030); px(im, 4 + i, 12 - i, 0xa07840); } }
        else { disc(im, 8, 8, 5, 0xff00ff); }
    }
    static void line(BufferedImage im, int x0, int y0, int x1, int y1, int c) {
        int n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
        for (int i = 0; i <= n; i++) px(im, x0 + (x1 - x0) * i / Math.max(1, n), y0 + (y1 - y0) * i / Math.max(1, n), c);
    }
    static void tool(BufferedImage im, int kind, int c) {
        int wood = 0x8a6030, d = dk(c, .7), l = dk(c, 1.0);
        if (kind == 4) { // меч
            line(im, 4, 11, 13, 2, c); line(im, 5, 11, 13, 3, d); line(im, 3, 11, 13, 1, l);
            line(im, 3, 8, 7, 12, 0x6a4a28); line(im, 2, 13, 4, 11, wood); px(im, 2, 14, wood);
            return;
        }
        line(im, 3, 13, 11, 5, wood); line(im, 4, 13, 12, 5, dk(wood, .75));
        if (kind == 1) { // кирка
            line(im, 5, 3, 11, 3, c); line(im, 4, 4, 12, 4, l); line(im, 3, 5, 4, 5, c); line(im, 12, 5, 13, 6, c); line(im, 13, 7, 13, 8, d); line(im, 3, 6, 3, 7, d); line(im, 4, 3, 4, 3, d);
        } else if (kind == 2) { // топор
            for (int y = 2; y <= 8; y++) for (int x = 8; x <= 13; x++) if (x - 8 + (y - 2) * .0 < 6 - Math.abs(y - 5) * 1.5) px(im, x, y, (x == 8 || y == 2) ? l : x > 11 ? d : c);
        } else { // лопата
            for (int y = 2; y <= 6; y++) for (int x = 9; x <= 14; x++) if (Math.hypot(x - 11.5, y - 4) < 2.8) px(im, x, y, y < 4 ? l : c);
        }
    }
}
