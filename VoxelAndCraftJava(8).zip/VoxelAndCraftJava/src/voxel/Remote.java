package voxel;

/** Другой игрок в сети (для отрисовки и серверного учёта). */
final class Remote implements Renderer.Renderable {
    int id; String name = "Игрок";
    double x, y, z, yaw, pitch, nx, ny, nz, nyaw, npitch, walk, swing;
    Net.Link link; boolean ready, first = true;

    void setTarget(double x, double y, double z, double yaw, double pitch) {
        nx = x; ny = y; nz = z; nyaw = yaw; npitch = pitch;
        if (first) { this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch; first = false; }
    }
    void update(double dt) {
        double dx = nx - x, dz = nz - z, k = Math.min(1, dt * 14);
        if (Math.hypot(dx, dz) > 8) { x = nx; z = nz; } else { x += dx * k; z += dz * k; }
        y += (ny - y) * k;
        double dA = ((nyaw - yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI; yaw += dA * k; pitch += (npitch - pitch) * k;
        double mv = Math.hypot(dx, dz) * k, spd = dt > 0 ? mv / dt : 0;
        swing += (Math.min(1, spd / 1.5) - swing) * Math.min(1, dt * 8); walk += mv * 3.0;
    }
    /** Модель смотрит туда же, куда игрок: у игрока вперёд при yaw=0 — это -Z, у модели ry=0 — тоже -Z. */
    public void emit(Renderer r) {
        int shirt = Textures.rgb(60 + (id * 53) % 120, 90 + (id * 97) % 100, 190 - (id * 41) % 90);
        Models.humanoid(r, x, y, z, yaw, walk, swing, false, pitch, 0xe0ac82, shirt, 0x32327a, 4, 0);
    }
}
