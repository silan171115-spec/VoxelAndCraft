package voxel;

import java.io.IOException;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Сервер (хост): принимает клиентов, шлёт им мир (отличия от генерации), блоки, игроков, мобов и время. Мир сохраняет только хост. */
final class Server implements Net.Handler {
    final Game game; final int port; ServerSocket ss; volatile boolean running;
    final ConcurrentLinkedQueue<Runnable> inbox = new ConcurrentLinkedQueue<>();
    final List<Net.Link> links = new ArrayList<>();
    final List<Object[]> pending = new ArrayList<>(); // {int[] блок, Link исключение}
    int nextId = 1; double tSend, tTime;

    Server(Game g, int port) { game = g; this.port = port; }

    void start() throws IOException {
        ss = new ServerSocket(port); running = true;
        Thread t = new Thread(() -> {
            while (running) {
                try { Socket s = ss.accept(); inbox.add(() -> accept(s)); } catch (IOException e) { break; }
            }
        }, "net-accept"); t.setDaemon(true); t.start();
        game.world.blockListener = a -> pending.add(new Object[]{a, null});
    }
    void accept(Socket s) {
        try { Net.Link l = new Net.Link(s, inbox, this); Remote r = new Remote(); r.link = l; l.user = r; links.add(l); }
        catch (IOException e) { try { s.close(); } catch (IOException ex) { } }
    }
    void stop() {
        running = false; try { if (ss != null) ss.close(); } catch (IOException e) { }
        for (Net.Link l : new ArrayList<>(links)) { l.send(Net.frame(Net.KICK, o -> o.writeUTF("Сервер закрыт"))); l.close(); }
        links.clear(); game.remotes.clear(); if (game.world != null) game.world.blockListener = null;
    }
    int players() { return 1 + game.remotes.size(); }

    // ------------------- приём -------------------
    public void handle(Net.Link l, int type, java.io.DataInputStream in) throws IOException {
        Remote r = (Remote) l.user;
        if (type == Net.HELLO) {
            if (r.ready) return;
            int proto = in.readInt(); String name = in.readUTF();
            if (proto != Net.PROTOCOL) { l.send(Net.frame(Net.KICK, o -> o.writeUTF("Неверная версия протокола"))); l.close(); return; }
            r.id = nextId++; r.name = name.isBlank() ? "Игрок" + r.id : name.substring(0, Math.min(16, name.length()));
            Player p = game.p;
            l.send(Net.frame(Net.WELCOME, o -> { o.writeInt(r.id); o.writeInt(game.world.seed); o.writeDouble(game.time); o.writeDouble(p.x + 1.5); o.writeDouble(p.y + .5); o.writeDouble(p.z); o.writeBoolean(p.creative); }));
            for (long k : game.world.editedChunks()) {
                int cx = (int) (k >> 32), cz = (int) (k & 0xffffffffL); int[] d = game.world.chunkDiff(cx, cz);
                if (d != null) l.send(Net.frame(Net.CHUNKDIFF, o -> { o.writeInt(cx); o.writeInt(cz); o.writeInt(d.length); for (int v : d) o.writeInt(v); }));
            }
            l.send(Net.frame(Net.DIFFDONE, o -> { })); r.ready = true; game.remotes.add(r);
            game.toast("Игрок " + r.name + " подключился");
        } else if (!r.ready) return;
        else if (type == Net.POS) { r.setTarget(in.readFloat(), in.readFloat(), in.readFloat(), in.readFloat(), in.readFloat()); }
        else if (type == Net.BLOCK) {
            int x = in.readInt(), y = in.readInt(), z = in.readInt(), id = in.readUnsignedByte(), meta = in.readUnsignedByte();
            game.world.quiet = true; game.world.set(x, y, z, id, meta, true); game.world.quiet = false;
            pending.add(new Object[]{new int[]{x, y, z, id, meta, 1}, l});
        } else if (type == Net.ATTACK) { game.mobs.attack(in.readInt(), Math.min(30, in.readFloat()), in.readFloat(), in.readFloat()); }
    }
    public void closed(Net.Link l) {
        links.remove(l); Remote r = (Remote) l.user;
        if (game.remotes.remove(r)) game.toast("Игрок " + r.name + " отключился");
    }

    // ------------------- отправка -------------------
    void broadcast(byte[] f) { for (Net.Link l : links) if (((Remote) l.user).ready) l.send(f); }
    void sendDamage(Remote r, int dmg) { if (r.link != null) r.link.send(Net.frame(Net.DAMAGE, o -> o.writeInt(dmg))); }

    void tick(double dt) {
        for (int i = 0; i < 200; i++) { Runnable r = inbox.poll(); if (r == null) break; r.run(); }
        // блоки — пачкой каждый тик
        if (!pending.isEmpty()) {
            for (Net.Link l : links) {
                if (!((Remote) l.user).ready) continue;
                List<int[]> mine = new ArrayList<>(); for (Object[] e : pending) if (e[1] != l) mine.add((int[]) e[0]);
                if (mine.isEmpty()) continue;
                l.send(Net.frame(Net.BLOCKS, o -> { o.writeInt(mine.size()); for (int[] a : mine) { o.writeInt(a[0]); o.writeInt(a[1]); o.writeInt(a[2]); o.writeByte(a[3]); o.writeByte(a[4]); } }));
            }
            pending.clear();
        }
        tSend += dt; tTime += dt;
        if (tSend >= .05) {
            tSend = 0;
            if (!links.isEmpty()) {
                List<Remote> all = new ArrayList<>(game.remotes);
                byte[] pf = Net.frame(Net.PLAYERS, o -> {
                    o.writeInt(all.size() + 1);
                    o.writeInt(0); o.writeUTF(game.nick); o.writeFloat((float) game.p.x); o.writeFloat((float) game.p.y); o.writeFloat((float) game.p.z); o.writeFloat((float) game.p.yaw); o.writeFloat((float) game.p.pitch);
                    for (Remote r : all) { o.writeInt(r.id); o.writeUTF(r.name); o.writeFloat((float) r.nx); o.writeFloat((float) r.ny); o.writeFloat((float) r.nz); o.writeFloat((float) r.nyaw); o.writeFloat((float) r.npitch); }
                });
                broadcast(pf);
                broadcast(Net.frame(Net.MOBS, o -> game.mobs.writeSnapshot(o)));
            }
        }
        if (tTime >= 1) { tTime = 0; broadcast(Net.frame(Net.TIME, o -> o.writeDouble(game.time))); }
    }
}
