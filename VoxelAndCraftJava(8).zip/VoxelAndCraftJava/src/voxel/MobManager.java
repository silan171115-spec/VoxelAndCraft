package voxel;

import java.io.*;
import java.util.*;
import java.util.function.IntConsumer;

/** Управляет мобами: спавн, ИИ (только хост), удары игрока и снимки для сети. */
final class MobManager {
    /** Цель для мобов: игрок (локальный или удалённый). */
    static final class Target {
        double x, y, z; boolean creative; IntConsumer damage;
        Target(double x, double y, double z, boolean creative, IntConsumer damage) { this.x = x; this.y = y; this.z = z; this.creative = creative; this.damage = damage; }
    }
    final List<Mob> mobs = new ArrayList<>();
    final Random rnd = new Random();
    int nextId = 1; double spawnT = 3;
    static final int MAX_PIGS = 10, MAX_ZOMBIES = 8, MAX_FISH = 18;

    void clear() { mobs.clear(); }

    // ---------------- хост / одиночная игра ----------------
    void update(World w, double dt, double day, List<Target> targets) {
        spawnT -= dt; if (spawnT <= 0) { spawnT = 1.5; trySpawn(w, day, targets); }
        for (Iterator<Mob> it = mobs.iterator(); it.hasNext(); ) {
            Mob m = it.next();
            double near = 1e18; for (Target t : targets) near = Math.min(near, (t.x - m.x) * (t.x - m.x) + (t.z - m.z) * (t.z - m.z));
            if (near > 90 * 90) { it.remove(); continue; }
            if (near > 70 * 70) continue; // слишком далеко — «замораживаем», чтобы не грузить генерацию мира
            m.update(w, dt, targets);
            if (m.type == Mob.ZOMBIE && day > .5 && m.hp > 0) { // горят на солнце
                int cx = Math.floorDiv((int) Math.floor(m.x), 16), cz = Math.floorDiv((int) Math.floor(m.z), 16);
                if (m.y + 1 > w.top(cx, cz)[Math.floorMod((int) Math.floor(m.z), 16) * 16 + Math.floorMod((int) Math.floor(m.x), 16)]) { m.hp -= 3 * dt; m.hurt = .3; }
            }
            if (m.hp <= 0) it.remove(); // без дропа: просто исчезает
        }
    }

    void trySpawn(World w, double day, List<Target> targets) {
        if (targets.isEmpty()) return;
        int pigs = 0, zombies = 0, fish = 0; for (Mob m : mobs) if (m.type == Mob.PIG) pigs++; else if (m.type == Mob.FISH) fish++; else zombies++;
        Target t = targets.get(rnd.nextInt(targets.size()));
        boolean night = day < .3;
        if (fish < MAX_FISH && w.dim == 0 && rnd.nextDouble() < .6) { if (spawnFish(w, t)) return; }
        for (int attempt = 0; attempt < 6; attempt++) {
            double a = rnd.nextDouble() * Math.PI * 2, d = 20 + rnd.nextDouble() * 24;
            int x = (int) Math.floor(t.x + Math.cos(a) * d), z = (int) Math.floor(t.z + Math.sin(a) * d);
            boolean cave = rnd.nextDouble() < (night ? .35 : .25);
            int y = -1; short[] top = w.top(Math.floorDiv(x, 16), Math.floorDiv(z, 16)); int ti = Math.floorMod(z, 16) * 16 + Math.floorMod(x, 16);
            if (!cave) y = top[ti] + 1;
            else {
                for (int yy = (int) t.y + 6; yy > Math.max(2, (int) t.y - 14); yy--)
                    if (yy < World.H - 2 && w.solid(x, yy - 1, z) && !w.solid(x, yy, z) && !w.solid(x, yy + 1, z) && w.get(x, yy, z) != Blocks.WATER && top[ti] > yy + 1) { y = yy; break; }
            }
            if (y < 2 || y >= World.H - 3 || w.solid(x, y, z) || w.solid(x, y + 1, z)) continue;
            int below = w.get(x, y - 1, z); if (!Blocks.solid[below]) continue;
            boolean covered = top[ti] > y + 1;
            boolean tooClose = false; for (Target o : targets) if (Math.hypot(o.x - x, o.z - z) < 16) tooClose = true; if (tooClose) continue;
            if (!covered && !night && day > .45 && below == Blocks.GRASS && pigs < MAX_PIGS) { spawnHerd(w, Mob.PIG, x + .5, y, z + .5, 2 + rnd.nextInt(3)); return; }
            if (((!covered && night) || covered) && zombies < MAX_ZOMBIES) { spawn(Mob.ZOMBIE, x + .5, y, z + .5); return; }
        }
    }
    /** Стая рыб в воде рядом с игроком. */
    boolean spawnFish(World w, Target t) {
        for (int attempt = 0; attempt < 8; attempt++) {
            double a = rnd.nextDouble() * Math.PI * 2, d = 12 + rnd.nextDouble() * 30;
            int x = (int) Math.floor(t.x + Math.cos(a) * d), z = (int) Math.floor(t.z + Math.sin(a) * d);
            int y = World.H - 2; while (y > 2 && w.get(x, y, z) == 0) y--;
            if (w.get(x, y, z) != Blocks.WATER) continue;
            int depth = 0; while (y - depth > 1 && w.get(x, y - depth, z) == Blocks.WATER) depth++;
            if (depth < 2) continue;
            int n = 2 + rnd.nextInt(4);
            for (int i = 0; i < n; i++) {
                int fx = x + rnd.nextInt(5) - 2, fz = z + rnd.nextInt(5) - 2, fy = y - 1 - rnd.nextInt(Math.min(depth - 1, 4));
                if (w.get(fx, fy, fz) == Blocks.WATER && w.get(fx, fy + 1, fz) == Blocks.WATER) spawn(Mob.FISH, fx + .5, fy + .2, fz + .5);
            }
            return true;
        }
        return false;
    }
    void spawnHerd(World w, int type, double x, double y, double z, int n) {
        spawn(type, x, y, z);
        for (int i = 1; i < n; i++) {
            double fx = x + rnd.nextDouble() * 4 - 2, fz = z + rnd.nextDouble() * 4 - 2;
            int bx = (int) Math.floor(fx), bz = (int) Math.floor(fz), by = (int) Math.floor(y);
            if (w.solid(bx, by - 1, bz) && !w.solid(bx, by, bz) && !w.solid(bx, by + 1, bz)) spawn(type, fx, y, fz);
        }
    }
    Mob spawn(int type, double x, double y, double z) { Mob m = new Mob(nextId++, type, x, y, z); mobs.add(m); return m; }

    /** Луч игрока: ближайший моб на расстоянии не больше maxD. dist[0] — расстояние. */
    Mob raycast(double ex, double ey, double ez, double dx, double dy, double dz, double maxD, double[] dist) {
        Mob best = null; double bt = maxD;
        for (Mob m : mobs) {
            double hw = m.halfW(), t0 = 0, t1 = bt; boolean ok = true;
            double[] o = {ex, ey, ez}, d = {dx, dy, dz}, lo = {m.x - hw, m.y, m.z - hw}, hi = {m.x + hw, m.y + m.height(), m.z + hw};
            for (int i = 0; i < 3 && ok; i++) {
                if (Math.abs(d[i]) < 1e-9) { if (o[i] < lo[i] || o[i] > hi[i]) ok = false; }
                else { double a = (lo[i] - o[i]) / d[i], b = (hi[i] - o[i]) / d[i]; if (a > b) { double s = a; a = b; b = s; } t0 = Math.max(t0, a); t1 = Math.min(t1, b); if (t0 > t1) ok = false; }
            }
            if (ok && t0 < bt) { bt = t0; best = m; }
        }
        if (best != null && dist != null) dist[0] = bt;
        return best;
    }
    /** Удар по мобу (локально на хосте или по запросу клиента). */
    void attack(int id, double dmg, double kx, double kz) {
        for (Mob m : mobs) if (m.id == id) {
            m.hp -= dmg; m.hurt = .4; m.vx = kx; m.vz = kz; m.vy = 5; m.panic = m.type == Mob.ZOMBIE ? 0 : 2.5; if (m.type == Mob.FISH) { m.vy = 0; m.dirY = 0; }
            if (m.type != Mob.ZOMBIE) { double l = Math.hypot(kx, kz); if (l > 0) { m.dirX = kx / l; m.dirZ = kz / l; } }
            return;
        }
    }

    // ---------------- сеть ----------------
    void writeSnapshot(DataOutputStream o) throws IOException {
        o.writeInt(mobs.size());
        for (Mob m : mobs) {
            o.writeInt(m.id); o.writeByte(m.type); o.writeFloat((float) m.x); o.writeFloat((float) m.y); o.writeFloat((float) m.z); o.writeFloat((float) m.ry);
            o.writeByte((m.moving ? 1 : 0) | (m.armsUp ? 2 : 0) | (m.hurt > 0 ? 4 : 0));
        }
    }
    /** Клиент: заменяет список мобов состоянием хоста (кого нет в снимке — тот мёртв). */
    void readSnapshot(DataInputStream in) throws IOException {
        int n = in.readInt(); Set<Integer> alive = new HashSet<>();
        for (int i = 0; i < n; i++) {
            int id = in.readInt(), type = in.readByte(); double x = in.readFloat(), y = in.readFloat(), z = in.readFloat(), ry = in.readFloat(); int fl = in.readByte();
            alive.add(id); Mob m = null; for (Mob o : mobs) if (o.id == id) { m = o; break; }
            if (m == null) { m = new Mob(id, type, x, y, z); m.ry = m.nry = ry; mobs.add(m); }
            m.nx = x; m.ny = y; m.nz = z; m.nry = ry; m.armsUp = (fl & 2) != 0; if ((fl & 4) != 0) m.hurt = .3;
        }
        mobs.removeIf(m -> !alive.contains(m.id));
    }
    void clientUpdate(double dt) { for (Mob m : mobs) m.clientUpdate(dt); }
}
