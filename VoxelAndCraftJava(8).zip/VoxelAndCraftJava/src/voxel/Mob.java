package voxel;

import java.util.List;
import java.util.Random;

/** Моб: свинья или зомби. Физика и ИИ работают на хосте; клиенты лишь сглаживают позицию из снимков. */
final class Mob implements Renderer.Renderable {
    static final int PIG = 0, ZOMBIE = 1, FISH = 2;
    final int id, type;
    double x, y, z, vx, vy, vz, ry, hp, walk, swing, hurt, atkCd, aiT, dirX, dirZ, dirY, panic, graze, atkAnim, fishPhase;
    boolean onGround, moving, armsUp;
    double nx, ny, nz, nry; // цели интерполяции у клиента
    final Random rnd = new Random();

    Mob(int id, int type, double x, double y, double z) {
        this.id = id; this.type = type; this.x = nx = x; this.y = ny = y; this.z = nz = z;
        hp = type == PIG ? 10 : type == FISH ? 4 : 20; fishPhase = rnd.nextDouble() * 6.28; ry = nry = rnd.nextDouble() * Math.PI * 2; aiT = rnd.nextDouble() * 2;
    }
    double halfW() { return type == PIG ? .4 : type == FISH ? .25 : .3; }
    double height() { return type == PIG ? .95 : type == FISH ? .35 : 1.95; }
    double speed() { return type == PIG ? 1.3 : type == FISH ? 1.1 : 2.4 + (id % 3) * .25; }

    boolean hits(World w, double px, double py, double pz) { double hw = halfW(); return w.hitsBox(px - hw, py, pz - hw, px + hw, py + height(), pz + hw); }

    void wander(double dt, double sp) {
        aiT -= dt;
        if (aiT <= 0) {
            if (rnd.nextDouble() < .5) { moving = false; aiT = 1 + rnd.nextDouble() * 3; }
            else { double a = rnd.nextDouble() * Math.PI * 2; dirX = Math.sin(a); dirZ = Math.cos(a); moving = true; aiT = 1 + rnd.nextDouble() * 3; }
        }
    }

    /** Шаг ИИ + физики (хост / одиночная игра). */
    void update(World w, double dt, List<MobManager.Target> targets) {
        hurt = Math.max(0, hurt - dt); atkCd -= dt; panic = Math.max(0, panic - dt); atkAnim = Math.max(0, atkAnim - dt * 3);
        if (type == FISH) { fishUpdate(w, dt); return; }
        double sp = speed(); moving = false; armsUp = false;
        if (type == ZOMBIE) {
            MobManager.Target best = null; double bd = 20 * 20;
            for (MobManager.Target t : targets) {
                if (t.creative || Math.abs(t.y - y) > 14) continue;
                double d2 = (t.x - x) * (t.x - x) + (t.z - z) * (t.z - z);
                if (d2 < bd) { bd = d2; best = t; }
            }
            if (best != null) {
                double dx = best.x - x, dz = best.z - z, d = Math.sqrt(dx * dx + dz * dz); armsUp = true;
                if (d > 1.0) { dirX = dx / d; dirZ = dz / d; moving = true; }
                if (d < 1.4 && Math.abs(best.y - y) < 1.7 && atkCd <= 0) { best.damage.accept(3); atkCd = 1.0; atkAnim = 1; }
            } else { wander(dt, sp); sp = 1.0; if (moving && unsafe(w)) { turnAway(); } }
        } else {
            if (panic > 0) { moving = true; sp = 3.2; } else { wander(dt, sp); }
            if (moving && unsafe(w)) turnAway();
            graze += ((!moving && aiT > .5 && aiT < 3 ? 1 : 0) - graze) * Math.min(1, dt * 4);
        }
        double wx = 0, wz = 0;
        if (moving) { wx = dirX * sp; wz = dirZ * sp; double want = Math.atan2(-dirX, -dirZ); double dA = ((want - ry + Math.PI * 3) % (Math.PI * 2)) - Math.PI; ry += dA * Math.min(1, dt * 10); }
        physics(w, dt, wx, wz);
        double spd = Math.hypot(vx, vz); swing += (Math.min(1, spd / 1.2) - swing) * Math.min(1, dt * 8); walk += spd * dt * 3.6;
        if (y < -10) hp = 0;
    }

    /** Впереди обрыв, вода или лава? */
    boolean unsafe(World w) {
        int ax = (int) Math.floor(x + dirX * .9), az = (int) Math.floor(z + dirZ * .9), y0 = (int) Math.floor(y);
        for (int d = 0; d <= 3; d++) {
            int id = w.get(ax, y0 - d, az);
            if (id == Blocks.WATER || id == Blocks.LAVA) return true;
            if (Blocks.solid[id]) return false;
        }
        return true;
    }
    void turnAway() { double a = Math.atan2(dirX, dirZ) + Math.PI * (.6 + rnd.nextDouble() * .8); dirX = Math.sin(a); dirZ = Math.cos(a); aiT = 1 + rnd.nextDouble() * 2; }

    /** Рыба: плавает в воде в трёх измерениях; на суше бьётся и погибает. */
    void fishUpdate(World w, double dt) {
        boolean in = w.get((int) Math.floor(x), (int) Math.floor(y + .15), (int) Math.floor(z)) == Blocks.WATER;
        fishPhase += dt * (4 + Math.hypot(vx, vz) * 4);
        if (!in) { hp -= dt * 1.5; vy -= 28 * dt; vx *= .9; vz *= .9; if (onGround) vy = 2.5; moving = false; }
        else {
            aiT -= dt;
            boolean ahead = w.get((int) Math.floor(x + dirX * .8), (int) Math.floor(y + .15 + dirY * .8), (int) Math.floor(z + dirZ * .8)) == Blocks.WATER;
            boolean above = w.get((int) Math.floor(x), (int) Math.floor(y + .9), (int) Math.floor(z)) == Blocks.WATER;
            if (aiT <= 0 || !ahead || panic > 0 && aiT <= 0) {
                double a = rnd.nextDouble() * Math.PI * 2; dirX = Math.sin(a); dirZ = Math.cos(a);
                dirY = (rnd.nextDouble() - .5) * .5; aiT = 1.5 + rnd.nextDouble() * 3;
                if (!above && dirY > 0) dirY = -.1;
            }
            double sp = panic > 0 ? 3.0 : speed();
            double k = Math.min(1, dt * 4);
            vx += (dirX * sp - vx) * k; vz += (dirZ * sp - vz) * k; vy += (dirY * sp - vy) * k; moving = true;
        }
        double nx_ = x + vx * dt; if (!hits(w, nx_, y, z)) x = nx_; else { vx = 0; aiT = 0; }
        double nz_ = z + vz * dt; if (!hits(w, x, y, nz_)) z = nz_; else { vz = 0; aiT = 0; }
        onGround = false; double ny_ = y + vy * dt;
        if (hits(w, x, ny_, z)) { if (vy < 0) onGround = true; vy = 0; aiT = 0; } else y = ny_;
        double spd = Math.hypot(vx, vz); swing = Math.min(1, spd / 1.1); if (spd > .05) { double want = Math.atan2(-vx, -vz); double dA = ((want - ry + Math.PI * 3) % (Math.PI * 2)) - Math.PI; ry += dA * Math.min(1, dt * 6); }
        if (y < -10) hp = 0;
    }

    void physics(World w, double dt, double wx, double wz) {
        boolean water = w.get((int) Math.floor(x), (int) Math.floor(y + .4), (int) Math.floor(z)) == Blocks.WATER;
        double k = Math.min(1, dt * 8); vx += (wx - vx) * k; vz += (wz - vz) * k;
        if (water) vy += (1.8 - vy) * Math.min(1, dt * 3); else vy -= 28 * dt;
        if (vy < -40) vy = -40;
        boolean blocked = false;
        double nx_ = x + vx * dt; if (!hits(w, nx_, y, z)) x = nx_; else { blocked = true; vx = 0; }
        double nz_ = z + vz * dt; if (!hits(w, x, y, nz_)) z = nz_; else { blocked = true; vz = 0; }
        if (blocked && onGround && moving) vy = 8.4;
        onGround = false; double ny_ = y + vy * dt;
        if (hits(w, x, ny_, z)) { if (vy < 0) onGround = true; vy = 0; } else y = ny_;
    }

    /** Клиент: плавно тянем позицию к присланной хостом. */
    void clientUpdate(double dt) {
        double dx = nx - x, dy = ny - y, dz = nz - z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d > 6) { x = nx; y = ny; z = nz; } else { double k = Math.min(1, dt * 14); x += dx * k; y += dy * k; z += dz * k; }
        double dA = ((nry - ry + Math.PI * 3) % (Math.PI * 2)) - Math.PI; ry += dA * Math.min(1, dt * 14);
        double mv = Math.hypot(dx, dz) * Math.min(1, dt * 14);
        double spd = dt > 0 ? mv / dt : 0; swing += (Math.min(1, spd / 1.2) - swing) * Math.min(1, dt * 8); walk += mv * 3.6;
        hurt = Math.max(0, hurt - dt);
    }

    public void emit(Renderer r) {
        if (type == PIG) Models.pig(r, x, y, z, ry, walk, swing, hurt, graze, id);
        else if (type == FISH) Models.fish(r, x, y, z, ry, fishPhase, swing, hurt, id);
        else {
            int[] shirts = {0x2896aa, 0x7a3a96, 0x9a4a3a}, pants = {0x2e3482, 0x30306a, 0x3a3a3a};
            Models.humanoid(r, x, y, z, ry, walk, swing, armsUp, 0, 0x58a048, shirts[id % 3], pants[id % 3], 3, hurt, Math.sin(atkAnim * Math.PI) * .7);
        }
    }
}
