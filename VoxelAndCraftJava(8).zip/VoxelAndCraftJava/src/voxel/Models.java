package voxel;

/** Кубические модели существ. Локальные оси: x — вправо, y — вверх, z — вперёд (лицом). */
final class Models {
    /** Поворот на угол ry вокруг Y + перенос; часть вращается вокруг оси X через шарнир (для ног, рук, головы). */
    static final class Rig {
        final Renderer r; final double ox, oy, oz, cr, sr;
        Rig(Renderer r, double x, double y, double z, double ry) { this.r = r; ox = x; oy = y; oz = z; cr = Math.cos(ry); sr = Math.sin(ry); }

        void part(double x0, double y0, double z0, double x1, double y1, double z1, double py, double pz, double ang, int color, int frontDetail) {
            double ca = Math.cos(ang), sa = Math.sin(ang);
            // грани: O, A, B (в локальных осях), внешняя нормаль, узор
            double[][] F = {
                {x0, y0, z1, x1 - x0, 0, 0, 0, y1 - y0, 0, 0, 0, 1, frontDetail},
                {x1, y0, z0, -(x1 - x0), 0, 0, 0, y1 - y0, 0, 0, 0, -1, 0},
                {x1, y0, z1, 0, 0, -(z1 - z0), 0, y1 - y0, 0, 1, 0, 0, 0},
                {x0, y0, z0, 0, 0, z1 - z0, 0, y1 - y0, 0, -1, 0, 0, 0},
                {x0, y1, z1, x1 - x0, 0, 0, 0, 0, -(z1 - z0), 0, 1, 0, 0},
                {x0, y0, z0, x1 - x0, 0, 0, 0, 0, z1 - z0, 0, -1, 0, 0}};
            for (double[] f : F) {
                double[] o = T(f[0], f[1], f[2], py, pz, ca, sa);
                double[] a = T(f[0] + f[3], f[1] + f[4], f[2] + f[5], py, pz, ca, sa), b = T(f[0] + f[6], f[1] + f[7], f[2] + f[8], py, pz, ca, sa);
                double[] n = T(f[0] + f[9], f[1] + f[10], f[2] + f[11], py, pz, ca, sa);
                double ax = a[0] - o[0], ay = a[1] - o[1], az = a[2] - o[2], bx = b[0] - o[0], by = b[1] - o[1], bz = b[2] - o[2];
                double cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx;
                double sign = (cx * (n[0] - o[0]) + cy * (n[1] - o[1]) + cz * (n[2] - o[2])) >= 0 ? 1 : -1;
                r.quad(o[0], o[1], o[2], ax, ay, az, bx, by, bz, color, (int) f[12], sign);
            }
        }
        double[] T(double lx, double ly, double lz, double py, double pz, double ca, double sa) {
            double y = ly - py, z = lz - pz;
            double yy = y * ca - z * sa, zz = y * sa + z * ca; ly = py + yy; lz = pz + zz;
            return new double[]{ox + lx * cr - lz * sr, oy + ly, oz - lx * sr - lz * cr};
        }
        void box(double x0, double y0, double z0, double x1, double y1, double z1, int color, int front) { part(x0, y0, z0, x1, y1, z1, 0, 0, 0, color, front); }
    }

    static int tint(int c, double hurt) { return hurt > 0 ? Textures.lerp(c, 0xff3030, Math.min(.6, hurt * 2)) : c; }

    static void pig(Renderer r, double x, double y, double z, double ry, double walk, double swing, double hurt, double graze, int id) {
        Rig g = new Rig(r, x, y, z, ry);
        boolean spot = id % 4 == 0;
        int body = tint(spot ? 0xe8c0b8 : 0xec98a0, hurt), head = tint(spot ? 0xf0cac0 : 0xf4a6ac, hurt), snout = tint(0xfcbebe, hurt), leg = tint(0xdc828c, hurt);
        double sw = Math.sin(walk) * .8 * swing;
        double[][] L = {{.2, .3, sw}, {-.2, .3, -sw}, {.2, -.3, -sw}, {-.2, -.3, sw}};
        for (double[] l : L) g.part(l[0] - .1, 0, l[1] - .1, l[0] + .1, .34, l[1] + .1, .34, l[1], l[2], leg, 0);
        g.box(-.3, .32, -.45, .3, .82, .45, body, 0);
        if (spot) g.box(-.31, .6, -.1, .31, .83, .3, tint(0xb07070, hurt), 0);
        double nod = graze * (.75 + .15 * Math.sin(walk * .5 + id)) + Math.sin(walk * 2) * .06 * swing;
        g.part(-.25, .5, .45, .25, .95, .9, .72, .45, nod, head, 1);
        g.part(-.13, .5, .9, .13, .72, 1.0, .72, .45, nod, snout, 2);
        g.part(-.2, .95, .55, -.1, 1.05, .65, .72, .45, nod, head, 0); g.part(.1, .95, .55, .2, 1.05, .65, .72, .45, nod, head, 0);
        double tw = Math.sin(walk * 1.5 + id) * .5; // хвостик
        g.part(-.04, .62, -.55, .04, .74, -.45, .74, -.45, .6 + tw * .3, leg, 0);
    }

    /** Рыба: тело, голова, хвост и плавники; хвост виляет. Длина ~0.7, высота ~0.35. */
    static void fish(Renderer r, double x, double y, double z, double ry, double phase, double swing, double hurt, int id) {
        Rig g = new Rig(r, x, y, z, ry);
        int[][] pal = {{0xe8872a, 0xf6c070}, {0x4a8ad0, 0xa8d4f0}, {0x58b070, 0xc8e8a0}, {0xc8c0b0, 0xf0ece0}};
        int a = tint(pal[id % 4][0], hurt), b = tint(pal[id % 4][1], hurt), fin = tint(Textures.lerp(pal[id % 4][0], 0xffffff, .2), hurt);
        double wag = Math.sin(phase) * .45;
        g.box(-.11, .05, -.2, .11, .32, .3, a, 0);
        g.box(-.09, .08, .3, .09, .27, .42, b, 4);
        g.box(-.1, .03, -.12, .1, .1, .22, b, 0);          // светлое брюшко
        g.box(-.015, .32, -.05, .015, .42, .2, fin, 0);     // спинной плавник
        g.box(-.2, .12, .02, -.11, .16, .14, fin, 0); g.box(.11, .12, .02, .2, .16, .14, fin, 0); // боковые
        // хвост: вращается вокруг вертикали через смещение — имитируем качанием вокруг X
        g.part(-.015, .06, -.45, .015, .32, -.2, .19, -.2, wag, fin, 0);
        g.part(-.015, .02, -.52, .015, .36, -.38, .19, -.2, wag * 1.4, a, 0);
    }

    static void humanoid(Renderer r, double x, double y, double z, double ry, double walk, double swing, boolean armsUp, double pitch,
                         int skin, int shirt, int pants, int faceDetail, double hurt) { humanoid(r, x, y, z, ry, walk, swing, armsUp, pitch, skin, shirt, pants, faceDetail, hurt, 0); }
    static void humanoid(Renderer r, double x, double y, double z, double ry, double walk, double swing, boolean armsUp, double pitch,
                         int skin, int shirt, int pants, int faceDetail, double hurt, double armSwing) {
        Rig g = new Rig(r, x, y, z, ry);
        skin = tint(skin, hurt); shirt = tint(shirt, hurt); pants = tint(pants, hurt);
        double sw = Math.sin(walk) * .9 * swing;
        g.part(0, 0, -.125, .25, .75, .125, .75, 0, sw, pants, 0);
        g.part(-.25, 0, -.125, 0, .75, .125, .75, 0, -sw, pants, 0);
        g.box(-.25, .75, -.125, .25, 1.5, .125, shirt, 0);
        double aL = armsUp ? -1.45 + armSwing : -sw, aR = armsUp ? -1.45 + armSwing : sw;
        g.part(.25, .75, -.125, .5, 1.5, .125, 1.4, 0, aL, armsUp ? skin : shirt, 0);
        g.part(-.5, .75, -.125, -.25, 1.5, .125, 1.4, 0, aR, armsUp ? skin : shirt, 0);
        g.part(-.25, 1.5, -.25, .25, 2.0, .25, 1.5, 0, -pitch, skin, faceDetail);
    }
}
