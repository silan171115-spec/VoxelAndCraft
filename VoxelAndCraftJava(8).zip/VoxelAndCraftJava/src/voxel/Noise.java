package voxel;

/** Детерминированный хеш-шум (порт из HTML-версии). */
final class Noise {
    static int seed;

    static double hs(int x, int y, int z, int s, int worldSeed) {
        int h = (x * 0x27d4eb2f) ^ (y * 0x165667b1) ^ (z * 0x1b873593) ^ ((s + worldSeed + 0x7f4a7c15) * 0x85ebca6b);
        h = (h ^ (h >>> 15)) * 0x2c1b3c6d;
        h = (h ^ (h >>> 12)) * 0x297a2d39;
        h ^= h >>> 15;
        return (h & 0xffffffffL) / 4294967296.0;
    }
    static double h(int x, int y, int z, int s) { return hs(x, y, z, s, seed); }
    static double sm(double t) { return t * t * (3 - 2 * t); }

    static double v2(double x, double z, int s) {
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        double fx = sm(x - ix), fz = sm(z - iz);
        double a = h(ix, 0, iz, s), b = h(ix + 1, 0, iz, s), c = h(ix, 0, iz + 1, s), d = h(ix + 1, 0, iz + 1, s);
        return a + (b - a) * fx + (c - a) * fz + (a - b - c + d) * fx * fz;
    }
    static double fbm2(double x, double z, int oct, int s) {
        double v = 0, a = 0.5, f = 1, n = 0;
        for (int i = 0; i < oct; i++) { v += a * v2(x * f, z * f, s + i * 17); n += a; a *= 0.5; f *= 2; }
        return v / n;
    }
    static double v3(double x, double y, double z, int s) {
        int ix = (int) Math.floor(x), iy = (int) Math.floor(y), iz = (int) Math.floor(z);
        double fx = sm(x - ix), fy = sm(y - iy), fz = sm(z - iz);
        double a = h(ix, iy, iz, s), b = h(ix + 1, iy, iz, s), c = h(ix, iy + 1, iz, s), d = h(ix + 1, iy + 1, iz, s);
        double e = h(ix, iy, iz + 1, s), f = h(ix + 1, iy, iz + 1, s), g = h(ix, iy + 1, iz + 1, s), hh = h(ix + 1, iy + 1, iz + 1, s);
        double x1 = a + (b - a) * fx, x2 = c + (d - c) * fx, x3 = e + (f - e) * fx, x4 = g + (hh - g) * fx;
        double y1 = x1 + (x2 - x1) * fy, y2 = x3 + (x4 - x3) * fy;
        return y1 + (y2 - y1) * fz;
    }
    /** Шум для текстур: не зависит от зерна мира. */
    static double t(int x, int y, int s) { return hs(x, y, 0, s, 0); }
    static double tn(int x, int y, int cells, int s) {
        double sc = 16.0 / cells, fx = x / sc, fy = y / sc;
        int ix = (int) Math.floor(fx), iy = (int) Math.floor(fy);
        double tx = sm(fx - ix), ty = sm(fy - iy);
        double a = t(((ix) % cells + cells) % cells, ((iy) % cells + cells) % cells, s);
        double b = t(((ix + 1) % cells + cells) % cells, ((iy) % cells + cells) % cells, s);
        double c = t(((ix) % cells + cells) % cells, ((iy + 1) % cells + cells) % cells, s);
        double d = t(((ix + 1) % cells + cells) % cells, ((iy + 1) % cells + cells) % cells, s);
        return a + (b - a) * tx + (c - a) * ty + (a - b - c + d) * tx * ty;
    }
}
