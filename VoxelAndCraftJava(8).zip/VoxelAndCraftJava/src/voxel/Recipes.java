package voxel;

import java.util.*;

/** Рецепты крафта (сетка 3x3 или 2x2) и плавки. Отрицательные числа в шаблоне — группы предметов. */
final class Recipes {
    static final int ANY_STONE = -1, ANY_PLANKS = -2, ANY_LOG = -3, E = 0;
    static final class R { int w, h; int[] pat; int res, n; boolean shapeless; }
    static final List<R> ALL = new ArrayList<>();
    static final Map<Integer, Integer> SMELT = new HashMap<>();

    static boolean eq(int token, int id) {
        if (token > 0) return token == id;
        if (token == ANY_STONE) return id == Blocks.COBBLE || id == Blocks.STONE;
        if (token == ANY_PLANKS) return id == Blocks.PLANKS || id == Blocks.SPRUCE_PLANKS;
        if (token == ANY_LOG) return id == Blocks.LOG || id == Blocks.BIRCH || id == Blocks.SPRUCE;
        return false;
    }
    static void shaped(int res, int n, int w, int h, int... pat) { R r = new R(); r.w = w; r.h = h; r.pat = pat; r.res = res; r.n = n; ALL.add(r); }
    static void shapeless(int res, int n, int... items) { R r = new R(); r.shapeless = true; r.pat = items; r.res = res; r.n = n; ALL.add(r); }

    static {
        shaped(Blocks.PLANKS, 4, 1, 1, Blocks.LOG); shaped(Blocks.PLANKS, 4, 1, 1, Blocks.BIRCH); shaped(Blocks.SPRUCE_PLANKS, 4, 1, 1, Blocks.SPRUCE);
        shaped(Blocks.STICK, 4, 1, 2, ANY_PLANKS, ANY_PLANKS);
        shaped(Blocks.CRAFT, 1, 2, 2, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS);
        int C = ANY_STONE;
        shaped(Blocks.FURNACE, 1, 3, 3, C, C, C, C, E, C, C, C, C);
        int[] mat = {0, ANY_PLANKS, ANY_STONE, Blocks.IRON_INGOT, Blocks.DIAMOND}, S = {Blocks.STICK};
        for (int t = 1; t <= 4; t++) {
            int M = mat[t], s = Blocks.STICK;
            shaped(Blocks.toolId(1, t), 1, 3, 3, M, M, M, E, s, E, E, s, E);
            shaped(Blocks.toolId(2, t), 1, 2, 3, M, M, M, s, E, s);
            shaped(Blocks.toolId(2, t), 1, 2, 3, M, M, s, M, s, E);
            shaped(Blocks.toolId(3, t), 1, 1, 3, M, s, s);
            shaped(Blocks.toolId(4, t), 1, 1, 3, M, M, s);
        }
        int I = Blocks.IRON_INGOT, s = Blocks.STICK;
        shaped(Blocks.GEAR, 4, 3, 3, E, I, E, I, s, I, E, I, E);
        shaped(Blocks.LEVER, 1, 1, 2, s, C);
        shapeless(Blocks.LAMP, 2, Blocks.GLASS, Blocks.GOLD_INGOT);
        shaped(Blocks.DOOR, 2, 2, 3, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS, ANY_PLANKS);
        shaped(Blocks.SULFUR_STONE, 4, 2, 2, Blocks.COAL, C, C, Blocks.COAL);
        for (int k = 0; k < Blocks.MATS.length; k++) {
            int m = Blocks.MATS[k];
            shaped(Blocks.SLAB0 + k, 6, 3, 1, m, m, m);
            shaped(Blocks.STAIR0 + k, 4, 3, 3, m, E, E, m, m, E, m, m, m);
            shapeless(m, 1, Blocks.SLAB0 + k, Blocks.SLAB0 + k);
        }
        shaped(Blocks.CALCITE_BRICKS, 4, 2, 2, Blocks.CALCITE, Blocks.CALCITE, Blocks.CALCITE, Blocks.CALCITE);
        shaped(Blocks.SMOOTH_CALCITE, 2, 1, 2, Blocks.CALCITE, Blocks.CALCITE);
        // как в оригинале: угольный блок, динамит и серный ключ
        shapeless(Blocks.COAL_BLOCK, 1, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.COAL);
        shapeless(Blocks.COAL, 9, Blocks.COAL_BLOCK);
        shapeless(Blocks.DYNAMITE, 1, Blocks.SAND, Blocks.SAND, Blocks.SAND, Blocks.SAND, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.GEAR);
        shapeless(Blocks.KEY, 1, Blocks.DYNAMITE, Blocks.COAL, Blocks.COAL, Blocks.COAL, Blocks.IRON_INGOT);
        shaped(Blocks.STONEBRICKS, 4, 2, 2, Blocks.STONE, Blocks.STONE, Blocks.STONE, Blocks.STONE);

        SMELT.put(Blocks.IRON_ORE, Blocks.IRON_INGOT); SMELT.put(Blocks.GOLD_ORE, Blocks.GOLD_INGOT); SMELT.put(Blocks.SAND, Blocks.GLASS);
        SMELT.put(Blocks.COBBLE, Blocks.STONE); SMELT.put(Blocks.CLAY_BALL, Blocks.BRICK);
        SMELT.put(Blocks.LOG, Blocks.COAL); SMELT.put(Blocks.BIRCH, Blocks.COAL); SMELT.put(Blocks.SPRUCE, Blocks.COAL);
    }
    static int smelt(int id) { Integer r = SMELT.get(id); return r == null ? 0 : r; }

    /** @return {id, count} или null. ids — клетки сетки size x size. */
    static int[] match(int[] ids, int size) {
        int minX = size, minY = size, maxX = -1, maxY = -1, count = 0;
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) if (ids[y * size + x] != 0) { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); count++; }
        if (count == 0) return null;
        int bw = maxX - minX + 1, bh = maxY - minY + 1;
        for (R r : ALL) {
            if (r.shapeless) {
                if (r.pat.length != count) continue;
                boolean[] used = new boolean[r.pat.length]; boolean ok = true; int found = 0;
                for (int i = 0; i < ids.length && ok; i++) if (ids[i] != 0) {
                    boolean hit = false;
                    for (int j = 0; j < r.pat.length; j++) if (!used[j] && eq(r.pat[j], ids[i])) { used[j] = true; hit = true; found++; break; }
                    if (!hit) ok = false;
                }
                if (ok && found == r.pat.length) return new int[]{r.res, r.n};
            } else {
                if (r.w != bw || r.h != bh) continue;
                boolean ok = true;
                for (int y = 0; y < bh && ok; y++) for (int x = 0; x < bw && ok; x++) {
                    int tok = r.pat[y * bw + x], id = ids[(minY + y) * size + minX + x];
                    if (tok == E ? id != 0 : !eq(tok, id)) ok = false;
                }
                if (ok) return new int[]{r.res, r.n};
            }
        }
        return null;
    }
}
