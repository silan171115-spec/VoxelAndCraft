package voxel;

/** Меш чанка после жадного слияния граней. Квад = 8 int: dir, plane, a0, b0, aw, bh, id, shadow. */
final class Mesh {
    static final class IntList {
        int[] a = new int[256]; int n;
        void add(int v) { if (n == a.length) a = java.util.Arrays.copyOf(a, n * 2); a[n++] = v; }
    }
    /** Неполные блоки (плиты, ступеньки, текущая вода): грани по 12 чисел: ox,oy,oz, ax,ay,az, bx,by,bz, id, alpha(0..256), shade. */
    static final class DList {
        double[] a = new double[240]; int n;
        void add(double... v) { if (n + v.length > a.length) a = java.util.Arrays.copyOf(a, Math.max(a.length * 2, n + v.length)); for (double d : v) a[n++] = d; }
    }
    final DList sh = new DList();
    final IntList op = new IntList(), tr = new IntList();
    int quads() { return (op.n + tr.n) / 8 + sh.n / 12; }
}
