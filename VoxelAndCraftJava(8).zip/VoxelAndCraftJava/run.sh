#!/bin/sh
java -cp out voxel.Game "$@"
