@echo off
if not exist out mkdir out
javac -encoding UTF-8 -d out src\voxel\*.java && echo Build OK. Run: run.bat
